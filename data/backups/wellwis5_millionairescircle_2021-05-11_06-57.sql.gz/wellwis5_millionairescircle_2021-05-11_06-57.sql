#RS|wellwis5_millionairescircle|48|2021.05.11 06:57:18|1259|1|2|3|18|60|2|1|29|1|2|1|7|3|1|69|3|81|253|1|18|561|136|2|3|1

DROP TABLE IF EXISTS aemailtempl;
CREATE TABLE `aemailtempl` (
  `emailtempl_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `message` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `tag_descr` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`emailtempl_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `aemailtempl` VALUES(1, 'Welcome to [SiteTitle]', '&lt;p&gt;Dear [FirstName] [LastName],&lt;/p&gt;\r\n&lt;p&gt;Some message with tags.&lt;/p&gt;\r\n&lt;p&gt;Regards, [SiteTitle]&lt;/p&gt;', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteUrl]\');\">SiteUrl</a>] - Url of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[RefLink]\');\">RefLink</a>] - Referral Link<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[ID]\');\">ID</a>] - Member&#039;s ID<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s First Name<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s Last Name<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s Username<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s Email<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorID]\');\">SponsorID</a>] - Sponsor&#039;s ID<br>\r\n', 1);


DROP TABLE IF EXISTS aptools;
CREATE TABLE `aptools` (
  `aptool_id` int(11) NOT NULL AUTO_INCREMENT,
  `photo` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `title` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`aptool_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS autoresponders;
CREATE TABLE `autoresponders` (
  `email_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `message` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `z_day` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `is_free` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`email_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `autoresponders` VALUES(1, 'test', 'test', 1, 0, 1);
INSERT INTO `autoresponders` VALUES(2, 'test', 'test', 2, 0, 0);


DROP TABLE IF EXISTS cash;
CREATE TABLE `cash` (
  `cash_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `from_id` int(11) NOT NULL DEFAULT '0',
  `to_id` int(11) NOT NULL DEFAULT '0',
  `type_cash` varchar(150) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `descr` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `cash_date` int(11) NOT NULL DEFAULT '0',
  `payment_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cash_id`),
  KEY `transfer_date_idx` (`cash_date`),
  KEY `user_id_idx` (`to_id`),
  KEY `amount_idx` (`amount`),
  KEY `from_id_idx` (`from_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS cash_out;
CREATE TABLE `cash_out` (
  `cash_out_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `processor` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `account_id` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `transfer_date` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cash_out_id`),
  KEY `transfer_date_idx` (`transfer_date`),
  KEY `member_id_idx` (`member_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS categories;
CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `m_level` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS currency;
CREATE TABLE `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `symbol` varchar(8) DEFAULT NULL,
  `name` varchar(8) DEFAULT '',
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `currency` VALUES(1, '$', 'USD', 1);
INSERT INTO `currency` VALUES(2, '€', 'EUR', 1);
INSERT INTO `currency` VALUES(3, 'Mex$', 'MXN', 1);


DROP TABLE IF EXISTS emailtempl;
CREATE TABLE `emailtempl` (
  `emailtempl_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `subject` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `message` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `tag_descr` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`emailtempl_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `emailtempl` VALUES(1, 'Sponsor notification about new sign up', 'From [SiteTitle]: New referrer signup up', 'Dear [SponsorFName] [SponsorLName], \r\n\r\nYou referral activated account. Their email is [Email], name is [FirstName] [LastName]. Contact them and make sure they are able to verify their email address.\r\nIf they don&#039;t do this within 24 hours they will be removed.\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorFName]\');\">SponsorFName</a>] - Sponsor&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorLName]\');\">SponsorLName</a>] - Sponsor&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorUsername]\');\">SponsorUsername</a>] - Sponsor&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorEmail]\');\">SponsorEmail</a>] - Sponsor&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(2, 'Welcome email sent to member after successful registration with activation link', 'Activate your new account in [SiteTitle]', 'Welcome and thank you for signing up to be a Member of [SiteTitle].\r\n\r\nYour login is: [Username]\r\nYour password is: [Password]\r\n\r\nTo activate your account (active within 24 hours) follow this Activation Membership link:\r\n[ActivationLink]\r\n\r\nWe look forward to helping you grow your business.\r\n\r\nWith best regards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Password]\');\">Password</a>] - Member&#039;s password<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[ActivationLink]\');\">ActivationLink</a>] - Member&#039;s activation link<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(3, 'Sponsor notification about a new activated referral', 'From [SiteTitle]: New personal referral is verified', 'Dear [SponsorFName] [SponsorLName], \r\n\r\nYour new enrollee has just become verified.\r\nTheir email address is [Email], name is [FirstName] [LastName].\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorFName]\');\">SponsorFName</a>] - Sponsor&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorLName]\');\">SponsorLName</a>] - Sponsor&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorUsername]\');\">SponsorUsername</a>] - Sponsor&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorEmail]\');\">SponsorEmail</a>] - Sponsor&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(4, 'Welcome email sent to member after successful registration', 'Welcome to [SiteTitle]', 'Welcome and thank you for signing up to be a Member of [SiteTitle].\r\n\r\nYour login is: [Username]\r\nYour password is: [Password]\r\n\r\nWe look forward to helping you grow your business.\r\n\r\nWith best regards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Password]\');\">Password</a>] - Member&#039;s password<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[RefLink]\');\">RefLink</a>] - Member&#039;s Referral Link<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(5, 'Forgot password email content with new access details', 'From [SiteTitle]: Your new access details', 'Dear [FirstName] [LastName], \r\n\r\nYou received this email because you have requested to remind you login details for [SiteTitle].\r\n\r\nYour login is: [Username]\r\n\r\nYour password is: [Password]\r\n\r\nYour referral link is: [RefLink]\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Password]\');\">Password</a>] - Member&#039;s password<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[RefLink]\');\">RefLink</a>] - Member&#039;s Referral Link<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(6, 'Pin code email after unsuccessfull log in attempt from wrong IP address', 'From [SiteTitle]: Changing Security Data', 'Dear [FirstName] [LastName], \r\n\r\nYou have tried to enter  [SiteTitle] from another IP address.\r\n\r\nTo change your current IP address click the link below end enter this pin-code: [PinCode]\r\n\r\n\r\n[CheckLink]\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[PinCode]\');\">PinCode</a>] - Member&#039;s pin code<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[CheckLink]\');\">CheckLink</a>] - Member&#039;s check link<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(7, 'Guest notification about a new ticket registration at the public support center', 'From [SiteTitle]: Your new ticket has been successfully registered', 'Dear [FirstName] [LastName], \r\n\r\nYour ticket was successfully sent to support center of [SiteTitle]. It will be soon answered.\r\n\r\n\r\nSubject of ticket: [TicketSubject]\r\n\r\nPlease use this direct link to view ticket status: \r\n\r\n[TicketLink] \r\n\r\n\r\nAlso you can view your ticket status using another way and following details:\r\n\r\nURL: [TicketShortLink] \r\n\r\nE-mail: [Email] \r\n\r\nTicket code: [TicketCode] \r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketSubject]\');\">TicketSubject</a>] - Subject of the ticket<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketCode]\');\">TicketCode</a>] - Ticket code<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketLink]\');\">TicketLink</a>] - Full ticket link<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketShortLink]\');\">TicketShortLink</a>] - Short ticket link<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(8, 'Guest notification about answer from the public support center', 'From [SiteTitle]: New answer from public support center', 'Dear [FirstName] [LastName], \r\n\r\nYou have just received an answer on your ticket.\r\n\r\nPlease use this direct link to view ticket status: \r\n\r\n[TicketLink] \r\n\r\n\r\nAlso you can view your ticket status using another way and following details:\r\n\r\nURL: [TicketShortLink] \r\n\r\nE-mail: [Email] \r\n\r\nTicket code: [TicketCode]\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketSubject]\');\">TicketSubject</a>] - Subject of the ticket<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketCode]\');\">TicketCode</a>] - Ticket code<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketLink]\');\">TicketLink</a>] - Full ticket link<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketShortLink]\');\">TicketShortLink</a>] - Short ticket link<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(9, 'Email template for members contact page', '[SiteTitle]: A message from [SenderFirstName] [SenderLastName] ([SenderID])!', 'Hello [FirstName] [LastName], \r\n\r\nSome message\r\n\r\n\r\n\r\n\r\nRegards,\r\n[SenderFirstName] [SenderLastName]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[ID]\');\">ID</a>] - Member&#039;s ID<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SenderFirstName]\');\">SenderFirstName</a>] - Sender&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SenderLastName]\');\">SenderLastName</a>] - Sender&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SenderID]\');\">SenderID</a>] - Sender&#039;s ID<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(10, 'Email template for members Tell Friend page', 'From [SiteTitle]: Hi [FirstName] [LastName]!', 'Hello [FirstName] [LastName], \r\n\r\nI just had to tell you about this great site I just found.\r\n\r\nCheck it out for yourself at [RefLink]\r\n\r\n\r\n\r\nRegards,\r\n[SenderFirstName] [SenderLastName]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SenderFirstName]\');\">SenderFirstName</a>] - Sender&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SenderLastName]\');\">SenderLastName</a>] - Sender&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[RefLink]\');\">RefLink</a>] - Sender&#039;s Referral Link<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(11, 'Successfull payment notification', 'From [SiteTitle]: Successful payment', 'Hello [FirstName] [LastName], \r\n\r\nYou have made a successful [Processor] payment.\r\n\r\nAmount: $[Amount]\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Processor]\');\">Processor</a>] - Payment Processor<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(12, 'Getting commissions / forced matrix mode', 'From [SiteTitle]: Your membership earned commissions', 'Congratulations [FirstName] [LastName], \r\n\r\nYour [SiteTitle] membership earned you $[Amount].\r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(13, 'Matrix completion and getting commissions / cycling matrix mode', 'From [SiteTitle]: Your membership earned commissions', 'Congratulations [FirstName] [LastName], \r\n\r\nYou just completed [Matrix] matrix on [SiteTitle] and earned $[Amount].\r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Matrix]\');\">Matrix</a>] - Title of completed matrix<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(14, 'Matrix completion and getting commissions by sponsor/ cycling mode', 'From [SiteTitle]: Your membership earned commissions', 'Congratulations [FirstName] [LastName], \r\n\r\nYour referral #[RefID] just completed [Matrix] matrix on [SiteTitle] and earned you $[Amount].\r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Matrix]\');\">Matrix</a>] - Title of completed matrix<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[RefID]\');\">RefID</a>] - Referral ID<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(15, 'Sponsor bonus notification for personally enrolled', 'From [SiteTitle]: You earned sponsor bonus', 'Congratulations [FirstName] [LastName], \r\n\r\nYou earned [SiteTitle] sponsor bonus : $[Amount].\r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(16, 'Successfull withdrawal request completion notification', 'From [SiteTitle]: your withdrawal request is completed', 'Hello [FirstName] [LastName], \r\n\r\nYour withdrawal request was successfully completed.\r\n\r\n$[Amount] was paid to your account.\r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(17, 'End of active period notification/ forced mode', 'From [SiteTitle]: active period expired', 'Hello [FirstName] [LastName], \r\n\r\nYour Account has expired. \r\n\r\nYou should log in to your member area now to make a payment, ensuring that you retain active status in the pay plan and do not lose any benefits. \r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(18, 'Pre Launch notification', '[SiteTitle] is launched', 'Hello [FirstName] [LastName],\r\n\r\nWe are glad to inform you that starting from now you can Upgrade your account in <a href=\'[SiteUrl]\'>[SiteTitle]</a>.\r\n\r\nPlease login using your credentials. \r\n\r\nWith best regards,\r\n[SiteTitle] Team\r\n', '', 1);


DROP TABLE IF EXISTS faq;
CREATE TABLE `faq` (
  `faq_id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(200) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `answer` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`faq_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS fees;
CREATE TABLE `fees` (
  `fee_id` int(11) NOT NULL AUTO_INCREMENT,
  `to_order_index` int(11) NOT NULL DEFAULT '0',
  `plevel` int(3) NOT NULL DEFAULT '0',
  `fee_member` decimal(12,2) NOT NULL DEFAULT '0.00',
  `fee_sponsor` decimal(12,2) NOT NULL DEFAULT '0.00',
  `from_order_index` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fee_id`),
  KEY `to_order_index_idx` (`to_order_index`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS lands;
CREATE TABLE `lands` (
  `land_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `photo` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `z_date` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`land_id`),
  KEY `z_date_idx` (`z_date`)
) ENGINE=MyISAM AUTO_INCREMENT=8 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS logs;
CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_date` int(11) NOT NULL DEFAULT '0',
  `ip_addr` varchar(20) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `descr` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  PRIMARY KEY (`log_id`),
  KEY `z_date_idx` (`z_date`)
) ENGINE=MyISAM AUTO_INCREMENT=61 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `logs` VALUES(1, 1612782250, '2a00:bc00:8800:b665:', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(2, 1612784946, '79.175.57.168', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(3, 1612793526, '79.175.57.168', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(4, 1612795261, '2a00:bc00:8800:b665:', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(5, 1612797097, '2a00:bc00:8800:b665:', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(6, 1612801367, '176.194.145.23', 'Incorrect login attempt. Password or Username do not match.');
INSERT INTO `logs` VALUES(7, 1612801372, '176.194.145.23', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(8, 1618839988, '93.157.144.198', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(9, 1618928098, '93.157.144.198', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(10, 1618928897, '2a00:bc00:8800:b665:', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(11, 1619004757, '2a00:bc00:8800:b665:', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(12, 1619013018, '2a00:bc00:8800:b665:', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(13, 1619026131, '46.72.21.127', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(14, 1619093412, '93.157.144.198', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(15, 1619097530, '2a00:bc00:8800:b665:', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(16, 1619102064, '2a00:bc00:8800:b665:', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(17, 1619690175, '93.157.144.198', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(18, 1619699304, '168.167.25.38', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(19, 1619701189, '93.157.144.198', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(20, 1619707244, '2a00:bc00:8800:b665:', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(21, 1619707245, '2a00:bc00:8800:b665:', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(22, 1619720658, '146.112.56.76', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(23, 1619802050, '168.167.26.181', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(24, 1619807410, '168.167.26.181', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(25, 1619816378, '168.167.26.181', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(26, 1619841919, '168.167.26.181', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(27, 1619863180, '168.167.26.181', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(28, 1620049942, '168.167.26.188', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(29, 1620132676, '168.167.26.188', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(30, 1620195733, '2a00:bc00:8800:b665:', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(31, 1620203343, '93.157.144.198', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(32, 1620246245, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(33, 1620248417, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(34, 1620248799, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(35, 1620249415, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(36, 1620249618, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(37, 1620249942, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(38, 1620250310, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(39, 1620251368, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(40, 1620252365, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(41, 1620259345, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(42, 1620259876, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(43, 1620281143, '93.157.144.198', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(44, 1620328806, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(45, 1620329862, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(46, 1620330524, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(47, 1620334078, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(48, 1620366798, '93.157.144.198', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(49, 1620367675, '2a00:bc00:8800:b665:', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(50, 1620400028, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(51, 1620412296, '46.72.21.127', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(52, 1620416947, '168.167.26.133', 'Incorrect login attempt. Password or Username do not match.');
INSERT INTO `logs` VALUES(53, 1620416951, '168.167.26.133', 'Incorrect login attempt. Password or Username do not match.');
INSERT INTO `logs` VALUES(54, 1620416956, '168.167.26.133', 'Incorrect login attempt. Password or Username do not match.');
INSERT INTO `logs` VALUES(55, 1620416975, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(56, 1620425809, '168.167.26.133', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(57, 1620737163, '37.25.123.125', 'Incorrect login attempt. Password or Username do not match.');
INSERT INTO `logs` VALUES(58, 1620737167, '37.25.123.125', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(59, 1620737379, '37.25.123.125', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(60, 1620737488, '46.72.21.127', 'Logged in succesfully.');


DROP TABLE IF EXISTS matrices_completed;
CREATE TABLE `matrices_completed` (
  `matrix_id` int(11) NOT NULL AUTO_INCREMENT,
  `place_id` int(11) DEFAULT '0',
  `z_date` int(11) DEFAULT '0',
  PRIMARY KEY (`matrix_id`),
  KEY `place_id_idx` (`place_id`),
  KEY `z_date_idx` (`z_date`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS matrix;
CREATE TABLE `matrix` (
  `matrix_id` int(11) NOT NULL AUTO_INCREMENT,
  `m_level` int(11) DEFAULT '0',
  `host_id` int(11) DEFAULT '0',
  `host_matrix` int(11) DEFAULT '0',
  `referrer_id` int(11) DEFAULT '0',
  `referrer_matrix` int(11) DEFAULT '0',
  `member_id` int(11) DEFAULT '0',
  `member_matrix` int(11) DEFAULT '0',
  `z_date` int(11) DEFAULT '0',
  `is_completed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`matrix_id`),
  KEY `host_id_idx` (`host_id`),
  KEY `member_id_idx` (`member_id`),
  KEY `referrer_id_idx` (`referrer_id`),
  KEY `m_level_idx` (`m_level`),
  KEY `host_matrix_idx` (`host_matrix`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS matrixes;
CREATE TABLE `matrixes` (
  `matrix_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `width` int(3) DEFAULT '0',
  `depth` int(3) DEFAULT '0',
  `entrance_fee` decimal(12,2) NOT NULL DEFAULT '0.00',
  `is_mode` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`matrix_id`),
  KEY `title_idx` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `matrixes` VALUES(1, 'Forced Matrix', 2, 3, '10.00', 1, 1);
INSERT INTO `matrixes` VALUES(2, 'Cycling Matrix', 2, 2, '25.00', 0, 0);


DROP TABLE IF EXISTS members;
CREATE TABLE `members` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `replica` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_replica` tinyint(1) NOT NULL DEFAULT '0',
  `is_a_replica` tinyint(1) NOT NULL DEFAULT '0',
  `enroller_id` int(11) NOT NULL DEFAULT '0',
  `passwd` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `email` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `first_name` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `last_name` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `street` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `city` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `state` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `country` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `postal` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `phone` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `reg_date` int(11) NOT NULL DEFAULT '0',
  `last_access` int(11) NOT NULL DEFAULT '0',
  `m_level` int(3) NOT NULL DEFAULT '0',
  `processor` int(11) NOT NULL DEFAULT '0',
  `account_id` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `quant_pay` int(5) NOT NULL DEFAULT '0',
  `ip_check` tinyint(1) NOT NULL DEFAULT '0',
  `ip_address` varchar(20) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `pin_code` varchar(20) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `is_dead` tinyint(1) NOT NULL DEFAULT '0',
  `date_active` int(11) DEFAULT '0',
  `b1` int(11) DEFAULT '0',
  `b3` int(11) DEFAULT '0',
  `b5` int(11) DEFAULT '0',
  `prelaunch_norif` int(1) DEFAULT '0',
  `alert_data` text /*!40101 COLLATE utf8_unicode_ci */,
  PRIMARY KEY (`member_id`),
  KEY `username_idx` (`username`),
  KEY `reg_date_idx` (`reg_date`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `members` VALUES(1, 'admin', '', 0, 0, 0, '21232f297a57a5a743894a0e4a801fc3', 'admin@admin.com', 'Admin', 'Admin', '', '', '', '', '', '', 1612781647, 1620410182, 1, 0, '', 0, 0, '168.167.26.133', '', 1, 0, 0, 0, 0, 0, 0, NULL);


DROP TABLE IF EXISTS messages;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `txid` varchar(64) DEFAULT NULL,
  `member_id` int(11) DEFAULT '0',
  `name_member_id` int(11) DEFAULT '0',
  `to_member_id` int(11) DEFAULT '0',
  `subject` varchar(512) DEFAULT '',
  `body` text,
  `date` int(11) DEFAULT '0',
  `attach` varchar(1024) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=95 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `messages` VALUES(63, '2ae67f3b83cac9772b8f90ec83090d9b', 1, 3, 3, 'My message', '', 1484636813, NULL, 0, 0);
INSERT INTO `messages` VALUES(55, '702641fc024fb873c69e6c4ef465f37f', 1, 2, 2, 'RE: 1&amp;gt;2', '', 1484393922, NULL, 0, 0);
INSERT INTO `messages` VALUES(56, '226786203465ecfa01815f44508bf620', 2, 1, 2, 'RE: 1&amp;gt;2', '', 1484393922, NULL, 1, 0);
INSERT INTO `messages` VALUES(61, 'dbac849aee88d6d73722aca3e628a5e0', 1, 2, 2, '1&amp;gt;2', '', 1484394819, '34351071.jpg', 1, 0);
INSERT INTO `messages` VALUES(62, '86a2fe69475e04648680e657a9b90230', 2, 1, 2, '1&amp;gt;2', '', 1484394819, '34351071.jpg', 0, 0);
INSERT INTO `messages` VALUES(58, '161b4820f922a8e6d24b60aa6beade52', 1, 2, 1, 'RE: 1&amp;gt;2', '', 1484394226, NULL, 1, 0);
INSERT INTO `messages` VALUES(53, '557547181d19b91977a666dd7dc66ece', 1, 2, 2, '1&amp;gt;2', '', 1484393874, NULL, 1, 0);
INSERT INTO `messages` VALUES(54, '0024c94a13756ba0d009676f718b1c95', 2, 1, 2, '1&amp;gt;2', '', 1484393874, NULL, 1, 0);
INSERT INTO `messages` VALUES(60, 'd2a8890edd87d09153813cb3dfede0f6', 1, 2, 1, 'RE: RE: 1&amp;gt;2', '', 1484394237, NULL, 1, 0);
INSERT INTO `messages` VALUES(93, '309fda9c60b55fa77413a7b2cebccd49', 1, 3, 3, 'RE: hi Attach', 'Glad to hear you', 1484739922, '34351071.jpg', 0, 0);
INSERT INTO `messages` VALUES(92, 'ee52c6c5f0632bce6871b5101680edcd', 3, 1, 3, 'RE: hi', 'Very nice picture', 1484739880, NULL, 1, 0);
INSERT INTO `messages` VALUES(66, '20d003dd105af52a3663b6e1074b3fd0', 1, 3, 1, 'RE: My message', 'cool', 1484636887, NULL, 1, 0);
INSERT INTO `messages` VALUES(68, 'e158a0c11918988030fd922d176db73b', 1, 3, 1, 'RE: My message', '', 1484733819, NULL, 1, 0);
INSERT INTO `messages` VALUES(91, '771866731bcc6272b50c9ef146643492', 1, 3, 3, 'RE: hi', 'Very nice picture', 1484739880, NULL, 0, 0);
INSERT INTO `messages` VALUES(70, '0b21805b1430fd673b40885d4451378c', 1, 3, 1, 'RE: My message', '', 1484733852, NULL, 1, 0);
INSERT INTO `messages` VALUES(90, 'ad6b204b25effcc5861dc68844820f78', 1, 3, 1, 'hi', 'Glad to hear you', 1484739762, 'test.jpg', 1, 0);
INSERT INTO `messages` VALUES(72, '7efe24f0528ab1bfe00ad786b370a486', 2, 3, 2, 'hi', 'ge', 1484734300, NULL, 1, 0);
INSERT INTO `messages` VALUES(73, '88e71544bda053f7ee04dfed8b8f4be0', 2, 3, 3, 'RE: hi', 'hi there', 1484734332, NULL, 1, 0);
INSERT INTO `messages` VALUES(89, '2d753264a84106a023d6ea04cdb507f4', 3, 1, 1, 'hi', 'Glad to hear you', 1484739762, 'test.jpg', 0, 0);
INSERT INTO `messages` VALUES(76, '46afefb7c81d8b17bbd8e9899dcec645', 2, 3, 2, 'RE: RE: hi', 'gfg', 1484734364, NULL, 0, 0);
INSERT INTO `messages` VALUES(88, '96381b1697c37a8fbc22ce740ef5ed80', 3, 1, 3, 'RE: Hi admin', 'Hi test1!\r\n\r\n\r\nhere is the text', 1484739732, NULL, 1, 0);
INSERT INTO `messages` VALUES(78, 'e3fe578f8090f3d8c19ca89d31278fd5', 2, 3, 2, 'RE: RE: RE: hi', 'gfg', 1484734375, 'Customer-support-girl-wearing-headsets.jpg', 1, 0);
INSERT INTO `messages` VALUES(79, 'd3523b72cea372b0f714b08d330c1129', 2, 3, 3, 'RE: RE: RE: RE: hi', 'cool', 1484734425, NULL, 1, 0);
INSERT INTO `messages` VALUES(87, 'b91c06674dec97604360c56a518d7c32', 1, 3, 3, 'RE: Hi admin', 'Hi test1!\r\n\r\n\r\nhere is the text', 1484739732, NULL, 0, 0);
INSERT INTO `messages` VALUES(81, '6b4c6bd48cac3a0b3084a997ba4c6f04', 2, 3, 3, 'RE: RE: RE: RE: hi', 'gfg', 1484734445, NULL, 0, 0);
INSERT INTO `messages` VALUES(86, '7ecec086abcf18ca40b0de83d975cdd3', 1, 3, 1, 'Hi admin', 'here is the text', 1484739706, NULL, 1, 0);
INSERT INTO `messages` VALUES(84, '4cec0832e9c93a2dcae15f05395de8c1', 2, 3, 2, 'RE: RE: RE: RE: RE: hi', 'gfg', 1484734473, NULL, 0, 0);
INSERT INTO `messages` VALUES(85, 'ec3fd10387bb3384833872accf616547', 3, 1, 1, 'Hi admin', 'here is the text', 1484739706, NULL, 0, 0);
INSERT INTO `messages` VALUES(94, 'b913cd81c94887855edad883075459a3', 3, 1, 3, 'RE: hi Attach', 'Glad to hear you', 1484739922, '34351071.jpg', 1, 0);


DROP TABLE IF EXISTS news;
CREATE TABLE `news` (
  `news_id` int(11) NOT NULL AUTO_INCREMENT,
  `news_date` int(11) NOT NULL DEFAULT '0',
  `title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `article` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `description` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `photo` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `destination` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`news_id`),
  KEY `news_date_idx` (`news_date`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS online_stats;
CREATE TABLE `online_stats` (
  `online_stat_id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `z_date` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`online_stat_id`),
  KEY `session_id_idx` (`session_id`),
  KEY `member_id_idx` (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1366 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `online_stats` VALUES(1363, '42d650c4a2c5796bddf0a8193d79df3f', 1, 1620737537);


DROP TABLE IF EXISTS pages;
CREATE TABLE `pages` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_index` int(5) NOT NULL DEFAULT '0',
  `title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `menu_title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `content` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `keywords` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `in_menu` tinyint(1) NOT NULL DEFAULT '0',
  `is_member` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `level1` tinyint(1) NOT NULL DEFAULT '0',
  `level2` tinyint(1) NOT NULL DEFAULT '0',
  `level3` tinyint(1) NOT NULL DEFAULT '0',
  `level4` tinyint(1) NOT NULL DEFAULT '0',
  `level5` tinyint(1) NOT NULL DEFAULT '0',
  `level6` tinyint(1) NOT NULL DEFAULT '0',
  `level7` tinyint(1) NOT NULL DEFAULT '0',
  `level8` tinyint(1) NOT NULL DEFAULT '0',
  `level9` tinyint(1) NOT NULL DEFAULT '0',
  `level10` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`page_id`),
  KEY `order_index_idx` (`order_index`)
) ENGINE=MyISAM AUTO_INCREMENT=10 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `pages` VALUES(1, 1, 'Start Page', 'Home', '&lt;div style=\"text-align: left;\"&gt;&lt;strong&gt;&lt;span style=\"font-size: 18pt;\"&gt;&lt;img src=\"/uploads/image/indexman.jpg\" width=\"466\" height=\"411\" align=\"left\" alt=\"\" /&gt;COMING SOON&lt;/span&gt;&lt;/strong&gt;&lt;/div&gt;', '', '', 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `pages` VALUES(2, 1, 'Terms and Conditions', 'Terms and Conditions', 'Coming Soon...', '', '', 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);


DROP TABLE IF EXISTS payins;
CREATE TABLE `payins` (
  `payins_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `transaction_id` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `processor` varchar(100) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `z_date` int(11) NOT NULL DEFAULT '0',
  `product_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`payins_id`),
  KEY `transaction_id_idx` (`transaction_id`),
  KEY `member_id_idx` (`member_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS payins_log;
CREATE TABLE `payins_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data` text /*!40101 COLLATE utf8_unicode_ci */,
  `processor` varchar(100) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `z_date` int(11) DEFAULT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS places;
CREATE TABLE `places` (
  `place_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT '0',
  `referrer_place_id` int(11) DEFAULT '0',
  `m_level` int(11) DEFAULT '0',
  `reentry` int(5) NOT NULL DEFAULT '0',
  `z_date` int(11) DEFAULT '0',
  `cl` int(11) DEFAULT '0',
  PRIMARY KEY (`place_id`),
  KEY `member_id_idx` (`member_id`),
  KEY `referrer_place_id_idx` (`referrer_place_id`),
  KEY `cl` (`cl`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `places` VALUES(1, 1, 0, 1, 1, 1620737498, 0);


DROP TABLE IF EXISTS processors;
CREATE TABLE `processors` (
  `processor_id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `name` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `account_id` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `routine_url` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `extra_field` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `fee` decimal(12,2) NOT NULL DEFAULT '0.00',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`processor_id`),
  KEY `code_idx` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=13 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `processors` VALUES(3, 'alertpay', 'Payza', '', 'https://secure.payza.com/checkout', '', '0.00', 0);
INSERT INTO `processors` VALUES(5, 'solidtrustpay', 'Solid Trust Pay', '', 'https://solidtrustpay.com/handle.php', '', '0.00', 0);
INSERT INTO `processors` VALUES(8, 'paypal', 'PayPal', '', 'https://www.paypal.com/cgi-bin/webscr', '', '0.00', 0);
INSERT INTO `processors` VALUES(9, 'perfectmoney', 'PerfectMoney', '', 'https://perfectmoney.is/api/step1.asp', '', '0.00', 0);
INSERT INTO `processors` VALUES(10, 'egopay', 'EgoPay', '', 'https://www.egopay.com/payments/pay/form', '', '0.00', 0);
INSERT INTO `processors` VALUES(7, 'okpay', 'OkPay', '', 'https://www.okpay.com/process.html', '', '0.00', 0);
INSERT INTO `processors` VALUES(12, 'coinpayments', 'Cryptocurrency', 'ff5af747ad2f36c69f6ba88f39ceff3e', 'https://www.coinpayments.net/index.php', 'j43LUXwjh1CErgM1', '0.00', 1);


DROP TABLE IF EXISTS products;
CREATE TABLE `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `file` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `photo` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_id`),
  KEY `price_idx` (`price`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS ptools;
CREATE TABLE `ptools` (
  `ptool_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `link` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `photo` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ptool_id`),
  KEY `title_idx` (`title`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS pub_ticket_messages;
CREATE TABLE `pub_ticket_messages` (
  `pub_ticket_message_id` int(11) NOT NULL AUTO_INCREMENT,
  `pub_ticket_id` int(11) NOT NULL DEFAULT '0',
  `support_message` tinyint(1) NOT NULL DEFAULT '0',
  `message` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `date_post` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pub_ticket_message_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS pub_tickets;
CREATE TABLE `pub_tickets` (
  `pub_ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `last_name` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `email` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `ticket_code` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `subject` varchar(150) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `date_create` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`pub_ticket_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS replicas;
CREATE TABLE `replicas` (
  `replica_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_index` int(11) NOT NULL DEFAULT '0',
  `member_id` int(5) NOT NULL DEFAULT '0',
  `title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `menu_title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `content` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`replica_id`),
  KEY `member_id_idx` (`member_id`),
  KEY `order_index_idx` (`order_index`)
) ENGINE=MyISAM AUTO_INCREMENT=8 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `replicas` VALUES(6, 1, 1, 'test', 'PDF', '&lt;p&gt;&amp;nbsp;кен&lt;/p&gt;', 1);
INSERT INTO `replicas` VALUES(5, 1, 5, 'my page', 'my page', '&lt;p&gt;&amp;nbsp;my page&lt;/p&gt;', 1);
INSERT INTO `replicas` VALUES(7, 1, 2, 'My Page', 'My Page', '&lt;p&gt;text here&amp;nbsp;&lt;/p&gt;', 1);


DROP TABLE IF EXISTS selected;
CREATE TABLE `selected` (
  `selected_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`selected_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `selected` VALUES(2, 1);


DROP TABLE IF EXISTS settings;
CREATE TABLE `settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `keyname` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `value` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`setting_id`),
  KEY `key1` (`keyname`)
) ENGINE=MyISAM AUTO_INCREMENT=72 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `settings` VALUES(1, 'AdminUsername', 'admin');
INSERT INTO `settings` VALUES(2, 'AdminPassword', 'fc93f0a8fa5c3527b8d0ad486df7e6e3');
INSERT INTO `settings` VALUES(3, 'AdminAltPassword', '21232f297a57a5a743894a0e4a801fc3');
INSERT INTO `settings` VALUES(4, 'SiteTitle', 'prod millionairescircle.club');
INSERT INTO `settings` VALUES(5, 'SiteUrl', 'http://millionairescircle.club/');
INSERT INTO `settings` VALUES(6, 'PathSite', '/home4/wellwis5/public_html/millionairescircle/');
INSERT INTO `settings` VALUES(7, 'ContactEmail', 'support@runmlm.com');
INSERT INTO `settings` VALUES(8, 'UseSMTPAutorisation', '0');
INSERT INTO `settings` VALUES(9, 'SMTPServer', 'SMTPServer');
INSERT INTO `settings` VALUES(10, 'SMTPDomain', 'SMTPDomain');
INSERT INTO `settings` VALUES(11, 'SMTPUserName', 'SMTPUserName');
INSERT INTO `settings` VALUES(12, 'SMTPPassword', 'SMTPPassword');
INSERT INTO `settings` VALUES(13, 'SecurityMode', '');
INSERT INTO `settings` VALUES(14, 'IPAddress', '');
INSERT INTO `settings` VALUES(15, 'pin_code', '');
INSERT INTO `settings` VALUES(16, 'PaymentMode', '');
INSERT INTO `settings` VALUES(17, 'PaymentModeDate', '0');
INSERT INTO `settings` VALUES(18, 'payPeriod', '7');
INSERT INTO `settings` VALUES(19, 'monthPeriod', '999');
INSERT INTO `settings` VALUES(20, 'LastCronjobStart', '0');
INSERT INTO `settings` VALUES(21, 'MinCashOut', '0.00');
INSERT INTO `settings` VALUES(22, 'warnPeriod', '5');
INSERT INTO `settings` VALUES(23, 'matrix_mode', '2');
INSERT INTO `settings` VALUES(24, 'fee', '5.00');
INSERT INTO `settings` VALUES(25, 'PhotoBigMaxWidth', '400');
INSERT INTO `settings` VALUES(26, 'PhotoBigMaxHeight', '400');
INSERT INTO `settings` VALUES(27, 'PhotoSmallMaxWidth', '120');
INSERT INTO `settings` VALUES(28, 'PhotoSmallMaxHeight', '120');
INSERT INTO `settings` VALUES(29, 'cycling', '1');
INSERT INTO `settings` VALUES(30, 'sponsor_amount', '0.00');
INSERT INTO `settings` VALUES(31, 'sponsor_quant', '1');
INSERT INTO `settings` VALUES(32, 'product', 'Product');
INSERT INTO `settings` VALUES(33, 'subjectMail', 'Welcome to [SiteTitle]');
INSERT INTO `settings` VALUES(34, 'messageMail', 'Dear [FirstName] [LastName], \r\n\r\nSome message with tags.\r\n\r\nRegards,\r\n[SiteTitle]');
INSERT INTO `settings` VALUES(35, 'is_replica', '1');
INSERT INTO `settings` VALUES(36, 'quant_replica', '1');
INSERT INTO `settings` VALUES(37, 'SerialCode', '6QK5-TPW2-OL6E-FF44');
INSERT INTO `settings` VALUES(38, 'StartDate', '1620737372');
INSERT INTO `settings` VALUES(39, 'AdminMessage', '');
INSERT INTO `settings` VALUES(40, 'useBanners', '0');
INSERT INTO `settings` VALUES(41, 'useBalance', '0');
INSERT INTO `settings` VALUES(42, 'useSecureMembers', '0');
INSERT INTO `settings` VALUES(43, 'useFoneMailing', '0');
INSERT INTO `settings` VALUES(44, 'useAutoresponder', '0');
INSERT INTO `settings` VALUES(45, 'useEshop', '0');
INSERT INTO `settings` VALUES(46, 'useValidation', '0');
INSERT INTO `settings` VALUES(47, 'quant_textadds', '0');
INSERT INTO `settings` VALUES(48, 'quant_textadds_show', '0');
INSERT INTO `settings` VALUES(49, 'quant_textadds_show_m', '0');
INSERT INTO `settings` VALUES(50, 'number_turing', '0');
INSERT INTO `settings` VALUES(51, 'payp_fromcash', '0');
INSERT INTO `settings` VALUES(52, 'is_pif', '0');
INSERT INTO `settings` VALUES(53, 'is_pif_cash', '0');
INSERT INTO `settings` VALUES(54, 'is_random', '1');
INSERT INTO `settings` VALUES(55, 'currency', '1');
INSERT INTO `settings` VALUES(56, 'ReferrerUrl', 'username');
INSERT INTO `settings` VALUES(57, 'FooterContent', 'Copyright © 2016. Powered by <a href=\"http://runmlm.com/\">MLM Builder Script</a>');
INSERT INTO `settings` VALUES(58, 'LicenseNumber', 'miU1RBTkRBUkQ=');
INSERT INTO `settings` VALUES(59, 'access', 'YYTo1Mjp7czo1OiJsYW5kcyI7YTo0OntzOjU6InRpdGxlIjtzOjEzOiJMYW5kaW5nIHBhZ2VzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NDoic3RhdCI7YTo0OntzOjU6InRpdGxlIjtzOjk6IkRhc2hib2FyZCI7czo0OiJGUkVFIjtpOjA7czo3OiJTVEFSVEVSIjtpOjA7czo4OiJTVEFOREFSRCI7aToxO31zOjExOiJtZW1iX21hdHJpeCI7YTo0OntzOjU6InRpdGxlIjtzOjEyOiJPdmVyYWxsIFRyZWUiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMToidXNlcl9hZG1pbnMiO2E6NTp7czo1OiJ0aXRsZSI7czoxNDoiQWRtaW5pc3RyYXRvcnMiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTtzOjY6ImFjY2VzcyI7aToxO31zOjY6Im1hbnVhbCI7YTo0OntzOjU6InRpdGxlIjtzOjE1OiJNYW51YWwgUGF5bWVudHMiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo1OiJwYWdlcyI7YTo1OntzOjU6InRpdGxlIjtzOjEyOiJQdWJsaWMgUGFnZXMiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTtzOjY6ImFjY2VzcyI7aToxO31zOjc6Im1fcGFnZXMiO2E6NDp7czo1OiJ0aXRsZSI7czoxMjoiTWVtYmVyIFBhZ2VzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NDoibmV3cyI7YTo0OntzOjU6InRpdGxlIjtzOjQ6Ik5ld3MiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo3OiJhcHRvb2xzIjthOjQ6e3M6NToidGl0bGUiO3M6MTM6IkFkbWluIGJhbm5lcnMiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxNToiYXV0b3Jlc3BvbmRlcnNmIjthOjQ6e3M6NToidGl0bGUiO3M6MzA6IkluYWN0aXZlIE1lbWJlcnMgQXV0b3Jlc3BvbmRlciI7czo0OiJGUkVFIjtpOjA7czo3OiJTVEFSVEVSIjtpOjA7czo4OiJTVEFOREFSRCI7aToxO31zOjE0OiJhdXRvcmVzcG9uZGVycyI7YTo0OntzOjU6InRpdGxlIjtzOjI5OiJBY3RpdmUgTWVtYmVycyBBdXRvcmVzcG9uZGVyICI7czo0OiJGUkVFIjtpOjA7czo3OiJTVEFSVEVSIjtpOjA7czo4OiJTVEFOREFSRCI7aToxO31zOjEwOiJhdGVtcGxhdGVzIjthOjQ6e3M6NToidGl0bGUiO3M6MjM6Ik1hc3MgTWFpbGluZyBUZW1wbGF0ZXMgIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NzoibWFpbGluZyI7YTo0OntzOjU6InRpdGxlIjtzOjE1OiJTZW5kIE1hc3MgRW1haWwiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo2OiJiYWNrdXAiO2E6NDp7czo1OiJ0aXRsZSI7czo3OiJCYWNrdXBzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTM6InVzZVZhbGlkYXRpb24iO2E6NDp7czo1OiJ0aXRsZSI7czowOiIiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo2OiJpc19waWYiO2E6NDp7czo1OiJ0aXRsZSI7czowOiIiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMToiaXNfcGlmX2Nhc2giO2E6NDp7czo1OiJ0aXRsZSI7czowOiIiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czozOiJmYXEiO2E6NDp7czo1OiJ0aXRsZSI7czozOiJGQVEiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo2OiJwdG9vbHMiO2E6NDp7czo1OiJ0aXRsZSI7czoxNToiTWVtYmVycyBCYW5uZXJzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTA6ImlzX3JlcGxpY2EiO2E6NDp7czo1OiJ0aXRsZSI7czoxNjoiUmVwbGljYXRlZCBTaXRlcyI7czo0OiJGUkVFIjtpOjA7czo3OiJTVEFSVEVSIjtpOjA7czo4OiJTVEFOREFSRCI7aToxO31zOjEzOiJxdWFudF9yZXBsaWNhIjthOjQ6e3M6NToidGl0bGUiO3M6MDoiIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NzoidGlja2V0cyI7YTo0OntzOjU6InRpdGxlIjtzOjE5OiJTdXBwb3J0IGZvciBtZW1iZXJzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTE6InB1Yl90aWNrZXRzIjthOjQ6e3M6NToidGl0bGUiO3M6MjA6IlN1cHBvcnQgZm9yIHZpc2l0b3JzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTA6ImNhdGVnb3JpZXMiO2E6NDp7czo1OiJ0aXRsZSI7czoxNzoiRXNob3AgQ2F0ZWdvcmllcyAiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo4OiJwcm9kdWN0cyI7YTo0OntzOjU6InRpdGxlIjtzOjE1OiJFc2hvcCBQcm9kdWN0cyAiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo5OiJzaG9wX2ZlZXMiO2E6NDp7czo1OiJ0aXRsZSI7czoxMToiRXNob3AgRmVlcyAiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMzoidHVyaW5nX251bWJlciI7YTo0OntzOjU6InRpdGxlIjtzOjA6IiI7czo0OiJGUkVFIjtpOjA7czo3OiJTVEFSVEVSIjtpOjA7czo4OiJTVEFOREFSRCI7aToxO31zOjg6ImN1cnJlbmN5IjthOjQ6e3M6NToidGl0bGUiO3M6MDoiIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTM6InBheXBfZnJvbWNhc2giO2E6NDp7czo1OiJ0aXRsZSI7czowOiIiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMToidHJlZV9tYXRyaXgiO2E6NDp7czo1OiJ0aXRsZSI7czowOiIiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxNzoidGVtcGxhdGVfZWxlbWVudHMiO2E6NDp7czo1OiJ0aXRsZSI7czoxNzoiVGVtcGxhdGUgRWxlbWVudHMiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo1OiJsb2dpbiI7YTo0OntzOjU6InRpdGxlIjtzOjEwOiJMb2dpbiBmb3JtIjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NzoibWVtYmVycyI7YTo0OntzOjU6InRpdGxlIjtzOjExOiJNZW1iZXIgbGlzdCI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjEyOiJhZG1pbmRldGFpbHMiO2E6NDp7czo1OiJ0aXRsZSI7czoxMjoiYWRtaW5kZXRhaWxzIjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6ODoic2V0dGluZ3MiO2E6NDp7czo1OiJ0aXRsZSI7czo4OiJzZXR0aW5ncyI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjg6Im1hdHJpeGVzIjthOjQ6e3M6NToidGl0bGUiO3M6ODoibWF0cml4ZXMiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo2OiJsZXZlbHMiO2E6NDp7czo1OiJ0aXRsZSI7czo2OiJsZXZlbHMiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMzoibGV2ZWxzX2ZvcmNlZCI7YTo0OntzOjU6InRpdGxlIjtzOjEzOiJsZXZlbHNfZm9yY2VkIjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NjoiYWRtaW5zIjthOjQ6e3M6NToidGl0bGUiO3M6NjoiYWRtaW5zIjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NzoicGF5bWVudCI7YTo0OntzOjU6InRpdGxlIjtzOjc6InBheW1lbnQiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo0OiJjYXNoIjthOjQ6e3M6NToidGl0bGUiO3M6NDoiY2FzaCI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjg6ImNhc2hfb3V0IjthOjQ6e3M6NToidGl0bGUiO3M6ODoiY2FzaF9vdXQiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMDoicHJvY2Vzc29ycyI7YTo0OntzOjU6InRpdGxlIjtzOjEwOiJwcm9jZXNzb3JzIjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NDoidGFkcyI7YTo0OntzOjU6InRpdGxlIjtzOjQ6InRhZHMiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo5OiJ0ZW1wbGF0ZXMiO2E6NDp7czo1OiJ0aXRsZSI7czo5OiJ0ZW1wbGF0ZXMiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo0OiJmZWVzIjthOjQ6e3M6NToidGl0bGUiO3M6NDoiZmVlcyI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjg6Im1fbGV2ZWxzIjthOjQ6e3M6NToidGl0bGUiO3M6ODoibV9sZXZlbHMiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMzoiZm9yY2VkX21hdHJpeCI7YTo0OntzOjU6InRpdGxlIjtzOjEzOiJmb3JjZWRfbWF0cml4IjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTI6InJlcGxpY2Ffc2l0ZSI7YTo0OntzOjU6InRpdGxlIjtzOjEyOiJyZXBsaWNhX3NpdGUiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo3OiJzaG9wZmVlIjthOjQ6e3M6NToidGl0bGUiO3M6Nzoic2hvcGZlZSI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjE0OiJ1cGxvYWRfbWVtYmVycyI7YTo0OntzOjU6InRpdGxlIjtzOjE0OiJ1cGxvYWRfbWVtYmVycyI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjY6InNsaWRlciI7YTo0OntzOjU6InRpdGxlIjtzOjY6InNsaWRlciI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO319');
INSERT INTO `settings` VALUES(60, 'Commissions_Value', '1');
INSERT INTO `settings` VALUES(61, 'PRE_LAUNCH', '0');
INSERT INTO `settings` VALUES(62, 'PRE_LAUNCH_DATE', '0');
INSERT INTO `settings` VALUES(63, 'matching_bonus', '0');
INSERT INTO `settings` VALUES(64, 'matching_bonus_value', '0');
INSERT INTO `settings` VALUES(65, 'time_after_launch', '36');
INSERT INTO `settings` VALUES(66, 'Carousel_autoplayTimeout', '3000');
INSERT INTO `settings` VALUES(67, 'SPONSOR_VALUE', '2');
INSERT INTO `settings` VALUES(70, 'WITHDRAWAL_VALUE', '2');
INSERT INTO `settings` VALUES(71, 'currency_rate', '0.00014613');


DROP TABLE IF EXISTS shop_fees;
CREATE TABLE `shop_fees` (
  `fee_id` int(11) NOT NULL AUTO_INCREMENT,
  `to_order_index` int(11) NOT NULL DEFAULT '0',
  `plevel` int(3) NOT NULL DEFAULT '0',
  `fee_member` decimal(12,2) NOT NULL DEFAULT '0.00',
  `fee_sponsor` decimal(12,2) NOT NULL DEFAULT '0.00',
  `from_order_index` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fee_id`),
  KEY `to_order_index_idx` (`to_order_index`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS slider;
CREATE TABLE `slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `image` varchar(64) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `slider` VALUES(6, '', '0r4i1rsax4t4u1ttqjd1.png');
INSERT INTO `slider` VALUES(7, '', 'cq345v2pzhkxqi2b42iw.png');
INSERT INTO `slider` VALUES(8, '', '1lcwaw0djokgzoiknrxg.png');


DROP TABLE IF EXISTS sn_messages;
CREATE TABLE `sn_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subj` varchar(256) NOT NULL,
  `mess` text NOT NULL,
  `date` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=91 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `sn_messages` VALUES(5, '13245 2345 2345', '2345 2345 2345', 1337226509);
INSERT INTO `sn_messages` VALUES(6, '3465', '&lt;br&gt;3563 456 34563456 3456 3456', 1337231899);
INSERT INTO `sn_messages` VALUES(7, 'Re: 3465', '568&lt;br&gt;', 1337241214);
INSERT INTO `sn_messages` VALUES(20, 'Re: Re: 3465', 'sdfg sdfg&lt;div&gt;s&lt;/div&gt;&lt;div&gt;&lt;b&gt;sdfgsdfg&lt;i&gt;sdfgsdfgsdfg&lt;/i&gt;&lt;/b&gt;&lt;/div&gt;', 1337310463);
INSERT INTO `sn_messages` VALUES(9, 'Re: 3465', '2345', 1337241586);
INSERT INTO `sn_messages` VALUES(10, 'Re: 3465', 'rtyurtyu', 1337241614);
INSERT INTO `sn_messages` VALUES(11, 'Re: 3465', 'ghjkghjkghjkghjkghjkuio', 1337241760);
INSERT INTO `sn_messages` VALUES(12, 'Re: 3465', 'С‹РІР°Рї С‹РІ&lt;strong&gt;С‹РІР°РїС‹РІР°Рї&lt;/strong&gt;', 1337242022);
INSERT INTO `sn_messages` VALUES(13, 'Re: 3465', '&lt;p&gt;asd&lt;strong&gt;asdasd&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;&lt;br&gt;&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;dd&lt;em&gt;dd&lt;/em&gt;&lt;br&gt;&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;&lt;em&gt;&lt;br&gt;&lt;/em&gt;&lt;/strong&gt;&lt;/p&gt;', 1337242392);
INSERT INTO `sn_messages` VALUES(14, 'Re: 3465', '&lt;p&gt;sdfg&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;sdfgsdf&lt;/strong&gt;&lt;/p&gt;', 1337242418);
INSERT INTO `sn_messages` VALUES(16, 'Re: 3465', '&lt;p&gt;hi &lt;/p&gt;&lt;p&gt;&lt;strong&gt;!!ept&lt;/strong&gt;&lt;br&gt;&lt;/p&gt;', 1337244713);
INSERT INTO `sn_messages` VALUES(17, 'Re: 13245 2345 2345', '&lt;br&gt;tyuityui', 1337244967);
INSERT INTO `sn_messages` VALUES(21, 'Re: Re: 3465', 'dfhdfgh', 1337310545);
INSERT INTO `sn_messages` VALUES(22, 'tyuityui', 'tyui,tyuityutyui &amp;nbsp;ui', 1337311399);
INSERT INTO `sn_messages` VALUES(23, '45674567', '456 4567 4567 4567 4567', 1337311474);
INSERT INTO `sn_messages` VALUES(24, 'tyuityui', 'tyui,tyuityutyui &amp;nbsp;ui', 1337311760);
INSERT INTO `sn_messages` VALUES(25, 'Hi!', '&lt;p&gt;Hello!&lt;/p&gt;&lt;p&gt;How are you?&lt;/p&gt;', 1337312357);
INSERT INTO `sn_messages` VALUES(26, 'Re: Hi!', 'Hi Alex. Great! Please answer this message asap', 1337321801);
INSERT INTO `sn_messages` VALUES(27, 'Re: Re: Hi!', 'hello&lt;br&gt;', 1337321962);
INSERT INTO `sn_messages` VALUES(28, 'Re: Re: Hi!', 'I read your message.&lt;br&gt;', 1337322089);
INSERT INTO `sn_messages` VALUES(29, '222', '22222qwe rqwer&amp;nbsp;', 1337322601);
INSERT INTO `sn_messages` VALUES(30, 'I do it', 'it&#039;s ready', 1337322679);
INSERT INTO `sn_messages` VALUES(31, 'Re: I do it', '&lt;ul&gt;&lt;ul&gt;&lt;li&gt;&lt;u&gt;&lt;b&gt;ah@et&#039;&lt;/b&gt;&lt;/u&gt;&lt;/li&gt;&lt;/ul&gt;&lt;ol&gt;&lt;ol&gt;&lt;li&gt;&lt;b&gt;&lt;u&gt;1&lt;i&gt;&amp;nbsp;ggg&lt;/i&gt;&lt;/u&gt;&lt;/b&gt;&lt;/li&gt;&lt;/ol&gt;&lt;li&gt;&lt;b&gt;&lt;u&gt;&lt;br&gt;&lt;/u&gt;&lt;/b&gt;&lt;/li&gt;&lt;/ol&gt;&lt;/ul&gt;', 1337326023);
INSERT INTO `sn_messages` VALUES(32, 'Re: 222', 'rtyurtyu&lt;br&gt;', 1337341143);
INSERT INTO `sn_messages` VALUES(33, 'Re: 222', 'rtyurtyuuuu&lt;br&gt;', 1337341155);
INSERT INTO `sn_messages` VALUES(34, 'Counter is ready', 'You can see it.', 1337341742);
INSERT INTO `sn_messages` VALUES(35, 'Test Message', 'Testing one, two, three.', 1337341962);
INSERT INTO `sn_messages` VALUES(36, 'Re: Test Message', 'Roger', 1337342036);
INSERT INTO `sn_messages` VALUES(37, 'asdffff', 'asdf', 1338184196);
INSERT INTO `sn_messages` VALUES(42, '', '&lt;br&gt;', 1339238821);
INSERT INTO `sn_messages` VALUES(39, '785678', '65785&lt;br&gt;', 1338200571);
INSERT INTO `sn_messages` VALUES(40, 'Wow', '&lt;b style=\"color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans; font-size: 11px; line-height: 14px; \"&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pharetra ullamcorper eros, id viverra nulla consequat sit amet. Mauris malesuada magna quis sem dapibus ut iaculis ipsum pretium. Cras id augue non elit pulvinar auctor. Proin aliquet cursus pharetra. Proin ullamcorper dolor vel leo luctus gravida euismod neque blandit. Aliquam dolor sapien, tincidunt eu imperdiet nec, viverra ut sapien. Aliquam ornare eros lobortis dolor blandit nec placerat leo dictum. Sed eu nibh tellus, et venenatis justo.&lt;/b&gt;', 1338879831);
INSERT INTO `sn_messages` VALUES(41, 'Wow', 'Superb', 1338881761);
INSERT INTO `sn_messages` VALUES(43, '12341234', '1234123&lt;br&gt;', 1340875730);
INSERT INTO `sn_messages` VALUES(44, 'jjjj', 'jjjj', 1340875739);
INSERT INTO `sn_messages` VALUES(45, '', '&lt;br&gt;', 1344941692);
INSERT INTO `sn_messages` VALUES(46, 'test', 'hello!', 1349437588);
INSERT INTO `sn_messages` VALUES(47, 'Subject', 'hello', 1349441558);
INSERT INTO `sn_messages` VALUES(48, '12', '12', 1349441689);
INSERT INTO `sn_messages` VALUES(49, 'regs', 'sdfgsdfg', 1350033139);
INSERT INTO `sn_messages` VALUES(50, 'xdfb', 'dfbsxf', 1350033207);
INSERT INTO `sn_messages` VALUES(51, 'q12341', '12qwerqwev rfwef qwe fq', 1350033338);
INSERT INTO `sn_messages` VALUES(52, 'test', 'xfgsdfgsdfgs', 1351162018);
INSERT INTO `sn_messages` VALUES(53, '11111', '11111111111', 1351164691);
INSERT INTO `sn_messages` VALUES(54, 'mess 1', 'mess 1 mess 1 mess 1 mess 1 mess 1 mess 1 mess 1 mess 1 mess 1', 1351233383);
INSERT INTO `sn_messages` VALUES(55, 'Re: mess 1', '', 1351235710);
INSERT INTO `sn_messages` VALUES(56, 'Re: mess 1', '', 1354525981);
INSERT INTO `sn_messages` VALUES(57, 'Re: Sent test4', '', 1354526046);
INSERT INTO `sn_messages` VALUES(58, 'Re: mess 1', '', 1354526146);
INSERT INTO `sn_messages` VALUES(59, 'Re: Re: mess 1', '111111111', 1354526450);
INSERT INTO `sn_messages` VALUES(60, 'Re: LikedВ В  one video-upload', '22222222', 1354526491);
INSERT INTO `sn_messages` VALUES(61, 'test tes tes', 'nvchrd6tfi876tfc iuy ygooy yugou g', 1354546965);
INSERT INTO `sn_messages` VALUES(62, '111111111', '2222222222222', 1354630305);
INSERT INTO `sn_messages` VALUES(63, '1111111', '2222222222fdddddddddd', 1354630565);
INSERT INTO `sn_messages` VALUES(64, '111111111', 'qqqqqqqqqqqqqqqqqqqqqqqq', 1356615168);
INSERT INTO `sn_messages` VALUES(65, 'Re: 111111111', '222222222222222', 1356615219);
INSERT INTO `sn_messages` VALUES(66, 'sdf', 'vgc', 1356615824);
INSERT INTO `sn_messages` VALUES(67, 'sdsd', 'sxdcssssssssss', 1356616090);
INSERT INTO `sn_messages` VALUES(68, '12121', 'sdg bsdg sdfgs fdg sd', 1358770558);
INSERT INTO `sn_messages` VALUES(69, '32323232', 'zdcv fg sfgzsfdgzs zsd', 1358770573);
INSERT INTO `sn_messages` VALUES(70, '111111', '11111111111111111111111', 1359462966);
INSERT INTO `sn_messages` VALUES(71, 'wer', 'weawdfsfds gsfd gsrg', 1365151361);
INSERT INTO `sn_messages` VALUES(72, 'wer', 'weawdfsfds gsfd gsrg', 1365151375);
INSERT INTO `sn_messages` VALUES(73, 'wer', 'weawdfsfds gsfd gsrg', 1365151380);
INSERT INTO `sn_messages` VALUES(74, 'wer', 'weawdfsfds gsfd gsrg', 1365151384);
INSERT INTO `sn_messages` VALUES(75, 'wer', 'weawdfsfds gsfd gsrg', 1365151721);
INSERT INTO `sn_messages` VALUES(76, 'wer', 'weawdfsfds gsfd gsrg', 1365151726);
INSERT INTO `sn_messages` VALUES(77, 'wer', 'weawdfsfds gsfd gsrg', 1365151730);
INSERT INTO `sn_messages` VALUES(78, 'wer', 'weawdfsfds gsfd gsrg', 1365151734);
INSERT INTO `sn_messages` VALUES(79, 'wer', 'weawdfsfds gsfd gsrg', 1365151738);
INSERT INTO `sn_messages` VALUES(80, 'Message from Chat', 'test message from chat', 1365156329);
INSERT INTO `sn_messages` VALUES(81, 'Message from Chat', 'jhgf', 1365497664);
INSERT INTO `sn_messages` VALUES(82, 'Message from Chat', 'jhgf', 1365497669);
INSERT INTO `sn_messages` VALUES(83, 'Message from Chat', 'jhgf', 1365497672);
INSERT INTO `sn_messages` VALUES(84, 'Message from Chat', 'jhgf', 1365497697);
INSERT INTO `sn_messages` VALUES(85, 'Message from Chat', 'jhgf', 1365497699);
INSERT INTO `sn_messages` VALUES(86, 'Message from Chat', 'jhgf', 1365497700);
INSERT INTO `sn_messages` VALUES(87, 'Message from Chat', 'jhgf', 1365497700);
INSERT INTO `sn_messages` VALUES(88, 'Message from Chat', 'sdfghjmk,', 1365503856);
INSERT INTO `sn_messages` VALUES(89, 'Message from Chat', ',mnhb', 1365503916);
INSERT INTO `sn_messages` VALUES(90, 'Message from Chat', ',mnhb', 1365503918);


DROP TABLE IF EXISTS sn_messages_mem;
CREATE TABLE `sn_messages_mem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mess_id` int(11) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `from_member_id` int(11) NOT NULL DEFAULT '0',
  `to_member_id` int(11) NOT NULL DEFAULT '0',
  `read_mark` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=275 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `sn_messages_mem` VALUES(14, 5, 1, 2, 1, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(13, 5, 1606, 1606, 15, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(12, 5, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(11, 5, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(10, 5, 1607, 1606, 1607, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(9, 5, 1606, 1606, 1607, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(15, 6, 1650, 1650, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(41, 21, 1650, 1650, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(40, 20, 1606, 1650, 1606, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(39, 20, 1650, 1650, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(19, 9, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(20, 9, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(21, 10, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(22, 10, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(23, 11, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(24, 11, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(25, 12, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(26, 12, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(27, 13, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(28, 13, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(29, 14, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(30, 14, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(31, 16, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(32, 16, 1650, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(33, 17, 1650, 1650, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(34, 17, 1606, 1650, 1606, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(42, 21, 1606, 1650, 1606, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(43, 22, 1606, 1606, 1650, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(44, 22, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(45, 23, 1606, 1606, 1611, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(46, 23, 1611, 1606, 1611, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(47, 24, 1606, 1606, 1611, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(48, 24, 1611, 1606, 1611, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(49, 25, 1606, 1606, 512, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(58, 29, 1606, 1611, 1606, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(51, 26, 512, 512, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(52, 26, 1606, 512, 1606, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(53, 27, 1606, 1606, 512, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(57, 29, 1611, 1611, 1606, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(55, 28, 1606, 1606, 512, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(56, 28, 512, 1606, 512, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(59, 30, 1606, 1606, 512, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(60, 30, 512, 1606, 512, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(61, 31, 512, 512, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(62, 31, 1606, 512, 1606, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(63, 32, 1606, 1606, 1611, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(64, 32, 1611, 1606, 1611, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(65, 33, 1606, 1606, 1611, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(66, 33, 1611, 1606, 1611, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(67, 34, 1606, 1606, 512, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(68, 34, 512, 1606, 512, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(69, 35, 2614, 2614, 512, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(70, 35, 512, 2614, 512, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(71, 36, 512, 512, 2614, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(72, 36, 2614, 512, 2614, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(73, 37, 1611, 1611, 1606, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(74, 37, 1606, 1611, 1606, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(83, 42, 1606, 1606, 2606, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(84, 42, 2606, 1606, 2606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(77, 39, 1606, 1606, 1606, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(78, 39, 1606, 1606, 1606, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(79, 40, 512, 512, 512, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(80, 40, 512, 512, 512, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(81, 41, 1, 1, 512, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(82, 41, 512, 1, 512, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(85, 43, 1606, 1606, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(86, 43, 1606, 1606, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(87, 44, 1606, 1606, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(88, 44, 1606, 1606, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(89, 47, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(90, 47, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(117, 61, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(92, 48, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(93, 49, 2674, 2674, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(94, 49, 2674, 2674, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(95, 50, 2674, 2674, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(96, 50, 2674, 2674, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(97, 51, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(98, 51, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(99, 52, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(100, 52, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(101, 53, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(102, 53, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(103, 54, 2676, 2676, 2674, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(104, 54, 2674, 2676, 2674, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(105, 55, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(106, 55, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(107, 56, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(108, 56, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(109, 57, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(110, 57, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(111, 58, 2674, 2674, 2676, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(112, 58, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(113, 59, 2676, 2676, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(114, 59, 2674, 2676, 2674, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(115, 60, 2676, 2676, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(116, 60, 2674, 2676, 2674, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(118, 61, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(119, 62, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(120, 62, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(121, 62, 2674, 2674, 2641, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(122, 62, 2641, 2674, 2641, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(123, 63, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(124, 63, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(125, 64, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(126, 64, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(127, 65, 2676, 2676, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(128, 65, 2674, 2676, 2674, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(129, 68, 2676, 2676, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(130, 68, 2674, 2676, 2674, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(131, 69, 2676, 2676, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(132, 69, 2674, 2676, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(133, 70, 2674, 2674, 1, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(134, 70, 1, 2674, 1, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(135, 73, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(136, 73, 2700, 2703, 2700, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(137, 74, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(138, 74, 2700, 2703, 2700, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(139, 0, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(140, 0, 2700, 2703, 2700, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(141, 0, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(142, 0, 2700, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(143, 0, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(144, 0, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(145, 0, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(146, 0, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(147, 0, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(148, 0, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(149, 75, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(150, 75, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(151, 76, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(152, 76, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(153, 77, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(154, 77, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(155, 78, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(156, 78, 2700, 2703, 2700, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(157, 79, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(158, 79, 2700, 2703, 2700, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(159, 80, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(160, 80, 2700, 2703, 2700, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(161, 81, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(162, 81, 2674, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(163, 82, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(164, 82, 2674, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(165, 83, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(166, 83, 2674, 2700, 2674, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(167, 84, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(168, 84, 2674, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(169, 85, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(170, 85, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(171, 86, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(172, 86, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(173, 87, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(174, 87, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(175, 88, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(176, 88, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(177, 89, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(178, 89, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(179, 90, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(180, 90, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(181, 91, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(182, 91, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(183, 92, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(184, 92, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(185, 93, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(186, 93, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(187, 94, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(188, 94, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(189, 95, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(190, 95, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(191, 96, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(192, 96, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(193, 97, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(194, 97, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(195, 98, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(196, 98, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(197, 99, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(198, 99, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(199, 100, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(200, 100, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(201, 101, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(202, 101, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(203, 102, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(204, 102, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(205, 103, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(206, 103, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(207, 104, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(208, 104, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(209, 105, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(210, 105, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(211, 106, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(212, 106, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(213, 107, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(214, 107, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(215, 108, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(216, 108, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(217, 109, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(218, 109, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(219, 110, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(220, 110, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(221, 111, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(222, 111, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(223, 112, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(224, 112, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(225, 113, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(226, 113, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(227, 114, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(228, 114, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(229, 115, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(230, 115, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(231, 116, 2690, 2690, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(232, 116, 2700, 2690, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(233, 117, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(234, 117, 2703, 2700, 2703, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(235, 71, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(236, 71, 2703, 2700, 2703, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(237, 72, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(238, 72, 2703, 2700, 2703, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(239, 73, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(240, 73, 2703, 2700, 2703, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(241, 74, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(242, 74, 2703, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(243, 75, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(244, 75, 2703, 2700, 2703, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(245, 76, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(246, 76, 2703, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(247, 77, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(248, 77, 2703, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(249, 78, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(250, 78, 2703, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(251, 79, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(252, 79, 2703, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(253, 80, 2703, 2700, 2703, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(255, 81, 2674, 2674, 2682, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(256, 81, 2682, 2674, 2682, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(257, 82, 2674, 2674, 2682, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(258, 82, 2682, 2674, 2682, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(259, 83, 2674, 2674, 2682, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(260, 83, 2682, 2674, 2682, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(261, 84, 2674, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(262, 84, 2681, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(263, 85, 2674, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(264, 85, 2681, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(265, 86, 2674, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(266, 86, 2681, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(267, 87, 2674, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(268, 87, 2681, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(269, 88, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(270, 88, 2703, 2700, 2703, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(271, 89, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(272, 89, 2700, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(273, 90, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(274, 90, 2700, 2703, 2700, 0, 0);


DROP TABLE IF EXISTS sponsor_bonus;
CREATE TABLE `sponsor_bonus` (
  `sponsor_bonus_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `sponsored_id` int(11) NOT NULL DEFAULT '0',
  `is_bonus` tinyint(1) NOT NULL DEFAULT '0',
  `z_date` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sponsor_bonus_id`),
  KEY `member_id_idx` (`member_id`),
  KEY `sponsored_id_idx` (`sponsored_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS stat_counter;
CREATE TABLE `stat_counter` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `page` bigint(20) DEFAULT '0',
  `un_ip` bigint(20) DEFAULT '0',
  `un_browser` bigint(20) DEFAULT '0',
  `date` date DEFAULT '0000-00-00',
  KEY `id` (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS stat_log;
CREATE TABLE `stat_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT '0000-00-00',
  `time` time DEFAULT '00:00:00',
  `ip` varchar(16) DEFAULT '',
  `proxy` varchar(16) DEFAULT '',
  `page` varchar(1024) DEFAULT '',
  `referer` varchar(1024) DEFAULT '',
  `language` varchar(8) DEFAULT '',
  `agent` varchar(255) DEFAULT '',
  `un_browser` int(1) DEFAULT '0',
  `un_ip` int(1) DEFAULT '0',
  `session` bigint(20) DEFAULT '0',
  `screen` varchar(255) DEFAULT '',
  `get` text,
  `post` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS stats_countries;
CREATE TABLE `stats_countries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `country` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  PRIMARY KEY (`country_id`),
  KEY `referral_idx` (`country`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `stats_countries` VALUES(1, 'Undefined');


DROP TABLE IF EXISTS stats_referrals;
CREATE TABLE `stats_referrals` (
  `referral_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  PRIMARY KEY (`referral_id`),
  KEY `referral_idx` (`referral`)
) ENGINE=MyISAM AUTO_INCREMENT=19 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `stats_referrals` VALUES(1, 'No referrer');
INSERT INTO `stats_referrals` VALUES(2, 'http://swan20.com.runmlm.com/');
INSERT INTO `stats_referrals` VALUES(3, 'http://swan20.com.runmlm.com/activation.php');
INSERT INTO `stats_referrals` VALUES(4, 'http://swan20.com.runmlm.com/news.php');
INSERT INTO `stats_referrals` VALUES(5, 'http://swan20.com.runmlm.com/faq.php');
INSERT INTO `stats_referrals` VALUES(6, 'http://swan20.com.runmlm.com/ticket.php');
INSERT INTO `stats_referrals` VALUES(7, 'http://swan20.com.runmlm.com/login.php');
INSERT INTO `stats_referrals` VALUES(8, 'http://swan20.com.runmlm.com/signup.php');
INSERT INTO `stats_referrals` VALUES(9, 'https://www.google.com/');
INSERT INTO `stats_referrals` VALUES(10, 'http://aliev.toplay.website');
INSERT INTO `stats_referrals` VALUES(11, 'http://millionairescircle.club.runmlm.com/');
INSERT INTO `stats_referrals` VALUES(12, 'http://millionairescircle.club.runmlm.com/member/m');
INSERT INTO `stats_referrals` VALUES(13, 'http://millionairescircle.club.runmlm.com/index.ph');
INSERT INTO `stats_referrals` VALUES(14, 'http://www.google.com.hk');
INSERT INTO `stats_referrals` VALUES(15, 'http://millionairescircle.club.runmlm.com/member/m');
INSERT INTO `stats_referrals` VALUES(16, 'http://millionairescircle.club.runmlm.com/member/t');
INSERT INTO `stats_referrals` VALUES(17, 'http://millionairescircle.club.runmlm.com/member/t');
INSERT INTO `stats_referrals` VALUES(18, 'http://millionairescircle.club.runmlm.com/member/p');


DROP TABLE IF EXISTS stats_views;
CREATE TABLE `stats_views` (
  `view_id` int(11) NOT NULL AUTO_INCREMENT,
  `visitor_id` int(11) NOT NULL DEFAULT '0',
  `page` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `thetime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`view_id`),
  KEY `ipaddress_idx` (`visitor_id`),
  KEY `country_idx` (`page`),
  KEY `city_idx` (`thetime`)
) ENGINE=MyISAM AUTO_INCREMENT=562 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `stats_views` VALUES(1, 1, '/index.php', 1607507974);
INSERT INTO `stats_views` VALUES(2, 2, '/index.php', 1607508853);
INSERT INTO `stats_views` VALUES(3, 3, '/index.php', 1607508863);
INSERT INTO `stats_views` VALUES(4, 4, '/index.php', 1607509012);
INSERT INTO `stats_views` VALUES(5, 5, '/index.php', 1607509040);
INSERT INTO `stats_views` VALUES(6, 6, '/thank_you.php', 1607509041);
INSERT INTO `stats_views` VALUES(7, 7, '/activation.php', 1607509066);
INSERT INTO `stats_views` VALUES(8, 8, '/activation.php', 1607509071);
INSERT INTO `stats_views` VALUES(9, 9, '/activation.php', 1607509085);
INSERT INTO `stats_views` VALUES(10, 10, '/activation.php', 1607509086);
INSERT INTO `stats_views` VALUES(11, 11, '/activation.php', 1607509113);
INSERT INTO `stats_views` VALUES(12, 12, '/activation.php', 1607509123);
INSERT INTO `stats_views` VALUES(13, 13, '/activation.php', 1607509124);
INSERT INTO `stats_views` VALUES(14, 14, '/activation.php', 1607509128);
INSERT INTO `stats_views` VALUES(15, 15, '/index.php', 1607509369);
INSERT INTO `stats_views` VALUES(16, 16, '/index.php', 1607509385);
INSERT INTO `stats_views` VALUES(17, 17, '/activation.php', 1607509574);
INSERT INTO `stats_views` VALUES(18, 18, '/index.php', 1607509657);
INSERT INTO `stats_views` VALUES(19, 19, '/index.php', 1607532652);
INSERT INTO `stats_views` VALUES(20, 20, '/index.php', 1607533287);
INSERT INTO `stats_views` VALUES(21, 21, '/index.php', 1607533337);
INSERT INTO `stats_views` VALUES(22, 22, '/index.php', 1607533452);
INSERT INTO `stats_views` VALUES(23, 23, '/index.php', 1607533456);
INSERT INTO `stats_views` VALUES(24, 24, '/index.php', 1607533490);
INSERT INTO `stats_views` VALUES(25, 25, '/index.php', 1607533506);
INSERT INTO `stats_views` VALUES(26, 26, '/index.php', 1607533518);
INSERT INTO `stats_views` VALUES(27, 27, '/news.php', 1607533566);
INSERT INTO `stats_views` VALUES(28, 28, '/faq.php', 1607533569);
INSERT INTO `stats_views` VALUES(29, 29, '/ticket.php', 1607533581);
INSERT INTO `stats_views` VALUES(30, 30, '/ticket.php', 1607533852);
INSERT INTO `stats_views` VALUES(31, 31, '/ticket.php', 1607533867);
INSERT INTO `stats_views` VALUES(32, 32, '/ticket.php', 1607533901);
INSERT INTO `stats_views` VALUES(33, 33, '/ticket.php', 1607533963);
INSERT INTO `stats_views` VALUES(34, 34, '/ticket.php', 1607533984);
INSERT INTO `stats_views` VALUES(35, 35, '/index.php', 1607533991);
INSERT INTO `stats_views` VALUES(36, 36, '/index.php', 1607534009);
INSERT INTO `stats_views` VALUES(37, 37, '/login.php', 1607534011);
INSERT INTO `stats_views` VALUES(38, 38, '/signup.php', 1607534014);
INSERT INTO `stats_views` VALUES(39, 39, '/signup.php', 1607534691);
INSERT INTO `stats_views` VALUES(40, 40, '/signup.php', 1607534920);
INSERT INTO `stats_views` VALUES(41, 41, '/signup.php', 1607534942);
INSERT INTO `stats_views` VALUES(42, 42, '/signup.php', 1607535105);
INSERT INTO `stats_views` VALUES(43, 43, '/thank_you.php', 1607535107);
INSERT INTO `stats_views` VALUES(44, 44, '/thank_you.php', 1607535209);
INSERT INTO `stats_views` VALUES(45, 45, '/signup.php', 1607535213);
INSERT INTO `stats_views` VALUES(46, 46, '/signup.php', 1607535233);
INSERT INTO `stats_views` VALUES(47, 47, '/signup.php', 1607535257);
INSERT INTO `stats_views` VALUES(48, 48, '/index.php', 1612284904);
INSERT INTO `stats_views` VALUES(49, 49, '/index.php', 1612508244);
INSERT INTO `stats_views` VALUES(50, 49, '/index.php', 1612508310);
INSERT INTO `stats_views` VALUES(51, 49, '/index.php', 1612508311);
INSERT INTO `stats_views` VALUES(52, 49, '/index.php', 1612508329);
INSERT INTO `stats_views` VALUES(53, 49, '/index.php', 1612508333);
INSERT INTO `stats_views` VALUES(54, 49, '/index.php', 1612508577);
INSERT INTO `stats_views` VALUES(55, 50, '/index.php', 1612515952);
INSERT INTO `stats_views` VALUES(56, 51, '/index.php', 1612625085);
INSERT INTO `stats_views` VALUES(57, 52, '/index.php', 1612670121);
INSERT INTO `stats_views` VALUES(58, 52, '/index.php', 1612678975);
INSERT INTO `stats_views` VALUES(59, 52, '/sites/index.php', 1612678975);
INSERT INTO `stats_views` VALUES(60, 52, '/sites/index.php', 1612678975);
INSERT INTO `stats_views` VALUES(61, 52, '/sites/index.php', 1612678975);
INSERT INTO `stats_views` VALUES(62, 52, '/sites/index.php', 1612678975);
INSERT INTO `stats_views` VALUES(63, 52, '/sites/index.php', 1612678975);
INSERT INTO `stats_views` VALUES(64, 52, '/sites/index.php', 1612678975);
INSERT INTO `stats_views` VALUES(65, 52, '/sites/index.php', 1612678975);
INSERT INTO `stats_views` VALUES(66, 52, '/sites/index.php', 1612678975);
INSERT INTO `stats_views` VALUES(67, 52, '/sites/index.php', 1612678975);
INSERT INTO `stats_views` VALUES(68, 52, '/sites/index.php', 1612678976);
INSERT INTO `stats_views` VALUES(69, 52, '/sites/index.php', 1612678976);
INSERT INTO `stats_views` VALUES(70, 52, '/sites/index.php', 1612678976);
INSERT INTO `stats_views` VALUES(71, 52, '/sites/index.php', 1612678976);
INSERT INTO `stats_views` VALUES(72, 52, '/sites/index.php', 1612678976);
INSERT INTO `stats_views` VALUES(73, 52, '/sites/index.php', 1612678976);
INSERT INTO `stats_views` VALUES(74, 52, '/sites/index.php', 1612678976);
INSERT INTO `stats_views` VALUES(75, 52, '/sites/index.php', 1612678976);
INSERT INTO `stats_views` VALUES(76, 52, '/sites/index.php', 1612678976);
INSERT INTO `stats_views` VALUES(77, 52, '/sites/index.php', 1612678976);
INSERT INTO `stats_views` VALUES(78, 52, '/sites/index.php', 1612678976);
INSERT INTO `stats_views` VALUES(79, 52, '/sites/index.php', 1612678976);
INSERT INTO `stats_views` VALUES(80, 52, '/sites/index.php', 1612678977);
INSERT INTO `stats_views` VALUES(81, 52, '/sites/index.php', 1612678977);
INSERT INTO `stats_views` VALUES(82, 52, '/sites/index.php', 1612678977);
INSERT INTO `stats_views` VALUES(83, 52, '/sites/index.php', 1612678977);
INSERT INTO `stats_views` VALUES(84, 52, '/sites/index.php', 1612678977);
INSERT INTO `stats_views` VALUES(85, 52, '/sites/index.php', 1612678978);
INSERT INTO `stats_views` VALUES(86, 52, '/sites/index.php', 1612678978);
INSERT INTO `stats_views` VALUES(87, 53, '/index.php', 1612781838);
INSERT INTO `stats_views` VALUES(88, 53, '/index.php', 1612781854);
INSERT INTO `stats_views` VALUES(89, 53, '/index.php', 1612781867);
INSERT INTO `stats_views` VALUES(90, 53, '/thank_you.php', 1612781869);
INSERT INTO `stats_views` VALUES(91, 53, '/index.php', 1612781871);
INSERT INTO `stats_views` VALUES(92, 53, '/index.php', 1612781881);
INSERT INTO `stats_views` VALUES(93, 53, '/thank_you.php', 1612781883);
INSERT INTO `stats_views` VALUES(94, 53, '/index.php', 1612781885);
INSERT INTO `stats_views` VALUES(95, 53, '/index.php', 1612781894);
INSERT INTO `stats_views` VALUES(96, 53, '/thank_you.php', 1612781894);
INSERT INTO `stats_views` VALUES(97, 53, '/index.php', 1612781895);
INSERT INTO `stats_views` VALUES(98, 53, '/index.php', 1612781903);
INSERT INTO `stats_views` VALUES(99, 53, '/thank_you.php', 1612781903);
INSERT INTO `stats_views` VALUES(100, 53, '/index.php', 1612781905);
INSERT INTO `stats_views` VALUES(101, 53, '/index.php', 1612781912);
INSERT INTO `stats_views` VALUES(102, 53, '/thank_you.php', 1612781913);
INSERT INTO `stats_views` VALUES(103, 53, '/index.php', 1612781915);
INSERT INTO `stats_views` VALUES(104, 53, '/index.php', 1612781922);
INSERT INTO `stats_views` VALUES(105, 53, '/thank_you.php', 1612781923);
INSERT INTO `stats_views` VALUES(106, 53, '/index.php', 1612781924);
INSERT INTO `stats_views` VALUES(107, 53, '/index.php', 1612781931);
INSERT INTO `stats_views` VALUES(108, 53, '/thank_you.php', 1612781932);
INSERT INTO `stats_views` VALUES(109, 53, '/index.php', 1612781933);
INSERT INTO `stats_views` VALUES(110, 53, '/index.php', 1612781940);
INSERT INTO `stats_views` VALUES(111, 53, '/thank_you.php', 1612781941);
INSERT INTO `stats_views` VALUES(112, 54, '/index.php', 1612801588);
INSERT INTO `stats_views` VALUES(113, 55, '/index.php', 1612933386);
INSERT INTO `stats_views` VALUES(114, 56, '/index.php', 1613002806);
INSERT INTO `stats_views` VALUES(115, 57, '/index.php', 1613134506);
INSERT INTO `stats_views` VALUES(116, 58, '/index.php', 1613507519);
INSERT INTO `stats_views` VALUES(117, 59, '/index.php', 1613849404);
INSERT INTO `stats_views` VALUES(118, 60, '/index.php', 1614046076);
INSERT INTO `stats_views` VALUES(119, 61, '/index.php', 1614389031);
INSERT INTO `stats_views` VALUES(120, 62, '/index.php', 1614393285);
INSERT INTO `stats_views` VALUES(121, 63, '/index.php', 1614457535);
INSERT INTO `stats_views` VALUES(122, 64, '/index.php', 1614491515);
INSERT INTO `stats_views` VALUES(123, 65, '/index.php', 1614688697);
INSERT INTO `stats_views` VALUES(124, 66, '/index.php', 1614790683);
INSERT INTO `stats_views` VALUES(125, 67, '/index.php', 1615045258);
INSERT INTO `stats_views` VALUES(126, 68, '/index.php', 1615142354);
INSERT INTO `stats_views` VALUES(127, 69, '/index.php', 1615245882);
INSERT INTO `stats_views` VALUES(128, 70, '/index.php', 1615305856);
INSERT INTO `stats_views` VALUES(129, 70, '/index.php', 1615305860);
INSERT INTO `stats_views` VALUES(130, 71, '/index.php', 1615602399);
INSERT INTO `stats_views` VALUES(131, 72, '/index.php', 1615609172);
INSERT INTO `stats_views` VALUES(132, 73, '/index.php', 1615628033);
INSERT INTO `stats_views` VALUES(133, 74, '/index.php', 1615914838);
INSERT INTO `stats_views` VALUES(134, 75, '/index.php', 1616017785);
INSERT INTO `stats_views` VALUES(135, 76, '/index.php', 1616271634);
INSERT INTO `stats_views` VALUES(136, 77, '/index.php', 1616444817);
INSERT INTO `stats_views` VALUES(137, 78, '/index.php', 1616467689);
INSERT INTO `stats_views` VALUES(138, 79, '/index.php', 1616492838);
INSERT INTO `stats_views` VALUES(139, 79, '/sites/index.php', 1616492838);
INSERT INTO `stats_views` VALUES(140, 79, '/sites/index.php', 1616492840);
INSERT INTO `stats_views` VALUES(141, 79, '/sites/index.php', 1616492840);
INSERT INTO `stats_views` VALUES(142, 79, '/sites/index.php', 1616492845);
INSERT INTO `stats_views` VALUES(143, 80, '/index.php', 1617153152);
INSERT INTO `stats_views` VALUES(144, 80, '/ticket.php', 1617153153);
INSERT INTO `stats_views` VALUES(145, 80, '/forgot_password.php', 1617153153);
INSERT INTO `stats_views` VALUES(146, 81, '/index.php', 1617153293);
INSERT INTO `stats_views` VALUES(147, 81, '/forgot_password.php', 1617153296);
INSERT INTO `stats_views` VALUES(148, 81, '/ticket.php', 1617153296);
INSERT INTO `stats_views` VALUES(149, 82, '/index.php', 1617162645);
INSERT INTO `stats_views` VALUES(150, 83, '/index.php', 1617162645);
INSERT INTO `stats_views` VALUES(151, 84, '/index.php', 1617171183);
INSERT INTO `stats_views` VALUES(152, 85, '/index.php', 1618839848);
INSERT INTO `stats_views` VALUES(153, 86, '/index.php', 1618839887);
INSERT INTO `stats_views` VALUES(154, 87, '/index.php', 1618839898);
INSERT INTO `stats_views` VALUES(155, 88, '/index.php', 1618839976);
INSERT INTO `stats_views` VALUES(156, 89, '/index.php', 1618840963);
INSERT INTO `stats_views` VALUES(157, 90, '/index.php', 1618887680);
INSERT INTO `stats_views` VALUES(158, 91, '/index.php', 1618903542);
INSERT INTO `stats_views` VALUES(159, 92, '/index.php', 1618903881);
INSERT INTO `stats_views` VALUES(160, 93, '/index.php', 1618928089);
INSERT INTO `stats_views` VALUES(161, 93, '/index.php', 1618928146);
INSERT INTO `stats_views` VALUES(162, 93, '/index.php', 1618928156);
INSERT INTO `stats_views` VALUES(163, 93, '/index.php', 1618928161);
INSERT INTO `stats_views` VALUES(164, 93, '/index.php', 1618928173);
INSERT INTO `stats_views` VALUES(165, 93, '/index.php', 1618928178);
INSERT INTO `stats_views` VALUES(166, 93, '/index.php', 1618928188);
INSERT INTO `stats_views` VALUES(167, 93, '/index.php', 1618928195);
INSERT INTO `stats_views` VALUES(168, 93, '/index.php', 1618928204);
INSERT INTO `stats_views` VALUES(169, 93, '/index.php', 1618928307);
INSERT INTO `stats_views` VALUES(170, 93, '/index.php', 1618928318);
INSERT INTO `stats_views` VALUES(171, 93, '/index.php', 1618928322);
INSERT INTO `stats_views` VALUES(172, 93, '/index.php', 1618928322);
INSERT INTO `stats_views` VALUES(173, 93, '/index.php', 1618928332);
INSERT INTO `stats_views` VALUES(174, 93, '/index.php', 1618928340);
INSERT INTO `stats_views` VALUES(175, 93, '/index.php', 1618928348);
INSERT INTO `stats_views` VALUES(176, 94, '/index.php', 1619004551);
INSERT INTO `stats_views` VALUES(177, 95, '/index.php', 1619013007);
INSERT INTO `stats_views` VALUES(178, 96, '/index.php', 1619024934);
INSERT INTO `stats_views` VALUES(179, 97, '/index.php', 1619097521);
INSERT INTO `stats_views` VALUES(180, 98, '/index.php', 1619359908);
INSERT INTO `stats_views` VALUES(181, 99, '/index.php', 1619503426);
INSERT INTO `stats_views` VALUES(182, 100, '/index.php', 1619549201);
INSERT INTO `stats_views` VALUES(183, 101, '/index.php', 1619690168);
INSERT INTO `stats_views` VALUES(184, 101, '/index.php', 1619690171);
INSERT INTO `stats_views` VALUES(185, 102, '/index.php', 1619690180);
INSERT INTO `stats_views` VALUES(186, 101, '/index.php', 1619690272);
INSERT INTO `stats_views` VALUES(187, 101, '/index.php', 1619690292);
INSERT INTO `stats_views` VALUES(188, 103, '/index.php', 1619700341);
INSERT INTO `stats_views` VALUES(189, 104, '/index.php', 1619703616);
INSERT INTO `stats_views` VALUES(190, 105, '/index.php', 1619705573);
INSERT INTO `stats_views` VALUES(191, 106, '/index.php', 1619714551);
INSERT INTO `stats_views` VALUES(192, 106, '/index.php', 1619714558);
INSERT INTO `stats_views` VALUES(193, 106, '/news.php', 1619714561);
INSERT INTO `stats_views` VALUES(194, 106, '/faq.php', 1619714565);
INSERT INTO `stats_views` VALUES(195, 106, '/ticket.php', 1619714569);
INSERT INTO `stats_views` VALUES(196, 106, '/index.php', 1619714576);
INSERT INTO `stats_views` VALUES(197, 106, '/index.php', 1619714602);
INSERT INTO `stats_views` VALUES(198, 106, '/news.php', 1619714607);
INSERT INTO `stats_views` VALUES(199, 106, '/faq.php', 1619714611);
INSERT INTO `stats_views` VALUES(200, 106, '/ticket.php', 1619714614);
INSERT INTO `stats_views` VALUES(201, 106, '/index.php', 1619714634);
INSERT INTO `stats_views` VALUES(202, 106, '/ticket.php', 1619714676);
INSERT INTO `stats_views` VALUES(203, 106, '/ticket.php', 1619714678);
INSERT INTO `stats_views` VALUES(204, 106, '/news.php', 1619714688);
INSERT INTO `stats_views` VALUES(205, 106, '/index.php', 1619714702);
INSERT INTO `stats_views` VALUES(206, 107, '/index.php', 1619714779);
INSERT INTO `stats_views` VALUES(207, 108, '/index.php', 1619720375);
INSERT INTO `stats_views` VALUES(208, 109, '/index.php', 1619720623);
INSERT INTO `stats_views` VALUES(209, 110, '/index.php', 1619726258);
INSERT INTO `stats_views` VALUES(210, 111, '/index.php', 1619753646);
INSERT INTO `stats_views` VALUES(211, 112, '/index.php', 1619801547);
INSERT INTO `stats_views` VALUES(212, 112, '/index.php', 1619801558);
INSERT INTO `stats_views` VALUES(213, 113, '/index.php', 1619816363);
INSERT INTO `stats_views` VALUES(214, 114, '/index.php', 1619822499);
INSERT INTO `stats_views` VALUES(215, 115, '/index.php', 1619841896);
INSERT INTO `stats_views` VALUES(216, 115, '/index.php', 1619844857);
INSERT INTO `stats_views` VALUES(217, 115, '/index.php', 1619844871);
INSERT INTO `stats_views` VALUES(218, 115, '/news.php', 1619845136);
INSERT INTO `stats_views` VALUES(219, 115, '/faq.php', 1619845140);
INSERT INTO `stats_views` VALUES(220, 115, '/index.php', 1619845153);
INSERT INTO `stats_views` VALUES(221, 115, '/index.php', 1619845212);
INSERT INTO `stats_views` VALUES(222, 115, '/ticket.php', 1619845271);
INSERT INTO `stats_views` VALUES(223, 115, '/faq.php', 1619845302);
INSERT INTO `stats_views` VALUES(224, 115, '/news.php', 1619845306);
INSERT INTO `stats_views` VALUES(225, 115, '/index.php', 1619845310);
INSERT INTO `stats_views` VALUES(226, 116, '/index.php', 1619854001);
INSERT INTO `stats_views` VALUES(227, 117, '/index.php', 1619863159);
INSERT INTO `stats_views` VALUES(228, 118, '/index.php', 1620079270);
INSERT INTO `stats_views` VALUES(229, 119, '/index.php', 1620124222);
INSERT INTO `stats_views` VALUES(230, 120, '/index.php', 1620184512);
INSERT INTO `stats_views` VALUES(231, 121, '/index.php', 1620195727);
INSERT INTO `stats_views` VALUES(232, 122, '/index.php', 1620247393);
INSERT INTO `stats_views` VALUES(233, 122, '/index.php', 1620247401);
INSERT INTO `stats_views` VALUES(234, 122, '/index.php', 1620247456);
INSERT INTO `stats_views` VALUES(235, 122, '/index.php', 1620247459);
INSERT INTO `stats_views` VALUES(236, 122, '/index.php', 1620247469);
INSERT INTO `stats_views` VALUES(237, 122, '/index.php', 1620247475);
INSERT INTO `stats_views` VALUES(238, 122, '/index.php', 1620247495);
INSERT INTO `stats_views` VALUES(239, 122, '/index.php', 1620247501);
INSERT INTO `stats_views` VALUES(240, 122, '/index.php', 1620247520);
INSERT INTO `stats_views` VALUES(241, 122, '/index.php', 1620247525);
INSERT INTO `stats_views` VALUES(242, 122, '/index.php', 1620247546);
INSERT INTO `stats_views` VALUES(243, 122, '/index.php', 1620247552);
INSERT INTO `stats_views` VALUES(244, 122, '/index.php', 1620247584);
INSERT INTO `stats_views` VALUES(245, 122, '/index.php', 1620247588);
INSERT INTO `stats_views` VALUES(246, 122, '/index.php', 1620247608);
INSERT INTO `stats_views` VALUES(247, 122, '/index.php', 1620247612);
INSERT INTO `stats_views` VALUES(248, 122, '/index.php', 1620247636);
INSERT INTO `stats_views` VALUES(249, 122, '/index.php', 1620247640);
INSERT INTO `stats_views` VALUES(250, 122, '/index.php', 1620247661);
INSERT INTO `stats_views` VALUES(251, 122, '/index.php', 1620247665);
INSERT INTO `stats_views` VALUES(252, 122, '/index.php', 1620247718);
INSERT INTO `stats_views` VALUES(253, 122, '/index.php', 1620247726);
INSERT INTO `stats_views` VALUES(254, 122, '/index.php', 1620247914);
INSERT INTO `stats_views` VALUES(255, 122, '/index.php', 1620247919);
INSERT INTO `stats_views` VALUES(256, 122, '/index.php', 1620247940);
INSERT INTO `stats_views` VALUES(257, 122, '/index.php', 1620247945);
INSERT INTO `stats_views` VALUES(258, 122, '/index.php', 1620247976);
INSERT INTO `stats_views` VALUES(259, 122, '/index.php', 1620247990);
INSERT INTO `stats_views` VALUES(260, 122, '/index.php', 1620248020);
INSERT INTO `stats_views` VALUES(261, 122, '/index.php', 1620248024);
INSERT INTO `stats_views` VALUES(262, 122, '/index.php', 1620248047);
INSERT INTO `stats_views` VALUES(263, 122, '/index.php', 1620248052);
INSERT INTO `stats_views` VALUES(264, 122, '/index.php', 1620248077);
INSERT INTO `stats_views` VALUES(265, 122, '/index.php', 1620248081);
INSERT INTO `stats_views` VALUES(266, 122, '/index.php', 1620248082);
INSERT INTO `stats_views` VALUES(267, 122, '/index.php', 1620248112);
INSERT INTO `stats_views` VALUES(268, 122, '/index.php', 1620248117);
INSERT INTO `stats_views` VALUES(269, 122, '/index.php', 1620248140);
INSERT INTO `stats_views` VALUES(270, 122, '/index.php', 1620248141);
INSERT INTO `stats_views` VALUES(271, 122, '/index.php', 1620248171);
INSERT INTO `stats_views` VALUES(272, 122, '/index.php', 1620248175);
INSERT INTO `stats_views` VALUES(273, 122, '/index.php', 1620248194);
INSERT INTO `stats_views` VALUES(274, 122, '/index.php', 1620248201);
INSERT INTO `stats_views` VALUES(275, 122, '/index.php', 1620248227);
INSERT INTO `stats_views` VALUES(276, 122, '/index.php', 1620248231);
INSERT INTO `stats_views` VALUES(277, 122, '/index.php', 1620248250);
INSERT INTO `stats_views` VALUES(278, 122, '/index.php', 1620248255);
INSERT INTO `stats_views` VALUES(279, 122, '/index.php', 1620248293);
INSERT INTO `stats_views` VALUES(280, 122, '/index.php', 1620248298);
INSERT INTO `stats_views` VALUES(281, 122, '/index.php', 1620248318);
INSERT INTO `stats_views` VALUES(282, 122, '/index.php', 1620248323);
INSERT INTO `stats_views` VALUES(283, 122, '/index.php', 1620248348);
INSERT INTO `stats_views` VALUES(284, 122, '/index.php', 1620248354);
INSERT INTO `stats_views` VALUES(285, 122, '/index.php', 1620248383);
INSERT INTO `stats_views` VALUES(286, 122, '/index.php', 1620248397);
INSERT INTO `stats_views` VALUES(287, 122, '/index.php', 1620248496);
INSERT INTO `stats_views` VALUES(288, 122, '/index.php', 1620248528);
INSERT INTO `stats_views` VALUES(289, 122, '/index.php', 1620248540);
INSERT INTO `stats_views` VALUES(290, 122, '/index.php', 1620248545);
INSERT INTO `stats_views` VALUES(291, 122, '/index.php', 1620248565);
INSERT INTO `stats_views` VALUES(292, 122, '/index.php', 1620248574);
INSERT INTO `stats_views` VALUES(293, 122, '/index.php', 1620248574);
INSERT INTO `stats_views` VALUES(294, 122, '/index.php', 1620248584);
INSERT INTO `stats_views` VALUES(295, 122, '/index.php', 1620248586);
INSERT INTO `stats_views` VALUES(296, 122, '/index.php', 1620248589);
INSERT INTO `stats_views` VALUES(297, 122, '/index.php', 1620248589);
INSERT INTO `stats_views` VALUES(298, 122, '/index.php', 1620248602);
INSERT INTO `stats_views` VALUES(299, 122, '/index.php', 1620248606);
INSERT INTO `stats_views` VALUES(300, 122, '/index.php', 1620248630);
INSERT INTO `stats_views` VALUES(301, 122, '/index.php', 1620248635);
INSERT INTO `stats_views` VALUES(302, 122, '/index.php', 1620248665);
INSERT INTO `stats_views` VALUES(303, 122, '/index.php', 1620248670);
INSERT INTO `stats_views` VALUES(304, 122, '/index.php', 1620248692);
INSERT INTO `stats_views` VALUES(305, 122, '/index.php', 1620248697);
INSERT INTO `stats_views` VALUES(306, 122, '/index.php', 1620248728);
INSERT INTO `stats_views` VALUES(307, 122, '/index.php', 1620248747);
INSERT INTO `stats_views` VALUES(308, 122, '/index.php', 1620248752);
INSERT INTO `stats_views` VALUES(309, 122, '/index.php', 1620248784);
INSERT INTO `stats_views` VALUES(310, 122, '/index.php', 1620248789);
INSERT INTO `stats_views` VALUES(311, 122, '/index.php', 1620248835);
INSERT INTO `stats_views` VALUES(312, 122, '/index.php', 1620248881);
INSERT INTO `stats_views` VALUES(313, 122, '/index.php', 1620248886);
INSERT INTO `stats_views` VALUES(314, 122, '/index.php', 1620248913);
INSERT INTO `stats_views` VALUES(315, 122, '/index.php', 1620249449);
INSERT INTO `stats_views` VALUES(316, 122, '/index.php', 1620249470);
INSERT INTO `stats_views` VALUES(317, 122, '/index.php', 1620249475);
INSERT INTO `stats_views` VALUES(318, 122, '/index.php', 1620249496);
INSERT INTO `stats_views` VALUES(319, 122, '/index.php', 1620249501);
INSERT INTO `stats_views` VALUES(320, 122, '/index.php', 1620249522);
INSERT INTO `stats_views` VALUES(321, 122, '/index.php', 1620249526);
INSERT INTO `stats_views` VALUES(322, 122, '/index.php', 1620249546);
INSERT INTO `stats_views` VALUES(323, 122, '/index.php', 1620249551);
INSERT INTO `stats_views` VALUES(324, 122, '/index.php', 1620249573);
INSERT INTO `stats_views` VALUES(325, 122, '/index.php', 1620249578);
INSERT INTO `stats_views` VALUES(326, 122, '/index.php', 1620249606);
INSERT INTO `stats_views` VALUES(327, 122, '/index.php', 1620249686);
INSERT INTO `stats_views` VALUES(328, 122, '/index.php', 1620249716);
INSERT INTO `stats_views` VALUES(329, 122, '/index.php', 1620249730);
INSERT INTO `stats_views` VALUES(330, 122, '/index.php', 1620249735);
INSERT INTO `stats_views` VALUES(331, 122, '/index.php', 1620249757);
INSERT INTO `stats_views` VALUES(332, 122, '/index.php', 1620249762);
INSERT INTO `stats_views` VALUES(333, 122, '/index.php', 1620249781);
INSERT INTO `stats_views` VALUES(334, 122, '/index.php', 1620249787);
INSERT INTO `stats_views` VALUES(335, 122, '/index.php', 1620249806);
INSERT INTO `stats_views` VALUES(336, 122, '/index.php', 1620249809);
INSERT INTO `stats_views` VALUES(337, 122, '/index.php', 1620249836);
INSERT INTO `stats_views` VALUES(338, 122, '/index.php', 1620249841);
INSERT INTO `stats_views` VALUES(339, 122, '/index.php', 1620249862);
INSERT INTO `stats_views` VALUES(340, 122, '/index.php', 1620249867);
INSERT INTO `stats_views` VALUES(341, 122, '/index.php', 1620249889);
INSERT INTO `stats_views` VALUES(342, 122, '/index.php', 1620249901);
INSERT INTO `stats_views` VALUES(343, 122, '/index.php', 1620249906);
INSERT INTO `stats_views` VALUES(344, 122, '/index.php', 1620249927);
INSERT INTO `stats_views` VALUES(345, 122, '/index.php', 1620249932);
INSERT INTO `stats_views` VALUES(346, 122, '/index.php', 1620250010);
INSERT INTO `stats_views` VALUES(347, 122, '/index.php', 1620250020);
INSERT INTO `stats_views` VALUES(348, 122, '/index.php', 1620250025);
INSERT INTO `stats_views` VALUES(349, 122, '/index.php', 1620250056);
INSERT INTO `stats_views` VALUES(350, 122, '/index.php', 1620250101);
INSERT INTO `stats_views` VALUES(351, 122, '/index.php', 1620250121);
INSERT INTO `stats_views` VALUES(352, 122, '/index.php', 1620250127);
INSERT INTO `stats_views` VALUES(353, 122, '/index.php', 1620250150);
INSERT INTO `stats_views` VALUES(354, 122, '/index.php', 1620250155);
INSERT INTO `stats_views` VALUES(355, 122, '/index.php', 1620250177);
INSERT INTO `stats_views` VALUES(356, 122, '/index.php', 1620250182);
INSERT INTO `stats_views` VALUES(357, 122, '/index.php', 1620250368);
INSERT INTO `stats_views` VALUES(358, 122, '/index.php', 1620250373);
INSERT INTO `stats_views` VALUES(359, 122, '/index.php', 1620250410);
INSERT INTO `stats_views` VALUES(360, 122, '/index.php', 1620250415);
INSERT INTO `stats_views` VALUES(361, 122, '/index.php', 1620250444);
INSERT INTO `stats_views` VALUES(362, 122, '/index.php', 1620250448);
INSERT INTO `stats_views` VALUES(363, 122, '/index.php', 1620251127);
INSERT INTO `stats_views` VALUES(364, 122, '/index.php', 1620251135);
INSERT INTO `stats_views` VALUES(365, 122, '/index.php', 1620251159);
INSERT INTO `stats_views` VALUES(366, 122, '/index.php', 1620251164);
INSERT INTO `stats_views` VALUES(367, 122, '/index.php', 1620251183);
INSERT INTO `stats_views` VALUES(368, 122, '/index.php', 1620251187);
INSERT INTO `stats_views` VALUES(369, 122, '/index.php', 1620251207);
INSERT INTO `stats_views` VALUES(370, 122, '/index.php', 1620251211);
INSERT INTO `stats_views` VALUES(371, 122, '/index.php', 1620251251);
INSERT INTO `stats_views` VALUES(372, 122, '/index.php', 1620251255);
INSERT INTO `stats_views` VALUES(373, 122, '/index.php', 1620251276);
INSERT INTO `stats_views` VALUES(374, 122, '/index.php', 1620251280);
INSERT INTO `stats_views` VALUES(375, 122, '/index.php', 1620251300);
INSERT INTO `stats_views` VALUES(376, 122, '/index.php', 1620251304);
INSERT INTO `stats_views` VALUES(377, 122, '/index.php', 1620251331);
INSERT INTO `stats_views` VALUES(378, 122, '/index.php', 1620251343);
INSERT INTO `stats_views` VALUES(379, 122, '/index.php', 1620251348);
INSERT INTO `stats_views` VALUES(380, 122, '/index.php', 1620252102);
INSERT INTO `stats_views` VALUES(381, 122, '/index.php', 1620252143);
INSERT INTO `stats_views` VALUES(382, 122, '/index.php', 1620252144);
INSERT INTO `stats_views` VALUES(383, 122, '/index.php', 1620252162);
INSERT INTO `stats_views` VALUES(384, 122, '/index.php', 1620252168);
INSERT INTO `stats_views` VALUES(385, 122, '/index.php', 1620252193);
INSERT INTO `stats_views` VALUES(386, 122, '/index.php', 1620252197);
INSERT INTO `stats_views` VALUES(387, 122, '/index.php', 1620252224);
INSERT INTO `stats_views` VALUES(388, 122, '/index.php', 1620252228);
INSERT INTO `stats_views` VALUES(389, 122, '/index.php', 1620252267);
INSERT INTO `stats_views` VALUES(390, 122, '/index.php', 1620252272);
INSERT INTO `stats_views` VALUES(391, 122, '/index.php', 1620252291);
INSERT INTO `stats_views` VALUES(392, 122, '/index.php', 1620252295);
INSERT INTO `stats_views` VALUES(393, 122, '/index.php', 1620252316);
INSERT INTO `stats_views` VALUES(394, 122, '/index.php', 1620252320);
INSERT INTO `stats_views` VALUES(395, 122, '/index.php', 1620252341);
INSERT INTO `stats_views` VALUES(396, 123, '/index.php', 1620258325);
INSERT INTO `stats_views` VALUES(397, 123, '/index.php', 1620258377);
INSERT INTO `stats_views` VALUES(398, 123, '/index.php', 1620258382);
INSERT INTO `stats_views` VALUES(399, 123, '/index.php', 1620258406);
INSERT INTO `stats_views` VALUES(400, 123, '/index.php', 1620258410);
INSERT INTO `stats_views` VALUES(401, 123, '/index.php', 1620258436);
INSERT INTO `stats_views` VALUES(402, 123, '/index.php', 1620258440);
INSERT INTO `stats_views` VALUES(403, 123, '/index.php', 1620258462);
INSERT INTO `stats_views` VALUES(404, 123, '/index.php', 1620258466);
INSERT INTO `stats_views` VALUES(405, 123, '/index.php', 1620258674);
INSERT INTO `stats_views` VALUES(406, 123, '/index.php', 1620258678);
INSERT INTO `stats_views` VALUES(407, 123, '/index.php', 1620258716);
INSERT INTO `stats_views` VALUES(408, 123, '/index.php', 1620258721);
INSERT INTO `stats_views` VALUES(409, 123, '/index.php', 1620258747);
INSERT INTO `stats_views` VALUES(410, 123, '/index.php', 1620258751);
INSERT INTO `stats_views` VALUES(411, 123, '/index.php', 1620258776);
INSERT INTO `stats_views` VALUES(412, 123, '/index.php', 1620258781);
INSERT INTO `stats_views` VALUES(413, 123, '/index.php', 1620258841);
INSERT INTO `stats_views` VALUES(414, 123, '/index.php', 1620258846);
INSERT INTO `stats_views` VALUES(415, 123, '/index.php', 1620258867);
INSERT INTO `stats_views` VALUES(416, 123, '/index.php', 1620258958);
INSERT INTO `stats_views` VALUES(417, 123, '/index.php', 1620259556);
INSERT INTO `stats_views` VALUES(418, 123, '/index.php', 1620259575);
INSERT INTO `stats_views` VALUES(419, 123, '/index.php', 1620259580);
INSERT INTO `stats_views` VALUES(420, 123, '/index.php', 1620259603);
INSERT INTO `stats_views` VALUES(421, 123, '/index.php', 1620259607);
INSERT INTO `stats_views` VALUES(422, 123, '/index.php', 1620259760);
INSERT INTO `stats_views` VALUES(423, 123, '/index.php', 1620259764);
INSERT INTO `stats_views` VALUES(424, 123, '/index.php', 1620259789);
INSERT INTO `stats_views` VALUES(425, 123, '/index.php', 1620259793);
INSERT INTO `stats_views` VALUES(426, 123, '/index.php', 1620259812);
INSERT INTO `stats_views` VALUES(427, 123, '/index.php', 1620259816);
INSERT INTO `stats_views` VALUES(428, 123, '/index.php', 1620259838);
INSERT INTO `stats_views` VALUES(429, 123, '/index.php', 1620259845);
INSERT INTO `stats_views` VALUES(430, 124, '/index.php', 1620291617);
INSERT INTO `stats_views` VALUES(431, 125, '/index.php', 1620329814);
INSERT INTO `stats_views` VALUES(432, 125, '/index.php', 1620329822);
INSERT INTO `stats_views` VALUES(433, 125, '/index.php', 1620329832);
INSERT INTO `stats_views` VALUES(434, 125, '/index.php', 1620329836);
INSERT INTO `stats_views` VALUES(435, 125, '/index.php', 1620329840);
INSERT INTO `stats_views` VALUES(436, 125, '/index.php', 1620334047);
INSERT INTO `stats_views` VALUES(437, 125, '/index.php', 1620334064);
INSERT INTO `stats_views` VALUES(438, 125, '/index.php', 1620338795);
INSERT INTO `stats_views` VALUES(439, 126, '/index.php', 1620360438);
INSERT INTO `stats_views` VALUES(440, 127, '/index.php', 1620367666);
INSERT INTO `stats_views` VALUES(441, 128, '/index.php', 1620407118);
INSERT INTO `stats_views` VALUES(442, 129, '/index.php', 1620410051);
INSERT INTO `stats_views` VALUES(443, 129, '/index.php', 1620410167);
INSERT INTO `stats_views` VALUES(444, 129, '/index.php', 1620410182);
INSERT INTO `stats_views` VALUES(445, 129, '/index.php', 1620416156);
INSERT INTO `stats_views` VALUES(446, 129, '/index.php', 1620416323);
INSERT INTO `stats_views` VALUES(447, 129, '/index.php', 1620416393);
INSERT INTO `stats_views` VALUES(448, 129, '/index.php', 1620416399);
INSERT INTO `stats_views` VALUES(449, 129, '/index.php', 1620416422);
INSERT INTO `stats_views` VALUES(450, 129, '/index.php', 1620416427);
INSERT INTO `stats_views` VALUES(451, 129, '/index.php', 1620416449);
INSERT INTO `stats_views` VALUES(452, 129, '/index.php', 1620416453);
INSERT INTO `stats_views` VALUES(453, 129, '/index.php', 1620416475);
INSERT INTO `stats_views` VALUES(454, 129, '/index.php', 1620416481);
INSERT INTO `stats_views` VALUES(455, 129, '/index.php', 1620416516);
INSERT INTO `stats_views` VALUES(456, 129, '/index.php', 1620416523);
INSERT INTO `stats_views` VALUES(457, 129, '/index.php', 1620416547);
INSERT INTO `stats_views` VALUES(458, 129, '/index.php', 1620416560);
INSERT INTO `stats_views` VALUES(459, 129, '/index.php', 1620416582);
INSERT INTO `stats_views` VALUES(460, 129, '/index.php', 1620416586);
INSERT INTO `stats_views` VALUES(461, 129, '/index.php', 1620416614);
INSERT INTO `stats_views` VALUES(462, 129, '/index.php', 1620416620);
INSERT INTO `stats_views` VALUES(463, 129, '/index.php', 1620416659);
INSERT INTO `stats_views` VALUES(464, 129, '/index.php', 1620416665);
INSERT INTO `stats_views` VALUES(465, 129, '/index.php', 1620416689);
INSERT INTO `stats_views` VALUES(466, 129, '/index.php', 1620416693);
INSERT INTO `stats_views` VALUES(467, 129, '/index.php', 1620416718);
INSERT INTO `stats_views` VALUES(468, 129, '/index.php', 1620416723);
INSERT INTO `stats_views` VALUES(469, 129, '/index.php', 1620416744);
INSERT INTO `stats_views` VALUES(470, 129, '/index.php', 1620416748);
INSERT INTO `stats_views` VALUES(471, 129, '/index.php', 1620416798);
INSERT INTO `stats_views` VALUES(472, 129, '/index.php', 1620416804);
INSERT INTO `stats_views` VALUES(473, 129, '/index.php', 1620416847);
INSERT INTO `stats_views` VALUES(474, 129, '/index.php', 1620416853);
INSERT INTO `stats_views` VALUES(475, 129, '/index.php', 1620416890);
INSERT INTO `stats_views` VALUES(476, 129, '/index.php', 1620416895);
INSERT INTO `stats_views` VALUES(477, 129, '/index.php', 1620416930);
INSERT INTO `stats_views` VALUES(478, 130, '/index.php', 1620424730);
INSERT INTO `stats_views` VALUES(479, 130, '/index.php', 1620424771);
INSERT INTO `stats_views` VALUES(480, 130, '/index.php', 1620424779);
INSERT INTO `stats_views` VALUES(481, 130, '/index.php', 1620424792);
INSERT INTO `stats_views` VALUES(482, 130, '/index.php', 1620424796);
INSERT INTO `stats_views` VALUES(483, 130, '/index.php', 1620424809);
INSERT INTO `stats_views` VALUES(484, 130, '/index.php', 1620424813);
INSERT INTO `stats_views` VALUES(485, 130, '/index.php', 1620424826);
INSERT INTO `stats_views` VALUES(486, 130, '/index.php', 1620424832);
INSERT INTO `stats_views` VALUES(487, 130, '/index.php', 1620424854);
INSERT INTO `stats_views` VALUES(488, 130, '/index.php', 1620424858);
INSERT INTO `stats_views` VALUES(489, 130, '/index.php', 1620424870);
INSERT INTO `stats_views` VALUES(490, 130, '/index.php', 1620424874);
INSERT INTO `stats_views` VALUES(491, 130, '/index.php', 1620424887);
INSERT INTO `stats_views` VALUES(492, 130, '/index.php', 1620424891);
INSERT INTO `stats_views` VALUES(493, 130, '/index.php', 1620424905);
INSERT INTO `stats_views` VALUES(494, 130, '/index.php', 1620424909);
INSERT INTO `stats_views` VALUES(495, 130, '/index.php', 1620424944);
INSERT INTO `stats_views` VALUES(496, 130, '/index.php', 1620424948);
INSERT INTO `stats_views` VALUES(497, 130, '/index.php', 1620424967);
INSERT INTO `stats_views` VALUES(498, 130, '/index.php', 1620424971);
INSERT INTO `stats_views` VALUES(499, 130, '/index.php', 1620424984);
INSERT INTO `stats_views` VALUES(500, 130, '/index.php', 1620424989);
INSERT INTO `stats_views` VALUES(501, 130, '/index.php', 1620425007);
INSERT INTO `stats_views` VALUES(502, 130, '/index.php', 1620425015);
INSERT INTO `stats_views` VALUES(503, 130, '/index.php', 1620425048);
INSERT INTO `stats_views` VALUES(504, 130, '/index.php', 1620425052);
INSERT INTO `stats_views` VALUES(505, 130, '/index.php', 1620425065);
INSERT INTO `stats_views` VALUES(506, 130, '/index.php', 1620425073);
INSERT INTO `stats_views` VALUES(507, 130, '/index.php', 1620425095);
INSERT INTO `stats_views` VALUES(508, 130, '/index.php', 1620425102);
INSERT INTO `stats_views` VALUES(509, 130, '/index.php', 1620425115);
INSERT INTO `stats_views` VALUES(510, 130, '/index.php', 1620425124);
INSERT INTO `stats_views` VALUES(511, 130, '/index.php', 1620425156);
INSERT INTO `stats_views` VALUES(512, 130, '/index.php', 1620425160);
INSERT INTO `stats_views` VALUES(513, 130, '/index.php', 1620425177);
INSERT INTO `stats_views` VALUES(514, 130, '/index.php', 1620425181);
INSERT INTO `stats_views` VALUES(515, 130, '/index.php', 1620425194);
INSERT INTO `stats_views` VALUES(516, 130, '/index.php', 1620425197);
INSERT INTO `stats_views` VALUES(517, 130, '/index.php', 1620425209);
INSERT INTO `stats_views` VALUES(518, 130, '/index.php', 1620425214);
INSERT INTO `stats_views` VALUES(519, 130, '/index.php', 1620425249);
INSERT INTO `stats_views` VALUES(520, 130, '/index.php', 1620425253);
INSERT INTO `stats_views` VALUES(521, 130, '/index.php', 1620425271);
INSERT INTO `stats_views` VALUES(522, 130, '/index.php', 1620425276);
INSERT INTO `stats_views` VALUES(523, 130, '/index.php', 1620425300);
INSERT INTO `stats_views` VALUES(524, 130, '/index.php', 1620425304);
INSERT INTO `stats_views` VALUES(525, 130, '/index.php', 1620425318);
INSERT INTO `stats_views` VALUES(526, 130, '/index.php', 1620425780);
INSERT INTO `stats_views` VALUES(527, 130, '/index.php', 1620426868);
INSERT INTO `stats_views` VALUES(528, 130, '/index.php', 1620426869);
INSERT INTO `stats_views` VALUES(529, 130, '/index.php', 1620426914);
INSERT INTO `stats_views` VALUES(530, 131, '/index.php', 1620581861);
INSERT INTO `stats_views` VALUES(531, 132, '/index.php', 1620618888);
INSERT INTO `stats_views` VALUES(532, 133, '/index.php', 1620697675);
INSERT INTO `stats_views` VALUES(533, 134, '/index.php', 1620733245);
INSERT INTO `stats_views` VALUES(534, 135, '/index.php', 1620733555);
INSERT INTO `stats_views` VALUES(535, 135, '/index.php', 1620733564);
INSERT INTO `stats_views` VALUES(536, 135, '/index.php', 1620733580);
INSERT INTO `stats_views` VALUES(537, 134, '/index.php', 1620733734);
INSERT INTO `stats_views` VALUES(538, 134, '/index.php', 1620733807);
INSERT INTO `stats_views` VALUES(539, 134, '/index.php', 1620733864);
INSERT INTO `stats_views` VALUES(540, 134, '/index.php', 1620733870);
INSERT INTO `stats_views` VALUES(541, 134, '/index.php', 1620733906);
INSERT INTO `stats_views` VALUES(542, 134, '/index.php', 1620733942);
INSERT INTO `stats_views` VALUES(543, 134, '/index.php', 1620734010);
INSERT INTO `stats_views` VALUES(544, 134, '/index.php', 1620734070);
INSERT INTO `stats_views` VALUES(545, 134, '/index.php', 1620734092);
INSERT INTO `stats_views` VALUES(546, 134, '/index.php', 1620734111);
INSERT INTO `stats_views` VALUES(547, 134, '/index.php', 1620734139);
INSERT INTO `stats_views` VALUES(548, 134, '/index.php', 1620734146);
INSERT INTO `stats_views` VALUES(549, 134, '/index.php', 1620734178);
INSERT INTO `stats_views` VALUES(550, 134, '/index.php', 1620734218);
INSERT INTO `stats_views` VALUES(551, 134, '/index.php', 1620734240);
INSERT INTO `stats_views` VALUES(552, 134, '/index.php', 1620734315);
INSERT INTO `stats_views` VALUES(553, 134, '/index.php', 1620734384);
INSERT INTO `stats_views` VALUES(554, 134, '/index.php', 1620734416);
INSERT INTO `stats_views` VALUES(555, 134, '/index.php', 1620734435);
INSERT INTO `stats_views` VALUES(556, 134, '/index.php', 1620734452);
INSERT INTO `stats_views` VALUES(557, 134, '/index.php', 1620734486);
INSERT INTO `stats_views` VALUES(558, 136, '/index.php', 1620734521);
INSERT INTO `stats_views` VALUES(559, 136, '/index.php', 1620734628);
INSERT INTO `stats_views` VALUES(560, 134, '/index.php', 1620734787);
INSERT INTO `stats_views` VALUES(561, 134, '/index.php', 1620736891);


DROP TABLE IF EXISTS stats_visitors;
CREATE TABLE `stats_visitors` (
  `visitor_id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(20) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `ipref` int(11) NOT NULL DEFAULT '0',
  `country` int(11) NOT NULL DEFAULT '0',
  `city` varchar(100) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `thetime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`visitor_id`),
  KEY `ipaddress_idx` (`ipaddress`),
  KEY `country_idx` (`country`),
  KEY `city_idx` (`city`),
  KEY `thetime` (`thetime`)
) ENGINE=MyISAM AUTO_INCREMENT=137 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `stats_visitors` VALUES(1, '52.114.75.71', 1, 1, 'Undefined', 1607507974);
INSERT INTO `stats_visitors` VALUES(2, '2401:3c00:18f:4c1a:f', 1, 1, 'Undefined', 1607508853);
INSERT INTO `stats_visitors` VALUES(3, '2401:3c00:18f:4c1a:f', 2, 1, 'Undefined', 1607508863);
INSERT INTO `stats_visitors` VALUES(4, '2401:3c00:18f:4c1a:f', 1, 1, 'Undefined', 1607509012);
INSERT INTO `stats_visitors` VALUES(5, '2401:3c00:18f:4c1a:f', 2, 1, 'Undefined', 1607509040);
INSERT INTO `stats_visitors` VALUES(6, '2401:3c00:18f:4c1a:f', 2, 1, 'Undefined', 1607509041);
INSERT INTO `stats_visitors` VALUES(7, '2401:3c00:18f:4c1a:f', 1, 1, 'Undefined', 1607509066);
INSERT INTO `stats_visitors` VALUES(8, '203.82.75.133', 1, 1, 'Undefined', 1607509071);
INSERT INTO `stats_visitors` VALUES(9, '2401:3c00:18f:4c1a:f', 3, 1, 'Undefined', 1607509085);
INSERT INTO `stats_visitors` VALUES(10, '2401:3c00:18f:4c1a:f', 3, 1, 'Undefined', 1607509086);
INSERT INTO `stats_visitors` VALUES(11, '2401:3c00:18f:4c1a:f', 1, 1, 'Undefined', 1607509113);
INSERT INTO `stats_visitors` VALUES(12, '2401:3c00:18f:4c1a:f', 3, 1, 'Undefined', 1607509123);
INSERT INTO `stats_visitors` VALUES(13, '2401:3c00:18f:4c1a:f', 3, 1, 'Undefined', 1607509124);
INSERT INTO `stats_visitors` VALUES(14, '2401:3c00:18f:4c1a:f', 1, 1, 'Undefined', 1607509128);
INSERT INTO `stats_visitors` VALUES(15, '61.129.8.179', 1, 1, 'Undefined', 1607509369);
INSERT INTO `stats_visitors` VALUES(16, '61.151.178.236', 1, 1, 'Undefined', 1607509385);
INSERT INTO `stats_visitors` VALUES(17, '101.89.239.230', 1, 1, 'Undefined', 1607509574);
INSERT INTO `stats_visitors` VALUES(18, '61.129.7.235', 1, 1, 'Undefined', 1607509657);
INSERT INTO `stats_visitors` VALUES(19, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607532652);
INSERT INTO `stats_visitors` VALUES(20, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533287);
INSERT INTO `stats_visitors` VALUES(21, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533337);
INSERT INTO `stats_visitors` VALUES(22, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533452);
INSERT INTO `stats_visitors` VALUES(23, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533456);
INSERT INTO `stats_visitors` VALUES(24, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533490);
INSERT INTO `stats_visitors` VALUES(25, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533506);
INSERT INTO `stats_visitors` VALUES(26, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533518);
INSERT INTO `stats_visitors` VALUES(27, '2a00:bc00:8800:b665:', 2, 1, 'Undefined', 1607533566);
INSERT INTO `stats_visitors` VALUES(28, '2a00:bc00:8800:b665:', 4, 1, 'Undefined', 1607533569);
INSERT INTO `stats_visitors` VALUES(29, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533581);
INSERT INTO `stats_visitors` VALUES(30, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533852);
INSERT INTO `stats_visitors` VALUES(31, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533867);
INSERT INTO `stats_visitors` VALUES(32, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533901);
INSERT INTO `stats_visitors` VALUES(33, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533963);
INSERT INTO `stats_visitors` VALUES(34, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533984);
INSERT INTO `stats_visitors` VALUES(35, '2a00:bc00:8800:b665:', 6, 1, 'Undefined', 1607533991);
INSERT INTO `stats_visitors` VALUES(36, '2a00:bc00:8800:b665:', 6, 1, 'Undefined', 1607534009);
INSERT INTO `stats_visitors` VALUES(37, '2a00:bc00:8800:b665:', 2, 1, 'Undefined', 1607534011);
INSERT INTO `stats_visitors` VALUES(38, '2a00:bc00:8800:b665:', 7, 1, 'Undefined', 1607534014);
INSERT INTO `stats_visitors` VALUES(39, '2a00:bc00:8800:b665:', 7, 1, 'Undefined', 1607534691);
INSERT INTO `stats_visitors` VALUES(40, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607534920);
INSERT INTO `stats_visitors` VALUES(41, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607534942);
INSERT INTO `stats_visitors` VALUES(42, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535105);
INSERT INTO `stats_visitors` VALUES(43, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535107);
INSERT INTO `stats_visitors` VALUES(44, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535209);
INSERT INTO `stats_visitors` VALUES(45, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535213);
INSERT INTO `stats_visitors` VALUES(46, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535233);
INSERT INTO `stats_visitors` VALUES(47, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535257);
INSERT INTO `stats_visitors` VALUES(48, '209.17.96.130', 1, 1, 'Undefined', 1612284904);
INSERT INTO `stats_visitors` VALUES(49, '79.175.57.168', 1, 1, 'Undefined', 1612508244);
INSERT INTO `stats_visitors` VALUES(50, '104.248.54.77', 1, 1, 'Undefined', 1612515952);
INSERT INTO `stats_visitors` VALUES(51, '209.17.96.186', 1, 1, 'Undefined', 1612625085);
INSERT INTO `stats_visitors` VALUES(52, '129.213.146.171', 1, 1, 'Undefined', 1612670121);
INSERT INTO `stats_visitors` VALUES(53, '79.175.57.168', 1, 1, 'Undefined', 1612781838);
INSERT INTO `stats_visitors` VALUES(54, '212.188.7.5', 9, 1, 'Undefined', 1612801588);
INSERT INTO `stats_visitors` VALUES(55, '188.232.28.202', 1, 1, 'Undefined', 1612933386);
INSERT INTO `stats_visitors` VALUES(56, '209.17.96.186', 1, 1, 'Undefined', 1613002806);
INSERT INTO `stats_visitors` VALUES(57, '209.17.96.26', 1, 1, 'Undefined', 1613134506);
INSERT INTO `stats_visitors` VALUES(58, '34.86.35.8', 1, 1, 'Undefined', 1613507519);
INSERT INTO `stats_visitors` VALUES(59, '40.71.118.135', 1, 1, 'Undefined', 1613849404);
INSERT INTO `stats_visitors` VALUES(60, '77.88.5.241', 1, 1, 'Undefined', 1614046076);
INSERT INTO `stats_visitors` VALUES(61, '92.118.160.37', 1, 1, 'Undefined', 1614389031);
INSERT INTO `stats_visitors` VALUES(62, '34.77.162.4', 1, 1, 'Undefined', 1614393285);
INSERT INTO `stats_visitors` VALUES(63, '165.227.178.215', 1, 1, 'Undefined', 1614457535);
INSERT INTO `stats_visitors` VALUES(64, '92.118.160.5', 1, 1, 'Undefined', 1614491515);
INSERT INTO `stats_visitors` VALUES(65, '66.249.93.114', 1, 1, 'Undefined', 1614688697);
INSERT INTO `stats_visitors` VALUES(66, '91.206.201.240', 10, 1, 'Undefined', 1614790683);
INSERT INTO `stats_visitors` VALUES(67, '2001:19f0:6c01:2bf9:', 1, 1, 'Undefined', 1615045258);
INSERT INTO `stats_visitors` VALUES(68, '2001:19f0:6c01:2bf9:', 1, 1, 'Undefined', 1615142354);
INSERT INTO `stats_visitors` VALUES(69, '34.77.162.12', 1, 1, 'Undefined', 1615245882);
INSERT INTO `stats_visitors` VALUES(70, '118.24.106.70', 1, 1, 'Undefined', 1615305856);
INSERT INTO `stats_visitors` VALUES(71, '92.118.160.37', 1, 1, 'Undefined', 1615602399);
INSERT INTO `stats_visitors` VALUES(72, '34.77.162.23', 1, 1, 'Undefined', 1615609172);
INSERT INTO `stats_visitors` VALUES(73, '106.54.83.31', 1, 1, 'Undefined', 1615628033);
INSERT INTO `stats_visitors` VALUES(74, '66.249.93.114', 1, 1, 'Undefined', 1615914838);
INSERT INTO `stats_visitors` VALUES(75, '34.77.162.5', 1, 1, 'Undefined', 1616017785);
INSERT INTO `stats_visitors` VALUES(76, '77.88.5.88', 1, 1, 'Undefined', 1616271634);
INSERT INTO `stats_visitors` VALUES(77, '92.118.160.61', 1, 1, 'Undefined', 1616444817);
INSERT INTO `stats_visitors` VALUES(78, '93.158.161.74', 1, 1, 'Undefined', 1616467689);
INSERT INTO `stats_visitors` VALUES(79, '45.95.31.61', 1, 1, 'Undefined', 1616492838);
INSERT INTO `stats_visitors` VALUES(80, '52.24.90.208', 1, 1, 'Undefined', 1617153152);
INSERT INTO `stats_visitors` VALUES(81, '54.202.74.131', 1, 1, 'Undefined', 1617153293);
INSERT INTO `stats_visitors` VALUES(82, '35.223.197.125', 1, 1, 'Undefined', 1617162645);
INSERT INTO `stats_visitors` VALUES(83, '35.223.197.125', 1, 1, 'Undefined', 1617162645);
INSERT INTO `stats_visitors` VALUES(84, '167.71.189.173', 1, 1, 'Undefined', 1617171183);
INSERT INTO `stats_visitors` VALUES(85, '2a00:bc00:8800:b665:', 11, 1, 'Undefined', 1618839848);
INSERT INTO `stats_visitors` VALUES(86, '149.154.161.13', 1, 1, 'Undefined', 1618839887);
INSERT INTO `stats_visitors` VALUES(87, '2a00:bc00:8800:b665:', 11, 1, 'Undefined', 1618839898);
INSERT INTO `stats_visitors` VALUES(88, '93.157.144.198', 1, 1, 'Undefined', 1618839976);
INSERT INTO `stats_visitors` VALUES(89, '205.169.39.46', 1, 1, 'Undefined', 1618840963);
INSERT INTO `stats_visitors` VALUES(90, '179.43.169.181', 1, 1, 'Undefined', 1618887680);
INSERT INTO `stats_visitors` VALUES(91, '195.154.61.206', 1, 1, 'Undefined', 1618903542);
INSERT INTO `stats_visitors` VALUES(92, '62.4.14.198', 1, 1, 'Undefined', 1618903881);
INSERT INTO `stats_visitors` VALUES(93, '93.157.144.198', 1, 1, 'Undefined', 1618928089);
INSERT INTO `stats_visitors` VALUES(94, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1619004551);
INSERT INTO `stats_visitors` VALUES(95, '2a00:bc00:8800:b665:', 12, 1, 'Undefined', 1619013007);
INSERT INTO `stats_visitors` VALUES(96, '149.154.161.5', 1, 1, 'Undefined', 1619024934);
INSERT INTO `stats_visitors` VALUES(97, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1619097521);
INSERT INTO `stats_visitors` VALUES(98, '54.234.62.29', 1, 1, 'Undefined', 1619359908);
INSERT INTO `stats_visitors` VALUES(99, '34.96.130.24', 1, 1, 'Undefined', 1619503426);
INSERT INTO `stats_visitors` VALUES(100, '34.86.35.29', 1, 1, 'Undefined', 1619549201);
INSERT INTO `stats_visitors` VALUES(101, '93.157.144.198', 1, 1, 'Undefined', 1619690168);
INSERT INTO `stats_visitors` VALUES(102, '87.79.22.75', 9, 1, 'Undefined', 1619690180);
INSERT INTO `stats_visitors` VALUES(103, '168.167.25.38', 1, 1, 'Undefined', 1619700341);
INSERT INTO `stats_visitors` VALUES(104, '146.112.56.124', 1, 1, 'Undefined', 1619703616);
INSERT INTO `stats_visitors` VALUES(105, '146.112.56.81', 1, 1, 'Undefined', 1619705573);
INSERT INTO `stats_visitors` VALUES(106, '146.112.56.114', 1, 1, 'Undefined', 1619714551);
INSERT INTO `stats_visitors` VALUES(107, '146.112.56.82', 13, 1, 'Undefined', 1619714779);
INSERT INTO `stats_visitors` VALUES(108, '146.112.56.81', 1, 1, 'Undefined', 1619720375);
INSERT INTO `stats_visitors` VALUES(109, '146.112.56.76', 1, 1, 'Undefined', 1619720623);
INSERT INTO `stats_visitors` VALUES(110, '146.112.56.114', 11, 1, 'Undefined', 1619726258);
INSERT INTO `stats_visitors` VALUES(111, '63.141.251.237', 14, 1, 'Undefined', 1619753646);
INSERT INTO `stats_visitors` VALUES(112, '168.167.26.181', 1, 1, 'Undefined', 1619801547);
INSERT INTO `stats_visitors` VALUES(113, '168.167.26.181', 1, 1, 'Undefined', 1619816363);
INSERT INTO `stats_visitors` VALUES(114, '34.96.130.26', 1, 1, 'Undefined', 1619822499);
INSERT INTO `stats_visitors` VALUES(115, '168.167.26.181', 1, 1, 'Undefined', 1619841896);
INSERT INTO `stats_visitors` VALUES(116, '34.77.162.6', 1, 1, 'Undefined', 1619854001);
INSERT INTO `stats_visitors` VALUES(117, '168.167.26.181', 1, 1, 'Undefined', 1619863159);
INSERT INTO `stats_visitors` VALUES(118, '34.86.35.22', 1, 1, 'Undefined', 1620079270);
INSERT INTO `stats_visitors` VALUES(119, '34.86.35.21', 1, 1, 'Undefined', 1620124222);
INSERT INTO `stats_visitors` VALUES(120, '159.65.249.251', 1, 1, 'Undefined', 1620184512);
INSERT INTO `stats_visitors` VALUES(121, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1620195727);
INSERT INTO `stats_visitors` VALUES(122, '168.167.26.133', 15, 1, 'Undefined', 1620247393);
INSERT INTO `stats_visitors` VALUES(123, '168.167.26.133', 16, 1, 'Undefined', 1620258325);
INSERT INTO `stats_visitors` VALUES(124, '88.12.7.11', 1, 1, 'Undefined', 1620291617);
INSERT INTO `stats_visitors` VALUES(125, '168.167.26.133', 17, 1, 'Undefined', 1620329814);
INSERT INTO `stats_visitors` VALUES(126, '34.86.35.33', 1, 1, 'Undefined', 1620360438);
INSERT INTO `stats_visitors` VALUES(127, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1620367666);
INSERT INTO `stats_visitors` VALUES(128, '34.86.35.20', 1, 1, 'Undefined', 1620407118);
INSERT INTO `stats_visitors` VALUES(129, '168.167.26.133', 18, 1, 'Undefined', 1620410051);
INSERT INTO `stats_visitors` VALUES(130, '168.167.26.133', 1, 1, 'Undefined', 1620424730);
INSERT INTO `stats_visitors` VALUES(131, '92.118.160.1', 1, 1, 'Undefined', 1620581861);
INSERT INTO `stats_visitors` VALUES(132, '92.118.160.9', 1, 1, 'Undefined', 1620618888);
INSERT INTO `stats_visitors` VALUES(133, '34.86.35.13', 1, 1, 'Undefined', 1620697675);
INSERT INTO `stats_visitors` VALUES(134, '37.25.123.125', 1, 1, 'Undefined', 1620733245);
INSERT INTO `stats_visitors` VALUES(135, '168.167.26.200', 1, 1, 'Undefined', 1620733555);
INSERT INTO `stats_visitors` VALUES(136, '46.72.21.127', 1, 1, 'Undefined', 1620734521);


DROP TABLE IF EXISTS testimonials;
CREATE TABLE `testimonials` (
  `testimonial_id` int(11) NOT NULL AUTO_INCREMENT,
  `number` int(5) NOT NULL DEFAULT '0',
  `author` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `location` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `photo` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`testimonial_id`),
  KEY `number_idx` (`number`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `testimonials` VALUES(1, 0, '1 am', '', 'messagemessagemessage', '_9ieghudm2e.jpg', 1);
INSERT INTO `testimonials` VALUES(2, 0, 'фыв', '', 'ыфп', '_gd1sq6kel3.jpg', 0);


DROP TABLE IF EXISTS text_ads;
CREATE TABLE `text_ads` (
  `text_ad_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(25) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description1` varchar(35) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description2` varchar(35) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `url` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `show_url` tinyint(1) NOT NULL DEFAULT '0',
  `displayed` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`text_ad_id`),
  KEY `member_id_idx` (`member_id`),
  KEY `displayed_idx` (`displayed`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS ticket_messages;
CREATE TABLE `ticket_messages` (
  `ticket_message_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL DEFAULT '0',
  `message_from` int(11) NOT NULL DEFAULT '0',
  `message_to` int(11) NOT NULL DEFAULT '0',
  `message` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `date_post` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ticket_message_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS tickets;
CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `subject` varchar(150) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `date_create` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  `last_replier` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ticket_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS types;
CREATE TABLE `types` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_index` int(11) NOT NULL DEFAULT '0',
  `title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `cost` decimal(12,2) NOT NULL DEFAULT '0.00',
  `host_fee` decimal(12,2) NOT NULL DEFAULT '0.00',
  `enr_fee` decimal(12,2) NOT NULL DEFAULT '0.00',
  `admin_fee` decimal(12,2) NOT NULL DEFAULT '0.00',
  `width` int(3) NOT NULL DEFAULT '0',
  `depth` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`type_id`),
  KEY `order_index_idx` (`order_index`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `types` VALUES(1, 1, 'Level 1', '25.00', '200.00', '0.00', '0.00', 2, 3);
INSERT INTO `types` VALUES(2, 2, 'Level 2', '100.00', '800.00', '0.00', '0.00', 2, 3);
INSERT INTO `types` VALUES(3, 3, 'Level 3', '400.00', '3200.00', '200.00', '200.00', 2, 3);


DROP TABLE IF EXISTS user_admins;
CREATE TABLE `user_admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `passwd` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `email` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `first_name` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `last_name` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `last_access` int(11) NOT NULL DEFAULT '0',
  `access` varchar(2048) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `username_idx` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=8 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `user_admins` VALUES(1, 'admin', 'fc93f0a8fa5c3527b8d0ad486df7e6e3', 'support@runmlm.com', '', '', 0, 'a:39:{i:0;s:5:\"login\";i:1;s:6:\"admins\";i:2;s:4:\"stat\";i:3;s:7:\"members\";i:4;s:4:\"tree\";i:5;s:12:\"admindetails\";i:6;s:8:\"settings\";i:7;s:8:\"matrixes\";i:8;s:6:\"levels\";i:9;s:13:\"levels_forced\";i:10;s:7:\"payment\";i:11;s:4:\"cash\";i:12;s:8:\"cash_out\";i:13;s:10:\"processors\";i:14;s:5:\"pages\";i:15;s:7:\"m_pages\";i:16;s:4:\"news\";i:17;s:3:\"faq\";i:18;s:5:\"lands\";i:19;s:7:\"aptools\";i:20;s:6:\"ptools\";i:21;s:4:\"tads\";i:22;s:7:\"tickets\";i:23;s:11:\"pub_tickets\";i:24;s:9:\"templates\";i:25;s:15:\"autorespondersf\";i:26;s:14:\"autoresponders\";i:27;s:11:\"atempplates\";i:28;s:7:\"mailing\";i:29;s:6:\"backup\";i:30;s:4:\"fees\";i:31;s:11:\"memb_matrix\";i:32;s:8:\"m_levels\";i:33;s:13:\"forced_matrix\";i:34;s:12:\"replica_site\";i:35;s:6:\"manual\";i:36;s:17:\"template_elements\";i:37;s:14:\"upload_members\";i:38;s:6:\"slider\";}', 1);


