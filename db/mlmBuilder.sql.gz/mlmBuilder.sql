-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Хост: irushost.mysql.ukraine.com.ua
-- Время создания: Фев 01 2021 г., 12:22
-- Версия сервера: 5.7.16-10-log
-- Версия PHP: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `irushost_mlm37`
--

-- --------------------------------------------------------

--
-- Структура таблицы `aemailtempl`
--

CREATE TABLE `aemailtempl` (
  `emailtempl_id` int(11) NOT NULL,
  `subject` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `tag_descr` text COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `aemailtempl`
--

INSERT INTO `aemailtempl` (`emailtempl_id`, `subject`, `message`, `tag_descr`, `is_active`) VALUES
(1, 'Welcome to [SiteTitle]', '&lt;p&gt;Dear [FirstName] [LastName],&lt;/p&gt;\r\n&lt;p&gt;Some message with tags.&lt;/p&gt;\r\n&lt;p&gt;Regards, [SiteTitle]&lt;/p&gt;', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteUrl]\');\">SiteUrl</a>] - Url of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[RefLink]\');\">RefLink</a>] - Referral Link<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[ID]\');\">ID</a>] - Member&#039;s ID<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s First Name<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s Last Name<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s Username<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s Email<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorID]\');\">SponsorID</a>] - Sponsor&#039;s ID<br>\r\n', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `aptools`
--

CREATE TABLE `aptools` (
  `aptool_id` int(11) NOT NULL,
  `photo` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `autoresponders`
--

CREATE TABLE `autoresponders` (
  `email_id` int(11) NOT NULL,
  `subject` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `z_day` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `is_free` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `autoresponders`
--

INSERT INTO `autoresponders` (`email_id`, `subject`, `message`, `z_day`, `is_active`, `is_free`) VALUES
(1, 'test', 'test', 1, 0, 1),
(2, 'test', 'test', 2, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `cash`
--

CREATE TABLE `cash` (
  `cash_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `from_id` int(11) NOT NULL DEFAULT '0',
  `to_id` int(11) NOT NULL DEFAULT '0',
  `type_cash` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `descr` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cash_date` int(11) NOT NULL DEFAULT '0',
  `payment_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cash_out`
--

CREATE TABLE `cash_out` (
  `cash_out_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `processor` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `account_id` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `transfer_date` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `title` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `m_level` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `currency`
--

CREATE TABLE `currency` (
  `id` int(11) NOT NULL,
  `symbol` varchar(8) DEFAULT NULL,
  `name` varchar(8) DEFAULT '',
  `active` tinyint(1) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `currency`
--

INSERT INTO `currency` (`id`, `symbol`, `name`, `active`) VALUES
(1, '$', 'USD', 1),
(2, '€', 'EUR', 1),
(3, 'Mex$', 'MXN', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `emailtempl`
--

CREATE TABLE `emailtempl` (
  `emailtempl_id` int(11) NOT NULL,
  `description` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subject` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `tag_descr` text COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `emailtempl`
--

INSERT INTO `emailtempl` (`emailtempl_id`, `description`, `subject`, `message`, `tag_descr`, `is_active`) VALUES
(1, 'Sponsor notification about new sign up', 'From [SiteTitle]: New referrer signup up', 'Dear [SponsorFName] [SponsorLName], \r\n\r\nYou referral activated account. Their email is [Email], name is [FirstName] [LastName]. Contact them and make sure they are able to verify their email address.\r\nIf they don&#039;t do this within 24 hours they will be removed.\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorFName]\');\">SponsorFName</a>] - Sponsor&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorLName]\');\">SponsorLName</a>] - Sponsor&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorUsername]\');\">SponsorUsername</a>] - Sponsor&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorEmail]\');\">SponsorEmail</a>] - Sponsor&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n', 1),
(2, 'Welcome email sent to member after successful registration with activation link', 'Activate your new account in [SiteTitle]', 'Welcome and thank you for signing up to be a Member of [SiteTitle].\r\n\r\nYour login is: [Username]\r\nYour password is: [Password]\r\n\r\nTo activate your account (active within 24 hours) follow this Activation Membership link:\r\n[ActivationLink]\r\n\r\nWe look forward to helping you grow your business.\r\n\r\nWith best regards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Password]\');\">Password</a>] - Member&#039;s password<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[ActivationLink]\');\">ActivationLink</a>] - Member&#039;s activation link<br>\r\n', 1),
(3, 'Sponsor notification about a new activated referral', 'From [SiteTitle]: New personal referral is verified', 'Dear [SponsorFName] [SponsorLName], \r\n\r\nYour new enrollee has just become verified.\r\nTheir email address is [Email], name is [FirstName] [LastName].\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorFName]\');\">SponsorFName</a>] - Sponsor&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorLName]\');\">SponsorLName</a>] - Sponsor&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorUsername]\');\">SponsorUsername</a>] - Sponsor&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorEmail]\');\">SponsorEmail</a>] - Sponsor&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n', 1),
(4, 'Welcome email sent to member after successful registration', 'Welcome to [SiteTitle]', 'Welcome and thank you for signing up to be a Member of [SiteTitle].\r\n\r\nYour login is: [Username]\r\nYour password is: [Password]\r\n\r\nWe look forward to helping you grow your business.\r\n\r\nWith best regards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Password]\');\">Password</a>] - Member&#039;s password<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[RefLink]\');\">RefLink</a>] - Member&#039;s Referral Link<br>\r\n', 1),
(5, 'Forgot password email content with new access details', 'From [SiteTitle]: Your new access details', 'Dear [FirstName] [LastName], \r\n\r\nYou received this email because you have requested to remind you login details for [SiteTitle].\r\n\r\nYour login is: [Username]\r\n\r\nYour password is: [Password]\r\n\r\nYour referral link is: [RefLink]\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Password]\');\">Password</a>] - Member&#039;s password<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[RefLink]\');\">RefLink</a>] - Member&#039;s Referral Link<br>\r\n', 1),
(6, 'Pin code email after unsuccessfull log in attempt from wrong IP address', 'From [SiteTitle]: Changing Security Data', 'Dear [FirstName] [LastName], \r\n\r\nYou have tried to enter  [SiteTitle] from another IP address.\r\n\r\nTo change your current IP address click the link below end enter this pin-code: [PinCode]\r\n\r\n\r\n[CheckLink]\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[PinCode]\');\">PinCode</a>] - Member&#039;s pin code<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[CheckLink]\');\">CheckLink</a>] - Member&#039;s check link<br>\r\n', 1),
(7, 'Guest notification about a new ticket registration at the public support center', 'From [SiteTitle]: Your new ticket has been successfully registered', 'Dear [FirstName] [LastName], \r\n\r\nYour ticket was successfully sent to support center of [SiteTitle]. It will be soon answered.\r\n\r\n\r\nSubject of ticket: [TicketSubject]\r\n\r\nPlease use this direct link to view ticket status: \r\n\r\n[TicketLink] \r\n\r\n\r\nAlso you can view your ticket status using another way and following details:\r\n\r\nURL: [TicketShortLink] \r\n\r\nE-mail: [Email] \r\n\r\nTicket code: [TicketCode] \r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketSubject]\');\">TicketSubject</a>] - Subject of the ticket<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketCode]\');\">TicketCode</a>] - Ticket code<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketLink]\');\">TicketLink</a>] - Full ticket link<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketShortLink]\');\">TicketShortLink</a>] - Short ticket link<br>\r\n', 1),
(8, 'Guest notification about answer from the public support center', 'From [SiteTitle]: New answer from public support center', 'Dear [FirstName] [LastName], \r\n\r\nYou have just received an answer on your ticket.\r\n\r\nPlease use this direct link to view ticket status: \r\n\r\n[TicketLink] \r\n\r\n\r\nAlso you can view your ticket status using another way and following details:\r\n\r\nURL: [TicketShortLink] \r\n\r\nE-mail: [Email] \r\n\r\nTicket code: [TicketCode]\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketSubject]\');\">TicketSubject</a>] - Subject of the ticket<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketCode]\');\">TicketCode</a>] - Ticket code<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketLink]\');\">TicketLink</a>] - Full ticket link<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketShortLink]\');\">TicketShortLink</a>] - Short ticket link<br>\r\n', 1),
(9, 'Email template for members contact page', '[SiteTitle]: A message from [SenderFirstName] [SenderLastName] ([SenderID])!', 'Hello [FirstName] [LastName], \r\n\r\nSome message\r\n\r\n\r\n\r\n\r\nRegards,\r\n[SenderFirstName] [SenderLastName]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[ID]\');\">ID</a>] - Member&#039;s ID<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SenderFirstName]\');\">SenderFirstName</a>] - Sender&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SenderLastName]\');\">SenderLastName</a>] - Sender&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SenderID]\');\">SenderID</a>] - Sender&#039;s ID<br>\r\n', 1),
(10, 'Email template for members Tell Friend page', 'From [SiteTitle]: Hi [FirstName] [LastName]!', 'Hello [FirstName] [LastName], \r\n\r\nI just had to tell you about this great site I just found.\r\n\r\nCheck it out for yourself at [RefLink]\r\n\r\n\r\n\r\nRegards,\r\n[SenderFirstName] [SenderLastName]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SenderFirstName]\');\">SenderFirstName</a>] - Sender&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SenderLastName]\');\">SenderLastName</a>] - Sender&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[RefLink]\');\">RefLink</a>] - Sender&#039;s Referral Link<br>\r\n', 1),
(11, 'Successfull payment notification', 'From [SiteTitle]: Successful payment', 'Hello [FirstName] [LastName], \r\n\r\nYou have made a successful [Processor] payment.\r\n\r\nAmount: $[Amount]\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Processor]\');\">Processor</a>] - Payment Processor<br>\r\n', 1),
(12, 'Getting commissions / forced matrix mode', 'From [SiteTitle]: Your membership earned commissions', 'Congratulations [FirstName] [LastName], \r\n\r\nYour [SiteTitle] membership earned you $[Amount].\r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n', 1),
(13, 'Matrix completion and getting commissions / cycling matrix mode', 'From [SiteTitle]: Your membership earned commissions', 'Congratulations [FirstName] [LastName], \r\n\r\nYou just completed [Matrix] matrix on [SiteTitle] and earned $[Amount].\r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Matrix]\');\">Matrix</a>] - Title of completed matrix<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n', 1),
(14, 'Matrix completion and getting commissions by sponsor/ cycling mode', 'From [SiteTitle]: Your membership earned commissions', 'Congratulations [FirstName] [LastName], \r\n\r\nYour referral #[RefID] just completed [Matrix] matrix on [SiteTitle] and earned you $[Amount].\r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Matrix]\');\">Matrix</a>] - Title of completed matrix<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[RefID]\');\">RefID</a>] - Referral ID<br>\r\n', 1),
(15, 'Sponsor bonus notification for personally enrolled', 'From [SiteTitle]: You earned sponsor bonus', 'Congratulations [FirstName] [LastName], \r\n\r\nYou earned [SiteTitle] sponsor bonus : $[Amount].\r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n', 1),
(16, 'Successfull withdrawal request completion notification', 'From [SiteTitle]: your withdrawal request is completed', 'Hello [FirstName] [LastName], \r\n\r\nYour withdrawal request was successfully completed.\r\n\r\n$[Amount] was paid to your account.\r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n', 1),
(17, 'End of active period notification/ forced mode', 'From [SiteTitle]: active period expired', 'Hello [FirstName] [LastName], \r\n\r\nYour Account has expired. \r\n\r\nYou should log in to your member area now to make a payment, ensuring that you retain active status in the pay plan and do not lose any benefits. \r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n', 1),
(18, 'Pre Launch notification', '[SiteTitle] is launched', 'Hello [FirstName] [LastName],\r\n\r\nWe are glad to inform you that starting from now you can Upgrade your account in <a href=\'[SiteUrl]\'>[SiteTitle]</a>.\r\n\r\nPlease login using your credentials. \r\n\r\nWith best regards,\r\n[SiteTitle] Team\r\n', '', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `faq`
--

CREATE TABLE `faq` (
  `faq_id` int(11) NOT NULL,
  `question` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `answer` text COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `fees`
--

CREATE TABLE `fees` (
  `fee_id` int(11) NOT NULL,
  `to_order_index` int(11) NOT NULL DEFAULT '0',
  `plevel` int(3) NOT NULL DEFAULT '0',
  `fee_member` decimal(12,2) NOT NULL DEFAULT '0.00',
  `fee_sponsor` decimal(12,2) NOT NULL DEFAULT '0.00',
  `from_order_index` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `lands`
--

CREATE TABLE `lands` (
  `land_id` int(11) NOT NULL,
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `z_date` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `logs`
--

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL,
  `z_date` int(11) NOT NULL DEFAULT '0',
  `ip_addr` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `descr` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `logs`
--

INSERT INTO `logs` (`log_id`, `z_date`, `ip_addr`, `descr`) VALUES
(1, 1563515164, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(2, 1563531028, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(3, 1563538659, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(4, 1564377825, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(5, 1564390739, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(6, 1564398421, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(7, 1564470901, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(8, 1564557369, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(9, 1564645375, '178.128.82.122', 'Logged in succesfully.'),
(10, 1564645691, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(11, 1565850917, '109.104.165.233', 'Logged in succesfully.'),
(12, 1567773136, '109.104.165.233', 'Logged in succesfully.'),
(13, 1567778643, '109.104.165.233', 'Logged in succesfully.'),
(14, 1568098978, '109.104.165.233', 'Logged in succesfully.'),
(15, 1568366909, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(16, 1568379812, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(17, 1568731469, '178.128.82.122', 'Logged in succesfully.'),
(18, 1571504011, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(19, 1576491477, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(20, 1578475258, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(21, 1578475446, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(22, 1582812343, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(23, 1583946254, '2a00:bc00:8800:b665:', 'Logged in succesfully.'),
(24, 1603784814, '79.175.57.168', 'Logged in succesfully.'),
(25, 1607324602, '79.175.57.168', 'Incorrect login attempt. Password or Username do not match.'),
(26, 1607324605, '79.175.57.168', 'Logged in succesfully.'),
(27, 1607407221, '79.175.57.168', 'Logged in succesfully.'),
(28, 1607522289, '79.175.57.168', 'Logged in succesfully.'),
(29, 1612164279, '79.175.57.168', 'Logged in succesfully.'),
(30, 1612164377, '79.175.57.168', 'Logged in succesfully.'),
(31, 1612166974, '2a00:bc00:8800:b665:', 'Logged in succesfully.');

-- --------------------------------------------------------

--
-- Структура таблицы `matrices_completed`
--

CREATE TABLE `matrices_completed` (
  `matrix_id` int(11) NOT NULL,
  `place_id` int(11) DEFAULT '0',
  `z_date` int(11) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `matrix`
--

CREATE TABLE `matrix` (
  `matrix_id` int(11) NOT NULL,
  `m_level` int(11) DEFAULT '0',
  `host_id` int(11) DEFAULT '0',
  `host_matrix` int(11) DEFAULT '0',
  `referrer_id` int(11) DEFAULT '0',
  `referrer_matrix` int(11) DEFAULT '0',
  `member_id` int(11) DEFAULT '0',
  `member_matrix` int(11) DEFAULT '0',
  `z_date` int(11) DEFAULT '0',
  `is_completed` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `matrix`
--

INSERT INTO `matrix` (`matrix_id`, `m_level`, `host_id`, `host_matrix`, `referrer_id`, `referrer_matrix`, `member_id`, `member_matrix`, `z_date`, `is_completed`) VALUES
(1, 1, 0, 0, 0, 0, 1, 0, 1612174529, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `matrixes`
--

CREATE TABLE `matrixes` (
  `matrix_id` int(11) NOT NULL,
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `width` int(3) DEFAULT '0',
  `depth` int(3) DEFAULT '0',
  `entrance_fee` decimal(12,2) NOT NULL DEFAULT '0.00',
  `is_mode` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `matrixes`
--

INSERT INTO `matrixes` (`matrix_id`, `title`, `width`, `depth`, `entrance_fee`, `is_mode`, `is_active`) VALUES
(1, 'Forced Matrix', 2, 3, '10.00', 1, 1),
(2, 'Cycling Matrix', 2, 2, '20.00', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `members`
--

CREATE TABLE `members` (
  `member_id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `replica` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_replica` tinyint(1) NOT NULL DEFAULT '0',
  `is_a_replica` tinyint(1) NOT NULL DEFAULT '0',
  `enroller_id` int(11) NOT NULL DEFAULT '0',
  `passwd` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `street` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `postal` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `reg_date` int(11) NOT NULL DEFAULT '0',
  `last_access` int(11) NOT NULL DEFAULT '0',
  `m_level` int(3) NOT NULL DEFAULT '0',
  `processor` int(11) NOT NULL DEFAULT '0',
  `account_id` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `quant_pay` int(5) NOT NULL DEFAULT '0',
  `ip_check` tinyint(1) NOT NULL DEFAULT '0',
  `ip_address` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pin_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `is_dead` tinyint(1) NOT NULL DEFAULT '0',
  `date_active` int(11) DEFAULT '0',
  `b1` int(11) DEFAULT '0',
  `b3` int(11) DEFAULT '0',
  `b5` int(11) DEFAULT '0',
  `prelaunch_norif` int(1) DEFAULT '0',
  `alert_data` text COLLATE utf8_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `members`
--

INSERT INTO `members` (`member_id`, `username`, `replica`, `is_replica`, `is_a_replica`, `enroller_id`, `passwd`, `email`, `first_name`, `last_name`, `street`, `city`, `state`, `country`, `postal`, `phone`, `reg_date`, `last_access`, `m_level`, `processor`, `account_id`, `quant_pay`, `ip_check`, `ip_address`, `pin_code`, `is_active`, `is_dead`, `date_active`, `b1`, `b3`, `b5`, `prelaunch_norif`, `alert_data`) VALUES
(1, 'admin', '', 0, 0, 0, '21232f297a57a5a743894a0e4a801fc3', 'admin@admin.com', 'Admin', 'Admin', '', '', '', '', '', '', 1562240414, 0, 1, 0, '', 3, 0, '', '', 1, 0, 0, 0, 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `txid` varchar(64) DEFAULT NULL,
  `member_id` int(11) DEFAULT '0',
  `name_member_id` int(11) DEFAULT '0',
  `to_member_id` int(11) DEFAULT '0',
  `subject` varchar(512) DEFAULT '',
  `body` text,
  `date` int(11) DEFAULT '0',
  `attach` varchar(1024) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `is_deleted` tinyint(1) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `messages`
--

INSERT INTO `messages` (`id`, `txid`, `member_id`, `name_member_id`, `to_member_id`, `subject`, `body`, `date`, `attach`, `is_read`, `is_deleted`) VALUES
(63, '2ae67f3b83cac9772b8f90ec83090d9b', 1, 3, 3, 'My message', '', 1484636813, NULL, 0, 0),
(55, '702641fc024fb873c69e6c4ef465f37f', 1, 2, 2, 'RE: 1&amp;gt;2', '', 1484393922, NULL, 0, 0),
(56, '226786203465ecfa01815f44508bf620', 2, 1, 2, 'RE: 1&amp;gt;2', '', 1484393922, NULL, 1, 0),
(61, 'dbac849aee88d6d73722aca3e628a5e0', 1, 2, 2, '1&amp;gt;2', '', 1484394819, '34351071.jpg', 1, 0),
(62, '86a2fe69475e04648680e657a9b90230', 2, 1, 2, '1&amp;gt;2', '', 1484394819, '34351071.jpg', 0, 0),
(58, '161b4820f922a8e6d24b60aa6beade52', 1, 2, 1, 'RE: 1&amp;gt;2', '', 1484394226, NULL, 1, 0),
(53, '557547181d19b91977a666dd7dc66ece', 1, 2, 2, '1&amp;gt;2', '', 1484393874, NULL, 1, 0),
(54, '0024c94a13756ba0d009676f718b1c95', 2, 1, 2, '1&amp;gt;2', '', 1484393874, NULL, 1, 0),
(60, 'd2a8890edd87d09153813cb3dfede0f6', 1, 2, 1, 'RE: RE: 1&amp;gt;2', '', 1484394237, NULL, 1, 0),
(93, '309fda9c60b55fa77413a7b2cebccd49', 1, 3, 3, 'RE: hi Attach', 'Glad to hear you', 1484739922, '34351071.jpg', 0, 0),
(92, 'ee52c6c5f0632bce6871b5101680edcd', 3, 1, 3, 'RE: hi', 'Very nice picture', 1484739880, NULL, 1, 0),
(66, '20d003dd105af52a3663b6e1074b3fd0', 1, 3, 1, 'RE: My message', 'cool', 1484636887, NULL, 1, 0),
(68, 'e158a0c11918988030fd922d176db73b', 1, 3, 1, 'RE: My message', '', 1484733819, NULL, 1, 0),
(91, '771866731bcc6272b50c9ef146643492', 1, 3, 3, 'RE: hi', 'Very nice picture', 1484739880, NULL, 0, 0),
(70, '0b21805b1430fd673b40885d4451378c', 1, 3, 1, 'RE: My message', '', 1484733852, NULL, 1, 0),
(90, 'ad6b204b25effcc5861dc68844820f78', 1, 3, 1, 'hi', 'Glad to hear you', 1484739762, 'test.jpg', 1, 0),
(72, '7efe24f0528ab1bfe00ad786b370a486', 2, 3, 2, 'hi', 'ge', 1484734300, NULL, 1, 0),
(73, '88e71544bda053f7ee04dfed8b8f4be0', 2, 3, 3, 'RE: hi', 'hi there', 1484734332, NULL, 1, 0),
(89, '2d753264a84106a023d6ea04cdb507f4', 3, 1, 1, 'hi', 'Glad to hear you', 1484739762, 'test.jpg', 0, 0),
(76, '46afefb7c81d8b17bbd8e9899dcec645', 2, 3, 2, 'RE: RE: hi', 'gfg', 1484734364, NULL, 0, 0),
(88, '96381b1697c37a8fbc22ce740ef5ed80', 3, 1, 3, 'RE: Hi admin', 'Hi test1!\r\n\r\n\r\nhere is the text', 1484739732, NULL, 1, 0),
(78, 'e3fe578f8090f3d8c19ca89d31278fd5', 2, 3, 2, 'RE: RE: RE: hi', 'gfg', 1484734375, 'Customer-support-girl-wearing-headsets.jpg', 1, 0),
(79, 'd3523b72cea372b0f714b08d330c1129', 2, 3, 3, 'RE: RE: RE: RE: hi', 'cool', 1484734425, NULL, 1, 0),
(87, 'b91c06674dec97604360c56a518d7c32', 1, 3, 3, 'RE: Hi admin', 'Hi test1!\r\n\r\n\r\nhere is the text', 1484739732, NULL, 0, 0),
(81, '6b4c6bd48cac3a0b3084a997ba4c6f04', 2, 3, 3, 'RE: RE: RE: RE: hi', 'gfg', 1484734445, NULL, 0, 0),
(86, '7ecec086abcf18ca40b0de83d975cdd3', 1, 3, 1, 'Hi admin', 'here is the text', 1484739706, NULL, 1, 0),
(84, '4cec0832e9c93a2dcae15f05395de8c1', 2, 3, 2, 'RE: RE: RE: RE: RE: hi', 'gfg', 1484734473, NULL, 0, 0),
(85, 'ec3fd10387bb3384833872accf616547', 3, 1, 1, 'Hi admin', 'here is the text', 1484739706, NULL, 0, 0),
(94, 'b913cd81c94887855edad883075459a3', 3, 1, 3, 'RE: hi Attach', 'Glad to hear you', 1484739922, '34351071.jpg', 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

CREATE TABLE `news` (
  `news_id` int(11) NOT NULL,
  `news_date` int(11) NOT NULL DEFAULT '0',
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `article` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `destination` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `online_stats`
--

CREATE TABLE `online_stats` (
  `online_stat_id` int(11) NOT NULL,
  `session_id` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `z_date` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `online_stats`
--

INSERT INTO `online_stats` (`online_stat_id`, `session_id`, `member_id`, `z_date`) VALUES
(1267, '77db2d2d52f7149f79bae67d25085735', 1, 1612168603),
(1266, '1d75b5268f56a6126ec18b6a1518907f', 1, 1612167987),
(1265, 'e1rfe3jgrj225eh4n1rnu4q915', 0, 1607535257);

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

CREATE TABLE `pages` (
  `page_id` int(11) NOT NULL,
  `order_index` int(5) NOT NULL DEFAULT '0',
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_title` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `keywords` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `in_menu` tinyint(1) NOT NULL DEFAULT '0',
  `is_member` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `level1` tinyint(1) NOT NULL DEFAULT '0',
  `level2` tinyint(1) NOT NULL DEFAULT '0',
  `level3` tinyint(1) NOT NULL DEFAULT '0',
  `level4` tinyint(1) NOT NULL DEFAULT '0',
  `level5` tinyint(1) NOT NULL DEFAULT '0',
  `level6` tinyint(1) NOT NULL DEFAULT '0',
  `level7` tinyint(1) NOT NULL DEFAULT '0',
  `level8` tinyint(1) NOT NULL DEFAULT '0',
  `level9` tinyint(1) NOT NULL DEFAULT '0',
  `level10` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`page_id`, `order_index`, `title`, `menu_title`, `content`, `keywords`, `description`, `in_menu`, `is_member`, `is_active`, `level1`, `level2`, `level3`, `level4`, `level5`, `level6`, `level7`, `level8`, `level9`, `level10`) VALUES
(1, 1, 'Start Page', 'Home', '&lt;div style=\"text-align: left;\"&gt;&lt;strong&gt;&lt;span style=\"font-size: 18pt;\"&gt;&lt;img src=\"/uploads/image/indexman.jpg\" width=\"466\" height=\"411\" align=\"left\" alt=\"\" /&gt;COMING SOON&lt;/span&gt;&lt;/strong&gt;&lt;/div&gt;', '', '', 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
(2, 1, 'Terms and Conditions', 'Terms and Conditions', 'Coming Soon...', '', '', 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `payins`
--

CREATE TABLE `payins` (
  `payins_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `transaction_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `processor` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `z_date` int(11) NOT NULL DEFAULT '0',
  `product_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `payins_log`
--

CREATE TABLE `payins_log` (
  `id` int(11) NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `processor` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `z_date` int(11) DEFAULT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `places`
--

CREATE TABLE `places` (
  `place_id` int(11) NOT NULL,
  `member_id` int(11) DEFAULT '0',
  `referrer_place_id` int(11) DEFAULT '0',
  `m_level` int(11) DEFAULT '0',
  `reentry` int(5) NOT NULL DEFAULT '0',
  `z_date` int(11) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `processors`
--

CREATE TABLE `processors` (
  `processor_id` int(11) NOT NULL,
  `code` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `account_id` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `routine_url` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extra_field` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fee` decimal(12,2) NOT NULL DEFAULT '0.00',
  `is_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `processors`
--

INSERT INTO `processors` (`processor_id`, `code`, `name`, `account_id`, `routine_url`, `extra_field`, `fee`, `is_active`) VALUES
(3, 'alertpay', 'Payza', '', 'https://secure.payza.com/checkout', '', '0.00', 0),
(5, 'solidtrustpay', 'Solid Trust Pay', '', 'https://solidtrustpay.com/handle.php', '', '0.00', 0),
(8, 'paypal', 'PayPal', '', 'https://www.paypal.com/cgi-bin/webscr', '', '0.00', 0),
(9, 'perfectmoney', 'PerfectMoney', '', 'https://perfectmoney.is/api/step1.asp', '', '0.00', 0),
(10, 'egopay', 'EgoPay', '', 'https://www.egopay.com/payments/pay/form', '', '0.00', 0),
(7, 'okpay', 'OkPay', '', 'https://www.okpay.com/process.html', '', '0.00', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `file` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `photo` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `ptools`
--

CREATE TABLE `ptools` (
  `ptool_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `photo` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `pub_tickets`
--

CREATE TABLE `pub_tickets` (
  `pub_ticket_id` int(11) NOT NULL,
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ticket_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subject` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date_create` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `pub_ticket_messages`
--

CREATE TABLE `pub_ticket_messages` (
  `pub_ticket_message_id` int(11) NOT NULL,
  `pub_ticket_id` int(11) NOT NULL DEFAULT '0',
  `support_message` tinyint(1) NOT NULL DEFAULT '0',
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `date_post` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `replicas`
--

CREATE TABLE `replicas` (
  `replica_id` int(11) NOT NULL,
  `order_index` int(11) NOT NULL DEFAULT '0',
  `member_id` int(5) NOT NULL DEFAULT '0',
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_title` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `replicas`
--

INSERT INTO `replicas` (`replica_id`, `order_index`, `member_id`, `title`, `menu_title`, `content`, `is_active`) VALUES
(6, 1, 1, 'test', 'PDF', '&lt;p&gt;&amp;nbsp;кен&lt;/p&gt;', 1),
(5, 1, 5, 'my page', 'my page', '&lt;p&gt;&amp;nbsp;my page&lt;/p&gt;', 1),
(7, 1, 2, 'My Page', 'My Page', '&lt;p&gt;text here&amp;nbsp;&lt;/p&gt;', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `selected`
--

CREATE TABLE `selected` (
  `selected_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `selected`
--

INSERT INTO `selected` (`selected_id`, `member_id`) VALUES
(2, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

CREATE TABLE `settings` (
  `setting_id` int(11) NOT NULL,
  `keyname` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `value` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`setting_id`, `keyname`, `value`) VALUES
(1, 'AdminUsername', 'admin'),
(2, 'AdminPassword', 'fc93f0a8fa5c3527b8d0ad486df7e6e3'),
(3, 'AdminAltPassword', '21232f297a57a5a743894a0e4a801fc3'),
(4, 'SiteTitle', 'DEV RunMLM Builder Script'),
(5, 'SiteUrl', 'http://mlm37.runmlm.com/'),
(6, 'PathSite', '/home/irushost/runmlm.com/mlm37/'),
(7, 'ContactEmail', 'support@runmlm.com'),
(8, 'UseSMTPAutorisation', '0'),
(9, 'SMTPServer', 'SMTPServer'),
(10, 'SMTPDomain', 'SMTPDomain'),
(11, 'SMTPUserName', 'SMTPUserName'),
(12, 'SMTPPassword', 'SMTPPassword'),
(13, 'SecurityMode', ''),
(14, 'IPAddress', ''),
(15, 'pin_code', ''),
(16, 'PaymentMode', ''),
(17, 'PaymentModeDate', '0'),
(18, 'payPeriod', '7'),
(19, 'monthPeriod', '999'),
(20, 'LastCronjobStart', '0'),
(21, 'MinCashOut', '0.00'),
(22, 'warnPeriod', '5'),
(23, 'matrix_mode', '2'),
(24, 'fee', '5.00'),
(25, 'PhotoBigMaxWidth', '400'),
(26, 'PhotoBigMaxHeight', '400'),
(27, 'PhotoSmallMaxWidth', '120'),
(28, 'PhotoSmallMaxHeight', '120'),
(29, 'cycling', '0'),
(30, 'sponsor_amount', '0.00'),
(31, 'sponsor_quant', '1'),
(32, 'product', 'Pay for membership'),
(33, 'subjectMail', 'Welcome to [SiteTitle]'),
(34, 'messageMail', 'Dear [FirstName] [LastName], \r\n\r\nSome message with tags.\r\n\r\nRegards,\r\n[SiteTitle]'),
(35, 'is_replica', '0'),
(36, 'quant_replica', '0'),
(37, 'SerialCode', '6QK5-TPW2-OL6E-FFFF'),
(38, 'StartDate', '1612164373'),
(39, 'AdminMessage', ''),
(40, 'useBanners', '0'),
(41, 'useBalance', '0'),
(42, 'useSecureMembers', '0'),
(43, 'useFoneMailing', '0'),
(44, 'useAutoresponder', '0'),
(45, 'useEshop', '0'),
(46, 'useValidation', '1'),
(47, 'quant_textadds', '0'),
(48, 'quant_textadds_show', '0'),
(49, 'quant_textadds_show_m', '0'),
(50, 'number_turing', '0'),
(51, 'payp_fromcash', '0'),
(52, 'is_pif', '0'),
(53, 'is_pif_cash', '0'),
(54, 'is_random', '1'),
(55, 'currency', '1'),
(56, 'ReferrerUrl', 'username'),
(57, 'FooterContent', 'Copyright © 2016. Powered by <a href=\"http://runmlm.com/\">MLM Builder Script</a>'),
(58, 'LicenseNumber', 'mlU1RBTkRBUkQ='),
(59, 'access', 'YYTo1Mjp7czo1OiJsYW5kcyI7YTo0OntzOjU6InRpdGxlIjtzOjEzOiJMYW5kaW5nIHBhZ2VzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NDoic3RhdCI7YTo0OntzOjU6InRpdGxlIjtzOjk6IkRhc2hib2FyZCI7czo0OiJGUkVFIjtpOjA7czo3OiJTVEFSVEVSIjtpOjA7czo4OiJTVEFOREFSRCI7aToxO31zOjExOiJtZW1iX21hdHJpeCI7YTo0OntzOjU6InRpdGxlIjtzOjEyOiJPdmVyYWxsIFRyZWUiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMToidXNlcl9hZG1pbnMiO2E6NTp7czo1OiJ0aXRsZSI7czoxNDoiQWRtaW5pc3RyYXRvcnMiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTtzOjY6ImFjY2VzcyI7aToxO31zOjY6Im1hbnVhbCI7YTo0OntzOjU6InRpdGxlIjtzOjE1OiJNYW51YWwgUGF5bWVudHMiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo1OiJwYWdlcyI7YTo1OntzOjU6InRpdGxlIjtzOjEyOiJQdWJsaWMgUGFnZXMiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTtzOjY6ImFjY2VzcyI7aToxO31zOjc6Im1fcGFnZXMiO2E6NDp7czo1OiJ0aXRsZSI7czoxMjoiTWVtYmVyIFBhZ2VzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NDoibmV3cyI7YTo0OntzOjU6InRpdGxlIjtzOjQ6Ik5ld3MiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo3OiJhcHRvb2xzIjthOjQ6e3M6NToidGl0bGUiO3M6MTM6IkFkbWluIGJhbm5lcnMiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxNToiYXV0b3Jlc3BvbmRlcnNmIjthOjQ6e3M6NToidGl0bGUiO3M6MzA6IkluYWN0aXZlIE1lbWJlcnMgQXV0b3Jlc3BvbmRlciI7czo0OiJGUkVFIjtpOjA7czo3OiJTVEFSVEVSIjtpOjA7czo4OiJTVEFOREFSRCI7aToxO31zOjE0OiJhdXRvcmVzcG9uZGVycyI7YTo0OntzOjU6InRpdGxlIjtzOjI5OiJBY3RpdmUgTWVtYmVycyBBdXRvcmVzcG9uZGVyICI7czo0OiJGUkVFIjtpOjA7czo3OiJTVEFSVEVSIjtpOjA7czo4OiJTVEFOREFSRCI7aToxO31zOjEwOiJhdGVtcGxhdGVzIjthOjQ6e3M6NToidGl0bGUiO3M6MjM6Ik1hc3MgTWFpbGluZyBUZW1wbGF0ZXMgIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NzoibWFpbGluZyI7YTo0OntzOjU6InRpdGxlIjtzOjE1OiJTZW5kIE1hc3MgRW1haWwiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo2OiJiYWNrdXAiO2E6NDp7czo1OiJ0aXRsZSI7czo3OiJCYWNrdXBzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTM6InVzZVZhbGlkYXRpb24iO2E6NDp7czo1OiJ0aXRsZSI7czowOiIiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo2OiJpc19waWYiO2E6NDp7czo1OiJ0aXRsZSI7czowOiIiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMToiaXNfcGlmX2Nhc2giO2E6NDp7czo1OiJ0aXRsZSI7czowOiIiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czozOiJmYXEiO2E6NDp7czo1OiJ0aXRsZSI7czozOiJGQVEiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo2OiJwdG9vbHMiO2E6NDp7czo1OiJ0aXRsZSI7czoxNToiTWVtYmVycyBCYW5uZXJzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTA6ImlzX3JlcGxpY2EiO2E6NDp7czo1OiJ0aXRsZSI7czoxNjoiUmVwbGljYXRlZCBTaXRlcyI7czo0OiJGUkVFIjtpOjA7czo3OiJTVEFSVEVSIjtpOjA7czo4OiJTVEFOREFSRCI7aToxO31zOjEzOiJxdWFudF9yZXBsaWNhIjthOjQ6e3M6NToidGl0bGUiO3M6MDoiIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NzoidGlja2V0cyI7YTo0OntzOjU6InRpdGxlIjtzOjE5OiJTdXBwb3J0IGZvciBtZW1iZXJzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTE6InB1Yl90aWNrZXRzIjthOjQ6e3M6NToidGl0bGUiO3M6MjA6IlN1cHBvcnQgZm9yIHZpc2l0b3JzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTA6ImNhdGVnb3JpZXMiO2E6NDp7czo1OiJ0aXRsZSI7czoxNzoiRXNob3AgQ2F0ZWdvcmllcyAiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo4OiJwcm9kdWN0cyI7YTo0OntzOjU6InRpdGxlIjtzOjE1OiJFc2hvcCBQcm9kdWN0cyAiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo5OiJzaG9wX2ZlZXMiO2E6NDp7czo1OiJ0aXRsZSI7czoxMToiRXNob3AgRmVlcyAiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMzoidHVyaW5nX251bWJlciI7YTo0OntzOjU6InRpdGxlIjtzOjA6IiI7czo0OiJGUkVFIjtpOjA7czo3OiJTVEFSVEVSIjtpOjA7czo4OiJTVEFOREFSRCI7aToxO31zOjg6ImN1cnJlbmN5IjthOjQ6e3M6NToidGl0bGUiO3M6MDoiIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTM6InBheXBfZnJvbWNhc2giO2E6NDp7czo1OiJ0aXRsZSI7czowOiIiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMToidHJlZV9tYXRyaXgiO2E6NDp7czo1OiJ0aXRsZSI7czowOiIiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxNzoidGVtcGxhdGVfZWxlbWVudHMiO2E6NDp7czo1OiJ0aXRsZSI7czoxNzoiVGVtcGxhdGUgRWxlbWVudHMiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo1OiJsb2dpbiI7YTo0OntzOjU6InRpdGxlIjtzOjEwOiJMb2dpbiBmb3JtIjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NzoibWVtYmVycyI7YTo0OntzOjU6InRpdGxlIjtzOjExOiJNZW1iZXIgbGlzdCI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjEyOiJhZG1pbmRldGFpbHMiO2E6NDp7czo1OiJ0aXRsZSI7czoxMjoiYWRtaW5kZXRhaWxzIjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6ODoic2V0dGluZ3MiO2E6NDp7czo1OiJ0aXRsZSI7czo4OiJzZXR0aW5ncyI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjg6Im1hdHJpeGVzIjthOjQ6e3M6NToidGl0bGUiO3M6ODoibWF0cml4ZXMiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo2OiJsZXZlbHMiO2E6NDp7czo1OiJ0aXRsZSI7czo2OiJsZXZlbHMiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMzoibGV2ZWxzX2ZvcmNlZCI7YTo0OntzOjU6InRpdGxlIjtzOjEzOiJsZXZlbHNfZm9yY2VkIjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NjoiYWRtaW5zIjthOjQ6e3M6NToidGl0bGUiO3M6NjoiYWRtaW5zIjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NzoicGF5bWVudCI7YTo0OntzOjU6InRpdGxlIjtzOjc6InBheW1lbnQiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo0OiJjYXNoIjthOjQ6e3M6NToidGl0bGUiO3M6NDoiY2FzaCI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjg6ImNhc2hfb3V0IjthOjQ6e3M6NToidGl0bGUiO3M6ODoiY2FzaF9vdXQiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMDoicHJvY2Vzc29ycyI7YTo0OntzOjU6InRpdGxlIjtzOjEwOiJwcm9jZXNzb3JzIjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NDoidGFkcyI7YTo0OntzOjU6InRpdGxlIjtzOjQ6InRhZHMiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo5OiJ0ZW1wbGF0ZXMiO2E6NDp7czo1OiJ0aXRsZSI7czo5OiJ0ZW1wbGF0ZXMiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo0OiJmZWVzIjthOjQ6e3M6NToidGl0bGUiO3M6NDoiZmVlcyI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjg6Im1fbGV2ZWxzIjthOjQ6e3M6NToidGl0bGUiO3M6ODoibV9sZXZlbHMiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMzoiZm9yY2VkX21hdHJpeCI7YTo0OntzOjU6InRpdGxlIjtzOjEzOiJmb3JjZWRfbWF0cml4IjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTI6InJlcGxpY2Ffc2l0ZSI7YTo0OntzOjU6InRpdGxlIjtzOjEyOiJyZXBsaWNhX3NpdGUiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo3OiJzaG9wZmVlIjthOjQ6e3M6NToidGl0bGUiO3M6Nzoic2hvcGZlZSI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjE0OiJ1cGxvYWRfbWVtYmVycyI7YTo0OntzOjU6InRpdGxlIjtzOjE0OiJ1cGxvYWRfbWVtYmVycyI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjY6InNsaWRlciI7YTo0OntzOjU6InRpdGxlIjtzOjY6InNsaWRlciI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO319'),
(60, 'Commissions_Value', '1'),
(61, 'PRE_LAUNCH', '0'),
(62, 'PRE_LAUNCH_DATE', '0'),
(63, 'matching_bonus', '0'),
(64, 'matching_bonus_value', '0'),
(65, 'time_after_launch', '36'),
(66, 'Carousel_autoplayTimeout', '3000'),
(67, 'SPONSOR_VALUE', '2'),
(70, 'WITHDRAWAL_VALUE', '2'),
(71, 'currency_rate', '0.00014613');

-- --------------------------------------------------------

--
-- Структура таблицы `shop_fees`
--

CREATE TABLE `shop_fees` (
  `fee_id` int(11) NOT NULL,
  `to_order_index` int(11) NOT NULL DEFAULT '0',
  `plevel` int(3) NOT NULL DEFAULT '0',
  `fee_member` decimal(12,2) NOT NULL DEFAULT '0.00',
  `fee_sponsor` decimal(12,2) NOT NULL DEFAULT '0.00',
  `from_order_index` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `slider`
--

INSERT INTO `slider` (`id`, `text`, `image`) VALUES
(6, '', '0r4i1rsax4t4u1ttqjd1.png'),
(7, '', 'cq345v2pzhkxqi2b42iw.png'),
(8, '', '1lcwaw0djokgzoiknrxg.png');

-- --------------------------------------------------------

--
-- Структура таблицы `sn_messages`
--

CREATE TABLE `sn_messages` (
  `id` int(11) NOT NULL,
  `subj` varchar(256) NOT NULL,
  `mess` text NOT NULL,
  `date` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sn_messages`
--

INSERT INTO `sn_messages` (`id`, `subj`, `mess`, `date`) VALUES
(5, '13245 2345 2345', '2345 2345 2345', 1337226509),
(6, '3465', '&lt;br&gt;3563 456 34563456 3456 3456', 1337231899),
(7, 'Re: 3465', '568&lt;br&gt;', 1337241214),
(20, 'Re: Re: 3465', 'sdfg sdfg&lt;div&gt;s&lt;/div&gt;&lt;div&gt;&lt;b&gt;sdfgsdfg&lt;i&gt;sdfgsdfgsdfg&lt;/i&gt;&lt;/b&gt;&lt;/div&gt;', 1337310463),
(9, 'Re: 3465', '2345', 1337241586),
(10, 'Re: 3465', 'rtyurtyu', 1337241614),
(11, 'Re: 3465', 'ghjkghjkghjkghjkghjkuio', 1337241760),
(12, 'Re: 3465', 'С‹РІР°Рї С‹РІ&lt;strong&gt;С‹РІР°РїС‹РІР°Рї&lt;/strong&gt;', 1337242022),
(13, 'Re: 3465', '&lt;p&gt;asd&lt;strong&gt;asdasd&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;&lt;br&gt;&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;dd&lt;em&gt;dd&lt;/em&gt;&lt;br&gt;&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;&lt;em&gt;&lt;br&gt;&lt;/em&gt;&lt;/strong&gt;&lt;/p&gt;', 1337242392),
(14, 'Re: 3465', '&lt;p&gt;sdfg&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;sdfgsdf&lt;/strong&gt;&lt;/p&gt;', 1337242418),
(16, 'Re: 3465', '&lt;p&gt;hi &lt;/p&gt;&lt;p&gt;&lt;strong&gt;!!ept&lt;/strong&gt;&lt;br&gt;&lt;/p&gt;', 1337244713),
(17, 'Re: 13245 2345 2345', '&lt;br&gt;tyuityui', 1337244967),
(21, 'Re: Re: 3465', 'dfhdfgh', 1337310545),
(22, 'tyuityui', 'tyui,tyuityutyui &amp;nbsp;ui', 1337311399),
(23, '45674567', '456 4567 4567 4567 4567', 1337311474),
(24, 'tyuityui', 'tyui,tyuityutyui &amp;nbsp;ui', 1337311760),
(25, 'Hi!', '&lt;p&gt;Hello!&lt;/p&gt;&lt;p&gt;How are you?&lt;/p&gt;', 1337312357),
(26, 'Re: Hi!', 'Hi Alex. Great! Please answer this message asap', 1337321801),
(27, 'Re: Re: Hi!', 'hello&lt;br&gt;', 1337321962),
(28, 'Re: Re: Hi!', 'I read your message.&lt;br&gt;', 1337322089),
(29, '222', '22222qwe rqwer&amp;nbsp;', 1337322601),
(30, 'I do it', 'it&#039;s ready', 1337322679),
(31, 'Re: I do it', '&lt;ul&gt;&lt;ul&gt;&lt;li&gt;&lt;u&gt;&lt;b&gt;ah@et&#039;&lt;/b&gt;&lt;/u&gt;&lt;/li&gt;&lt;/ul&gt;&lt;ol&gt;&lt;ol&gt;&lt;li&gt;&lt;b&gt;&lt;u&gt;1&lt;i&gt;&amp;nbsp;ggg&lt;/i&gt;&lt;/u&gt;&lt;/b&gt;&lt;/li&gt;&lt;/ol&gt;&lt;li&gt;&lt;b&gt;&lt;u&gt;&lt;br&gt;&lt;/u&gt;&lt;/b&gt;&lt;/li&gt;&lt;/ol&gt;&lt;/ul&gt;', 1337326023),
(32, 'Re: 222', 'rtyurtyu&lt;br&gt;', 1337341143),
(33, 'Re: 222', 'rtyurtyuuuu&lt;br&gt;', 1337341155),
(34, 'Counter is ready', 'You can see it.', 1337341742),
(35, 'Test Message', 'Testing one, two, three.', 1337341962),
(36, 'Re: Test Message', 'Roger', 1337342036),
(37, 'asdffff', 'asdf', 1338184196),
(42, '', '&lt;br&gt;', 1339238821),
(39, '785678', '65785&lt;br&gt;', 1338200571),
(40, 'Wow', '&lt;b style=\"color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans; font-size: 11px; line-height: 14px; \"&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pharetra ullamcorper eros, id viverra nulla consequat sit amet. Mauris malesuada magna quis sem dapibus ut iaculis ipsum pretium. Cras id augue non elit pulvinar auctor. Proin aliquet cursus pharetra. Proin ullamcorper dolor vel leo luctus gravida euismod neque blandit. Aliquam dolor sapien, tincidunt eu imperdiet nec, viverra ut sapien. Aliquam ornare eros lobortis dolor blandit nec placerat leo dictum. Sed eu nibh tellus, et venenatis justo.&lt;/b&gt;', 1338879831),
(41, 'Wow', 'Superb', 1338881761),
(43, '12341234', '1234123&lt;br&gt;', 1340875730),
(44, 'jjjj', 'jjjj', 1340875739),
(45, '', '&lt;br&gt;', 1344941692),
(46, 'test', 'hello!', 1349437588),
(47, 'Subject', 'hello', 1349441558),
(48, '12', '12', 1349441689),
(49, 'regs', 'sdfgsdfg', 1350033139),
(50, 'xdfb', 'dfbsxf', 1350033207),
(51, 'q12341', '12qwerqwev rfwef qwe fq', 1350033338),
(52, 'test', 'xfgsdfgsdfgs', 1351162018),
(53, '11111', '11111111111', 1351164691),
(54, 'mess 1', 'mess 1 mess 1 mess 1 mess 1 mess 1 mess 1 mess 1 mess 1 mess 1', 1351233383),
(55, 'Re: mess 1', '', 1351235710),
(56, 'Re: mess 1', '', 1354525981),
(57, 'Re: Sent test4', '', 1354526046),
(58, 'Re: mess 1', '', 1354526146),
(59, 'Re: Re: mess 1', '111111111', 1354526450),
(60, 'Re: LikedВ В  one video-upload', '22222222', 1354526491),
(61, 'test tes tes', 'nvchrd6tfi876tfc iuy ygooy yugou g', 1354546965),
(62, '111111111', '2222222222222', 1354630305),
(63, '1111111', '2222222222fdddddddddd', 1354630565),
(64, '111111111', 'qqqqqqqqqqqqqqqqqqqqqqqq', 1356615168),
(65, 'Re: 111111111', '222222222222222', 1356615219),
(66, 'sdf', 'vgc', 1356615824),
(67, 'sdsd', 'sxdcssssssssss', 1356616090),
(68, '12121', 'sdg bsdg sdfgs fdg sd', 1358770558),
(69, '32323232', 'zdcv fg sfgzsfdgzs zsd', 1358770573),
(70, '111111', '11111111111111111111111', 1359462966),
(71, 'wer', 'weawdfsfds gsfd gsrg', 1365151361),
(72, 'wer', 'weawdfsfds gsfd gsrg', 1365151375),
(73, 'wer', 'weawdfsfds gsfd gsrg', 1365151380),
(74, 'wer', 'weawdfsfds gsfd gsrg', 1365151384),
(75, 'wer', 'weawdfsfds gsfd gsrg', 1365151721),
(76, 'wer', 'weawdfsfds gsfd gsrg', 1365151726),
(77, 'wer', 'weawdfsfds gsfd gsrg', 1365151730),
(78, 'wer', 'weawdfsfds gsfd gsrg', 1365151734),
(79, 'wer', 'weawdfsfds gsfd gsrg', 1365151738),
(80, 'Message from Chat', 'test message from chat', 1365156329),
(81, 'Message from Chat', 'jhgf', 1365497664),
(82, 'Message from Chat', 'jhgf', 1365497669),
(83, 'Message from Chat', 'jhgf', 1365497672),
(84, 'Message from Chat', 'jhgf', 1365497697),
(85, 'Message from Chat', 'jhgf', 1365497699),
(86, 'Message from Chat', 'jhgf', 1365497700),
(87, 'Message from Chat', 'jhgf', 1365497700),
(88, 'Message from Chat', 'sdfghjmk,', 1365503856),
(89, 'Message from Chat', ',mnhb', 1365503916),
(90, 'Message from Chat', ',mnhb', 1365503918);

-- --------------------------------------------------------

--
-- Структура таблицы `sn_messages_mem`
--

CREATE TABLE `sn_messages_mem` (
  `id` int(11) NOT NULL,
  `mess_id` int(11) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `from_member_id` int(11) NOT NULL DEFAULT '0',
  `to_member_id` int(11) NOT NULL DEFAULT '0',
  `read_mark` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sn_messages_mem`
--

INSERT INTO `sn_messages_mem` (`id`, `mess_id`, `member_id`, `from_member_id`, `to_member_id`, `read_mark`, `deleted`) VALUES
(14, 5, 1, 2, 1, 0, 0),
(13, 5, 1606, 1606, 15, 1, 1),
(12, 5, 1650, 1606, 1650, 1, 0),
(11, 5, 1606, 1606, 1650, 1, 1),
(10, 5, 1607, 1606, 1607, 0, 0),
(9, 5, 1606, 1606, 1607, 1, 1),
(15, 6, 1650, 1650, 1606, 0, 0),
(41, 21, 1650, 1650, 1606, 0, 0),
(40, 20, 1606, 1650, 1606, 1, 1),
(39, 20, 1650, 1650, 1606, 0, 0),
(19, 9, 1606, 1606, 1650, 1, 1),
(20, 9, 1650, 1606, 1650, 1, 0),
(21, 10, 1606, 1606, 1650, 1, 1),
(22, 10, 1650, 1606, 1650, 1, 0),
(23, 11, 1606, 1606, 1650, 1, 1),
(24, 11, 1650, 1606, 1650, 1, 0),
(25, 12, 1606, 1606, 1650, 1, 1),
(26, 12, 1650, 1606, 1650, 1, 0),
(27, 13, 1606, 1606, 1650, 1, 1),
(28, 13, 1650, 1606, 1650, 1, 0),
(29, 14, 1606, 1606, 1650, 1, 1),
(30, 14, 1650, 1606, 1650, 1, 0),
(31, 16, 1606, 1606, 1650, 1, 1),
(32, 16, 1650, 1606, 1650, 1, 1),
(33, 17, 1650, 1650, 1606, 0, 0),
(34, 17, 1606, 1650, 1606, 1, 1),
(42, 21, 1606, 1650, 1606, 1, 1),
(43, 22, 1606, 1606, 1650, 0, 1),
(44, 22, 1650, 1606, 1650, 1, 0),
(45, 23, 1606, 1606, 1611, 0, 1),
(46, 23, 1611, 1606, 1611, 1, 0),
(47, 24, 1606, 1606, 1611, 1, 1),
(48, 24, 1611, 1606, 1611, 1, 0),
(49, 25, 1606, 1606, 512, 1, 1),
(58, 29, 1606, 1611, 1606, 1, 0),
(51, 26, 512, 512, 1606, 0, 0),
(52, 26, 1606, 512, 1606, 1, 1),
(53, 27, 1606, 1606, 512, 1, 1),
(57, 29, 1611, 1611, 1606, 1, 0),
(55, 28, 1606, 1606, 512, 1, 1),
(56, 28, 512, 1606, 512, 1, 0),
(59, 30, 1606, 1606, 512, 1, 1),
(60, 30, 512, 1606, 512, 1, 0),
(61, 31, 512, 512, 1606, 0, 0),
(62, 31, 1606, 512, 1606, 1, 0),
(63, 32, 1606, 1606, 1611, 0, 1),
(64, 32, 1611, 1606, 1611, 1, 0),
(65, 33, 1606, 1606, 1611, 0, 1),
(66, 33, 1611, 1606, 1611, 1, 0),
(67, 34, 1606, 1606, 512, 1, 1),
(68, 34, 512, 1606, 512, 1, 0),
(69, 35, 2614, 2614, 512, 1, 0),
(70, 35, 512, 2614, 512, 1, 0),
(71, 36, 512, 512, 2614, 0, 0),
(72, 36, 2614, 512, 2614, 0, 0),
(73, 37, 1611, 1611, 1606, 1, 0),
(74, 37, 1606, 1611, 1606, 1, 0),
(83, 42, 1606, 1606, 2606, 0, 1),
(84, 42, 2606, 1606, 2606, 0, 0),
(77, 39, 1606, 1606, 1606, 1, 0),
(78, 39, 1606, 1606, 1606, 1, 0),
(79, 40, 512, 512, 512, 0, 0),
(80, 40, 512, 512, 512, 0, 0),
(81, 41, 1, 1, 512, 0, 0),
(82, 41, 512, 1, 512, 1, 0),
(85, 43, 1606, 1606, 1606, 0, 0),
(86, 43, 1606, 1606, 1606, 0, 0),
(87, 44, 1606, 1606, 1606, 0, 0),
(88, 44, 1606, 1606, 1606, 0, 0),
(89, 47, 2674, 2674, 2676, 1, 0),
(90, 47, 2676, 2674, 2676, 1, 0),
(117, 61, 2674, 2674, 2676, 1, 0),
(92, 48, 2676, 2674, 2676, 1, 0),
(93, 49, 2674, 2674, 2674, 0, 0),
(94, 49, 2674, 2674, 2674, 0, 0),
(95, 50, 2674, 2674, 2674, 0, 0),
(96, 50, 2674, 2674, 2674, 0, 0),
(97, 51, 2674, 2674, 2676, 1, 0),
(98, 51, 2676, 2674, 2676, 1, 0),
(99, 52, 2674, 2674, 2676, 1, 0),
(100, 52, 2676, 2674, 2676, 1, 0),
(101, 53, 2674, 2674, 2676, 1, 0),
(102, 53, 2676, 2674, 2676, 1, 0),
(103, 54, 2676, 2676, 2674, 1, 0),
(104, 54, 2674, 2676, 2674, 1, 0),
(105, 55, 2674, 2674, 2676, 1, 0),
(106, 55, 2676, 2674, 2676, 1, 0),
(107, 56, 2674, 2674, 2676, 1, 0),
(108, 56, 2676, 2674, 2676, 1, 0),
(109, 57, 2674, 2674, 2676, 1, 0),
(110, 57, 2676, 2674, 2676, 1, 0),
(111, 58, 2674, 2674, 2676, 1, 1),
(112, 58, 2676, 2674, 2676, 1, 0),
(113, 59, 2676, 2676, 2674, 0, 0),
(114, 59, 2674, 2676, 2674, 1, 1),
(115, 60, 2676, 2676, 2674, 0, 0),
(116, 60, 2674, 2676, 2674, 1, 1),
(118, 61, 2676, 2674, 2676, 1, 0),
(119, 62, 2674, 2674, 2676, 1, 0),
(120, 62, 2676, 2674, 2676, 1, 0),
(121, 62, 2674, 2674, 2641, 1, 0),
(122, 62, 2641, 2674, 2641, 0, 0),
(123, 63, 2674, 2674, 2676, 1, 0),
(124, 63, 2676, 2674, 2676, 1, 0),
(125, 64, 2674, 2674, 2676, 1, 0),
(126, 64, 2676, 2674, 2676, 1, 0),
(127, 65, 2676, 2676, 2674, 0, 0),
(128, 65, 2674, 2676, 2674, 1, 0),
(129, 68, 2676, 2676, 2674, 0, 0),
(130, 68, 2674, 2676, 2674, 1, 0),
(131, 69, 2676, 2676, 2674, 0, 0),
(132, 69, 2674, 2676, 2674, 0, 0),
(133, 70, 2674, 2674, 1, 1, 0),
(134, 70, 1, 2674, 1, 1, 0),
(135, 73, 2703, 2703, 2700, 0, 0),
(136, 73, 2700, 2703, 2700, 1, 1),
(137, 74, 2703, 2703, 2700, 0, 0),
(138, 74, 2700, 2703, 2700, 1, 1),
(139, 0, 2703, 2703, 2700, 0, 0),
(140, 0, 2700, 2703, 2700, 0, 1),
(141, 0, 2703, 2703, 2700, 0, 0),
(142, 0, 2700, 2703, 2700, 0, 0),
(143, 0, 2700, 2700, 2700, 0, 0),
(144, 0, 2700, 2700, 2700, 0, 0),
(145, 0, 2700, 2700, 2700, 0, 0),
(146, 0, 2700, 2700, 2700, 0, 0),
(147, 0, 2700, 2700, 2700, 0, 0),
(148, 0, 2700, 2700, 2700, 0, 0),
(149, 75, 2700, 2700, 2700, 0, 0),
(150, 75, 2700, 2700, 2700, 0, 0),
(151, 76, 2700, 2700, 2700, 0, 0),
(152, 76, 2700, 2700, 2700, 0, 0),
(153, 77, 2700, 2700, 2700, 0, 0),
(154, 77, 2700, 2700, 2700, 0, 0),
(155, 78, 2703, 2703, 2700, 0, 0),
(156, 78, 2700, 2703, 2700, 1, 0),
(157, 79, 2703, 2703, 2700, 0, 0),
(158, 79, 2700, 2703, 2700, 1, 0),
(159, 80, 2703, 2703, 2700, 0, 0),
(160, 80, 2700, 2703, 2700, 1, 0),
(161, 81, 2700, 2700, 2674, 0, 0),
(162, 81, 2674, 2700, 2674, 0, 0),
(163, 82, 2700, 2700, 2674, 0, 0),
(164, 82, 2674, 2700, 2674, 0, 0),
(165, 83, 2700, 2700, 2674, 0, 0),
(166, 83, 2674, 2700, 2674, 1, 0),
(167, 84, 2700, 2700, 2674, 0, 0),
(168, 84, 2674, 2700, 2674, 0, 0),
(169, 85, 2700, 2700, 2674, 0, 0),
(170, 85, 2674, 2700, 2674, 0, 1),
(171, 86, 2700, 2700, 2674, 0, 0),
(172, 86, 2674, 2700, 2674, 0, 1),
(173, 87, 2700, 2700, 2674, 0, 0),
(174, 87, 2674, 2700, 2674, 0, 1),
(175, 88, 2700, 2700, 2674, 0, 0),
(176, 88, 2674, 2700, 2674, 0, 1),
(177, 89, 2700, 2700, 2674, 0, 0),
(178, 89, 2674, 2700, 2674, 0, 1),
(179, 90, 2700, 2700, 2674, 0, 0),
(180, 90, 2674, 2700, 2674, 0, 1),
(181, 91, 2700, 2700, 2674, 0, 0),
(182, 91, 2674, 2700, 2674, 0, 1),
(183, 92, 2700, 2700, 2674, 0, 0),
(184, 92, 2674, 2700, 2674, 0, 1),
(185, 93, 2700, 2700, 2674, 0, 0),
(186, 93, 2674, 2700, 2674, 0, 1),
(187, 94, 2700, 2700, 2674, 0, 0),
(188, 94, 2674, 2700, 2674, 0, 1),
(189, 95, 2700, 2700, 2674, 0, 0),
(190, 95, 2674, 2700, 2674, 0, 1),
(191, 96, 2700, 2700, 2674, 0, 0),
(192, 96, 2674, 2700, 2674, 0, 1),
(193, 97, 2700, 2700, 2674, 0, 0),
(194, 97, 2674, 2700, 2674, 0, 1),
(195, 98, 2700, 2700, 2674, 0, 0),
(196, 98, 2674, 2700, 2674, 0, 1),
(197, 99, 2700, 2700, 2674, 0, 0),
(198, 99, 2674, 2700, 2674, 0, 1),
(199, 100, 2700, 2700, 2674, 0, 0),
(200, 100, 2674, 2700, 2674, 0, 1),
(201, 101, 2700, 2700, 2674, 0, 0),
(202, 101, 2674, 2700, 2674, 0, 1),
(203, 102, 2700, 2700, 2674, 0, 0),
(204, 102, 2674, 2700, 2674, 0, 1),
(205, 103, 2700, 2700, 2674, 0, 0),
(206, 103, 2674, 2700, 2674, 0, 1),
(207, 104, 2700, 2700, 2674, 0, 0),
(208, 104, 2674, 2700, 2674, 0, 1),
(209, 105, 2700, 2700, 2674, 0, 0),
(210, 105, 2674, 2700, 2674, 0, 1),
(211, 106, 2700, 2700, 2700, 0, 0),
(212, 106, 2700, 2700, 2700, 0, 0),
(213, 107, 2700, 2700, 2674, 0, 0),
(214, 107, 2674, 2700, 2674, 0, 1),
(215, 108, 2700, 2700, 2674, 0, 0),
(216, 108, 2674, 2700, 2674, 0, 1),
(217, 109, 2700, 2700, 2674, 0, 0),
(218, 109, 2674, 2700, 2674, 0, 1),
(219, 110, 2700, 2700, 2674, 0, 0),
(220, 110, 2674, 2700, 2674, 0, 1),
(221, 111, 2700, 2700, 2674, 0, 0),
(222, 111, 2674, 2700, 2674, 0, 1),
(223, 112, 2700, 2700, 2674, 0, 0),
(224, 112, 2674, 2700, 2674, 0, 1),
(225, 113, 2700, 2700, 2674, 0, 0),
(226, 113, 2674, 2700, 2674, 0, 1),
(227, 114, 2700, 2700, 2674, 0, 0),
(228, 114, 2674, 2700, 2674, 0, 1),
(229, 115, 2700, 2700, 2674, 0, 0),
(230, 115, 2674, 2700, 2674, 0, 1),
(231, 116, 2690, 2690, 2700, 0, 0),
(232, 116, 2700, 2690, 2700, 0, 0),
(233, 117, 2700, 2700, 2703, 0, 0),
(234, 117, 2703, 2700, 2703, 0, 1),
(235, 71, 2700, 2700, 2703, 0, 0),
(236, 71, 2703, 2700, 2703, 0, 1),
(237, 72, 2700, 2700, 2703, 0, 0),
(238, 72, 2703, 2700, 2703, 0, 1),
(239, 73, 2700, 2700, 2703, 0, 0),
(240, 73, 2703, 2700, 2703, 0, 1),
(241, 74, 2700, 2700, 2703, 0, 0),
(242, 74, 2703, 2700, 2703, 0, 0),
(243, 75, 2700, 2700, 2703, 0, 0),
(244, 75, 2703, 2700, 2703, 0, 1),
(245, 76, 2700, 2700, 2703, 0, 0),
(246, 76, 2703, 2700, 2703, 0, 0),
(247, 77, 2700, 2700, 2703, 0, 0),
(248, 77, 2703, 2700, 2703, 0, 0),
(249, 78, 2700, 2700, 2703, 0, 0),
(250, 78, 2703, 2700, 2703, 0, 0),
(251, 79, 2700, 2700, 2703, 0, 0),
(252, 79, 2703, 2700, 2703, 0, 0),
(253, 80, 2703, 2700, 2703, 1, 1),
(255, 81, 2674, 2674, 2682, 0, 0),
(256, 81, 2682, 2674, 2682, 0, 0),
(257, 82, 2674, 2674, 2682, 0, 0),
(258, 82, 2682, 2674, 2682, 0, 0),
(259, 83, 2674, 2674, 2682, 0, 0),
(260, 83, 2682, 2674, 2682, 0, 0),
(261, 84, 2674, 2674, 2681, 0, 0),
(262, 84, 2681, 2674, 2681, 0, 0),
(263, 85, 2674, 2674, 2681, 0, 0),
(264, 85, 2681, 2674, 2681, 0, 0),
(265, 86, 2674, 2674, 2681, 0, 0),
(266, 86, 2681, 2674, 2681, 0, 0),
(267, 87, 2674, 2674, 2681, 0, 0),
(268, 87, 2681, 2674, 2681, 0, 0),
(269, 88, 2700, 2700, 2703, 0, 0),
(270, 88, 2703, 2700, 2703, 0, 1),
(271, 89, 2703, 2703, 2700, 0, 0),
(272, 89, 2700, 2703, 2700, 0, 0),
(273, 90, 2703, 2703, 2700, 0, 0),
(274, 90, 2700, 2703, 2700, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `sponsor_bonus`
--

CREATE TABLE `sponsor_bonus` (
  `sponsor_bonus_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `sponsored_id` int(11) NOT NULL DEFAULT '0',
  `is_bonus` tinyint(1) NOT NULL DEFAULT '0',
  `z_date` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `stats_countries`
--

CREATE TABLE `stats_countries` (
  `country_id` int(11) NOT NULL,
  `country` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `stats_countries`
--

INSERT INTO `stats_countries` (`country_id`, `country`) VALUES
(1, 'Undefined');

-- --------------------------------------------------------

--
-- Структура таблицы `stats_referrals`
--

CREATE TABLE `stats_referrals` (
  `referral_id` int(11) NOT NULL,
  `referral` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `stats_referrals`
--

INSERT INTO `stats_referrals` (`referral_id`, `referral`) VALUES
(1, 'No referrer'),
(2, 'http://swan20.com.runmlm.com/'),
(3, 'http://swan20.com.runmlm.com/activation.php'),
(4, 'http://swan20.com.runmlm.com/news.php'),
(5, 'http://swan20.com.runmlm.com/faq.php'),
(6, 'http://swan20.com.runmlm.com/ticket.php'),
(7, 'http://swan20.com.runmlm.com/login.php'),
(8, 'http://swan20.com.runmlm.com/signup.php');

-- --------------------------------------------------------

--
-- Структура таблицы `stats_views`
--

CREATE TABLE `stats_views` (
  `view_id` int(11) NOT NULL,
  `visitor_id` int(11) NOT NULL DEFAULT '0',
  `page` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `thetime` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `stats_views`
--

INSERT INTO `stats_views` (`view_id`, `visitor_id`, `page`, `thetime`) VALUES
(1, 1, '/index.php', 1607507974),
(2, 2, '/index.php', 1607508853),
(3, 3, '/index.php', 1607508863),
(4, 4, '/index.php', 1607509012),
(5, 5, '/index.php', 1607509040),
(6, 6, '/thank_you.php', 1607509041),
(7, 7, '/activation.php', 1607509066),
(8, 8, '/activation.php', 1607509071),
(9, 9, '/activation.php', 1607509085),
(10, 10, '/activation.php', 1607509086),
(11, 11, '/activation.php', 1607509113),
(12, 12, '/activation.php', 1607509123),
(13, 13, '/activation.php', 1607509124),
(14, 14, '/activation.php', 1607509128),
(15, 15, '/index.php', 1607509369),
(16, 16, '/index.php', 1607509385),
(17, 17, '/activation.php', 1607509574),
(18, 18, '/index.php', 1607509657),
(19, 19, '/index.php', 1607532652),
(20, 20, '/index.php', 1607533287),
(21, 21, '/index.php', 1607533337),
(22, 22, '/index.php', 1607533452),
(23, 23, '/index.php', 1607533456),
(24, 24, '/index.php', 1607533490),
(25, 25, '/index.php', 1607533506),
(26, 26, '/index.php', 1607533518),
(27, 27, '/news.php', 1607533566),
(28, 28, '/faq.php', 1607533569),
(29, 29, '/ticket.php', 1607533581),
(30, 30, '/ticket.php', 1607533852),
(31, 31, '/ticket.php', 1607533867),
(32, 32, '/ticket.php', 1607533901),
(33, 33, '/ticket.php', 1607533963),
(34, 34, '/ticket.php', 1607533984),
(35, 35, '/index.php', 1607533991),
(36, 36, '/index.php', 1607534009),
(37, 37, '/login.php', 1607534011),
(38, 38, '/signup.php', 1607534014),
(39, 39, '/signup.php', 1607534691),
(40, 40, '/signup.php', 1607534920),
(41, 41, '/signup.php', 1607534942),
(42, 42, '/signup.php', 1607535105),
(43, 43, '/thank_you.php', 1607535107),
(44, 44, '/thank_you.php', 1607535209),
(45, 45, '/signup.php', 1607535213),
(46, 46, '/signup.php', 1607535233),
(47, 47, '/signup.php', 1607535257);

-- --------------------------------------------------------

--
-- Структура таблицы `stats_visitors`
--

CREATE TABLE `stats_visitors` (
  `visitor_id` int(11) NOT NULL,
  `ipaddress` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ipref` int(11) NOT NULL DEFAULT '0',
  `country` int(11) NOT NULL DEFAULT '0',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `thetime` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `stats_visitors`
--

INSERT INTO `stats_visitors` (`visitor_id`, `ipaddress`, `ipref`, `country`, `city`, `thetime`) VALUES
(1, '52.114.75.71', 1, 1, 'Undefined', 1607507974),
(2, '2401:3c00:18f:4c1a:f', 1, 1, 'Undefined', 1607508853),
(3, '2401:3c00:18f:4c1a:f', 2, 1, 'Undefined', 1607508863),
(4, '2401:3c00:18f:4c1a:f', 1, 1, 'Undefined', 1607509012),
(5, '2401:3c00:18f:4c1a:f', 2, 1, 'Undefined', 1607509040),
(6, '2401:3c00:18f:4c1a:f', 2, 1, 'Undefined', 1607509041),
(7, '2401:3c00:18f:4c1a:f', 1, 1, 'Undefined', 1607509066),
(8, '203.82.75.133', 1, 1, 'Undefined', 1607509071),
(9, '2401:3c00:18f:4c1a:f', 3, 1, 'Undefined', 1607509085),
(10, '2401:3c00:18f:4c1a:f', 3, 1, 'Undefined', 1607509086),
(11, '2401:3c00:18f:4c1a:f', 1, 1, 'Undefined', 1607509113),
(12, '2401:3c00:18f:4c1a:f', 3, 1, 'Undefined', 1607509123),
(13, '2401:3c00:18f:4c1a:f', 3, 1, 'Undefined', 1607509124),
(14, '2401:3c00:18f:4c1a:f', 1, 1, 'Undefined', 1607509128),
(15, '61.129.8.179', 1, 1, 'Undefined', 1607509369),
(16, '61.151.178.236', 1, 1, 'Undefined', 1607509385),
(17, '101.89.239.230', 1, 1, 'Undefined', 1607509574),
(18, '61.129.7.235', 1, 1, 'Undefined', 1607509657),
(19, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607532652),
(20, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533287),
(21, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533337),
(22, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533452),
(23, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533456),
(24, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533490),
(25, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533506),
(26, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533518),
(27, '2a00:bc00:8800:b665:', 2, 1, 'Undefined', 1607533566),
(28, '2a00:bc00:8800:b665:', 4, 1, 'Undefined', 1607533569),
(29, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533581),
(30, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533852),
(31, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533867),
(32, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533901),
(33, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533963),
(34, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533984),
(35, '2a00:bc00:8800:b665:', 6, 1, 'Undefined', 1607533991),
(36, '2a00:bc00:8800:b665:', 6, 1, 'Undefined', 1607534009),
(37, '2a00:bc00:8800:b665:', 2, 1, 'Undefined', 1607534011),
(38, '2a00:bc00:8800:b665:', 7, 1, 'Undefined', 1607534014),
(39, '2a00:bc00:8800:b665:', 7, 1, 'Undefined', 1607534691),
(40, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607534920),
(41, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607534942),
(42, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535105),
(43, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535107),
(44, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535209),
(45, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535213),
(46, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535233),
(47, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535257);

-- --------------------------------------------------------

--
-- Структура таблицы `stat_counter`
--

CREATE TABLE `stat_counter` (
  `id` int(11) UNSIGNED NOT NULL,
  `page` bigint(20) DEFAULT '0',
  `un_ip` bigint(20) DEFAULT '0',
  `un_browser` bigint(20) DEFAULT '0',
  `date` date DEFAULT '0000-00-00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `stat_log`
--

CREATE TABLE `stat_log` (
  `id` int(11) UNSIGNED NOT NULL,
  `date` date DEFAULT '0000-00-00',
  `time` time DEFAULT '00:00:00',
  `ip` varchar(16) DEFAULT '',
  `proxy` varchar(16) DEFAULT '',
  `page` varchar(1024) DEFAULT '',
  `referer` varchar(1024) DEFAULT '',
  `language` varchar(8) DEFAULT '',
  `agent` varchar(255) DEFAULT '',
  `un_browser` int(1) DEFAULT '0',
  `un_ip` int(1) DEFAULT '0',
  `session` bigint(20) DEFAULT '0',
  `screen` varchar(255) DEFAULT '',
  `get` text,
  `post` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `testimonials`
--

CREATE TABLE `testimonials` (
  `testimonial_id` int(11) NOT NULL,
  `number` int(5) NOT NULL DEFAULT '0',
  `author` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `location` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `testimonials`
--

INSERT INTO `testimonials` (`testimonial_id`, `number`, `author`, `location`, `description`, `photo`, `is_active`) VALUES
(1, 0, '1 am', '', 'messagemessagemessage', '_9ieghudm2e.jpg', 1),
(2, 0, 'фыв', '', 'ыфп', '_gd1sq6kel3.jpg', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `text_ads`
--

CREATE TABLE `text_ads` (
  `text_ad_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description1` varchar(35) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description2` varchar(35) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `url` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `show_url` tinyint(1) NOT NULL DEFAULT '0',
  `displayed` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `tickets`
--

CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `subject` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date_create` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  `last_replier` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_read` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `ticket_messages`
--

CREATE TABLE `ticket_messages` (
  `ticket_message_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL DEFAULT '0',
  `message_from` int(11) NOT NULL DEFAULT '0',
  `message_to` int(11) NOT NULL DEFAULT '0',
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `date_post` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `types`
--

CREATE TABLE `types` (
  `type_id` int(11) NOT NULL,
  `order_index` int(11) NOT NULL DEFAULT '0',
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cost` decimal(12,2) NOT NULL DEFAULT '0.00',
  `host_fee` decimal(12,2) NOT NULL DEFAULT '0.00',
  `enr_fee` decimal(12,2) NOT NULL DEFAULT '0.00',
  `admin_fee` decimal(12,2) NOT NULL DEFAULT '0.00',
  `width` int(3) NOT NULL DEFAULT '0',
  `depth` int(3) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `types`
--

INSERT INTO `types` (`type_id`, `order_index`, `title`, `cost`, `host_fee`, `enr_fee`, `admin_fee`, `width`, `depth`) VALUES
(1, 1, 'Free Stage', '0.00', '0.00', '0.00', '0.00', 0, 0),
(2, 2, 'Stage 1', '20.00', '0.00', '0.00', '0.00', 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `user_admins`
--

CREATE TABLE `user_admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `passwd` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_access` int(11) NOT NULL DEFAULT '0',
  `access` varchar(2048) COLLATE utf8_unicode_ci DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `user_admins`
--

INSERT INTO `user_admins` (`id`, `username`, `passwd`, `email`, `first_name`, `last_name`, `last_access`, `access`, `is_active`) VALUES
(1, 'admin', 'fc93f0a8fa5c3527b8d0ad486df7e6e3', 'support@runmlm.com', '', '', 0, 'a:39:{i:0;s:5:\"login\";i:1;s:6:\"admins\";i:2;s:4:\"stat\";i:3;s:7:\"members\";i:4;s:4:\"tree\";i:5;s:12:\"admindetails\";i:6;s:8:\"settings\";i:7;s:8:\"matrixes\";i:8;s:6:\"levels\";i:9;s:13:\"levels_forced\";i:10;s:7:\"payment\";i:11;s:4:\"cash\";i:12;s:8:\"cash_out\";i:13;s:10:\"processors\";i:14;s:5:\"pages\";i:15;s:7:\"m_pages\";i:16;s:4:\"news\";i:17;s:3:\"faq\";i:18;s:5:\"lands\";i:19;s:7:\"aptools\";i:20;s:6:\"ptools\";i:21;s:4:\"tads\";i:22;s:7:\"tickets\";i:23;s:11:\"pub_tickets\";i:24;s:9:\"templates\";i:25;s:15:\"autorespondersf\";i:26;s:14:\"autoresponders\";i:27;s:11:\"atempplates\";i:28;s:7:\"mailing\";i:29;s:6:\"backup\";i:30;s:4:\"fees\";i:31;s:11:\"memb_matrix\";i:32;s:8:\"m_levels\";i:33;s:13:\"forced_matrix\";i:34;s:12:\"replica_site\";i:35;s:6:\"manual\";i:36;s:17:\"template_elements\";i:37;s:14:\"upload_members\";i:38;s:6:\"slider\";}', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `aemailtempl`
--
ALTER TABLE `aemailtempl`
  ADD PRIMARY KEY (`emailtempl_id`);

--
-- Индексы таблицы `aptools`
--
ALTER TABLE `aptools`
  ADD PRIMARY KEY (`aptool_id`);

--
-- Индексы таблицы `autoresponders`
--
ALTER TABLE `autoresponders`
  ADD PRIMARY KEY (`email_id`);

--
-- Индексы таблицы `cash`
--
ALTER TABLE `cash`
  ADD PRIMARY KEY (`cash_id`),
  ADD KEY `transfer_date_idx` (`cash_date`),
  ADD KEY `user_id_idx` (`to_id`),
  ADD KEY `amount_idx` (`amount`),
  ADD KEY `from_id_idx` (`from_id`);

--
-- Индексы таблицы `cash_out`
--
ALTER TABLE `cash_out`
  ADD PRIMARY KEY (`cash_out_id`),
  ADD KEY `transfer_date_idx` (`transfer_date`),
  ADD KEY `member_id_idx` (`member_id`);

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Индексы таблицы `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `emailtempl`
--
ALTER TABLE `emailtempl`
  ADD PRIMARY KEY (`emailtempl_id`);

--
-- Индексы таблицы `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`faq_id`);

--
-- Индексы таблицы `fees`
--
ALTER TABLE `fees`
  ADD PRIMARY KEY (`fee_id`),
  ADD KEY `to_order_index_idx` (`to_order_index`);

--
-- Индексы таблицы `lands`
--
ALTER TABLE `lands`
  ADD PRIMARY KEY (`land_id`),
  ADD KEY `z_date_idx` (`z_date`);

--
-- Индексы таблицы `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `z_date_idx` (`z_date`);

--
-- Индексы таблицы `matrices_completed`
--
ALTER TABLE `matrices_completed`
  ADD PRIMARY KEY (`matrix_id`),
  ADD KEY `place_id_idx` (`place_id`),
  ADD KEY `z_date_idx` (`z_date`);

--
-- Индексы таблицы `matrix`
--
ALTER TABLE `matrix`
  ADD PRIMARY KEY (`matrix_id`),
  ADD KEY `host_id_idx` (`host_id`),
  ADD KEY `member_id_idx` (`member_id`),
  ADD KEY `referrer_id_idx` (`referrer_id`),
  ADD KEY `m_level_idx` (`m_level`),
  ADD KEY `host_matrix_idx` (`host_matrix`);

--
-- Индексы таблицы `matrixes`
--
ALTER TABLE `matrixes`
  ADD PRIMARY KEY (`matrix_id`),
  ADD KEY `title_idx` (`title`);

--
-- Индексы таблицы `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`member_id`),
  ADD KEY `username_idx` (`username`),
  ADD KEY `reg_date_idx` (`reg_date`);

--
-- Индексы таблицы `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`news_id`),
  ADD KEY `news_date_idx` (`news_date`);

--
-- Индексы таблицы `online_stats`
--
ALTER TABLE `online_stats`
  ADD PRIMARY KEY (`online_stat_id`),
  ADD KEY `session_id_idx` (`session_id`),
  ADD KEY `member_id_idx` (`member_id`);

--
-- Индексы таблицы `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`page_id`),
  ADD KEY `order_index_idx` (`order_index`);

--
-- Индексы таблицы `payins`
--
ALTER TABLE `payins`
  ADD PRIMARY KEY (`payins_id`),
  ADD KEY `transaction_id_idx` (`transaction_id`),
  ADD KEY `member_id_idx` (`member_id`);

--
-- Индексы таблицы `payins_log`
--
ALTER TABLE `payins_log`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `places`
--
ALTER TABLE `places`
  ADD PRIMARY KEY (`place_id`),
  ADD KEY `member_id_idx` (`member_id`),
  ADD KEY `referrer_place_id_idx` (`referrer_place_id`);

--
-- Индексы таблицы `processors`
--
ALTER TABLE `processors`
  ADD PRIMARY KEY (`processor_id`),
  ADD KEY `code_idx` (`code`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `price_idx` (`price`);

--
-- Индексы таблицы `ptools`
--
ALTER TABLE `ptools`
  ADD PRIMARY KEY (`ptool_id`),
  ADD KEY `title_idx` (`title`);

--
-- Индексы таблицы `pub_tickets`
--
ALTER TABLE `pub_tickets`
  ADD PRIMARY KEY (`pub_ticket_id`);

--
-- Индексы таблицы `pub_ticket_messages`
--
ALTER TABLE `pub_ticket_messages`
  ADD PRIMARY KEY (`pub_ticket_message_id`);

--
-- Индексы таблицы `replicas`
--
ALTER TABLE `replicas`
  ADD PRIMARY KEY (`replica_id`),
  ADD KEY `member_id_idx` (`member_id`),
  ADD KEY `order_index_idx` (`order_index`);

--
-- Индексы таблицы `selected`
--
ALTER TABLE `selected`
  ADD PRIMARY KEY (`selected_id`);

--
-- Индексы таблицы `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`setting_id`),
  ADD KEY `key1` (`keyname`);

--
-- Индексы таблицы `shop_fees`
--
ALTER TABLE `shop_fees`
  ADD PRIMARY KEY (`fee_id`),
  ADD KEY `to_order_index_idx` (`to_order_index`);

--
-- Индексы таблицы `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `sn_messages`
--
ALTER TABLE `sn_messages`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `sn_messages_mem`
--
ALTER TABLE `sn_messages_mem`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `sponsor_bonus`
--
ALTER TABLE `sponsor_bonus`
  ADD PRIMARY KEY (`sponsor_bonus_id`),
  ADD KEY `member_id_idx` (`member_id`),
  ADD KEY `sponsored_id_idx` (`sponsored_id`);

--
-- Индексы таблицы `stats_countries`
--
ALTER TABLE `stats_countries`
  ADD PRIMARY KEY (`country_id`),
  ADD KEY `referral_idx` (`country`);

--
-- Индексы таблицы `stats_referrals`
--
ALTER TABLE `stats_referrals`
  ADD PRIMARY KEY (`referral_id`),
  ADD KEY `referral_idx` (`referral`);

--
-- Индексы таблицы `stats_views`
--
ALTER TABLE `stats_views`
  ADD PRIMARY KEY (`view_id`),
  ADD KEY `ipaddress_idx` (`visitor_id`),
  ADD KEY `country_idx` (`page`),
  ADD KEY `city_idx` (`thetime`);

--
-- Индексы таблицы `stats_visitors`
--
ALTER TABLE `stats_visitors`
  ADD PRIMARY KEY (`visitor_id`),
  ADD KEY `ipaddress_idx` (`ipaddress`),
  ADD KEY `country_idx` (`country`),
  ADD KEY `city_idx` (`city`),
  ADD KEY `thetime` (`thetime`);

--
-- Индексы таблицы `stat_counter`
--
ALTER TABLE `stat_counter`
  ADD KEY `id` (`id`);

--
-- Индексы таблицы `stat_log`
--
ALTER TABLE `stat_log`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`testimonial_id`),
  ADD KEY `number_idx` (`number`);

--
-- Индексы таблицы `text_ads`
--
ALTER TABLE `text_ads`
  ADD PRIMARY KEY (`text_ad_id`),
  ADD KEY `member_id_idx` (`member_id`),
  ADD KEY `displayed_idx` (`displayed`);

--
-- Индексы таблицы `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Индексы таблицы `ticket_messages`
--
ALTER TABLE `ticket_messages`
  ADD PRIMARY KEY (`ticket_message_id`);

--
-- Индексы таблицы `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`type_id`),
  ADD KEY `order_index_idx` (`order_index`);

--
-- Индексы таблицы `user_admins`
--
ALTER TABLE `user_admins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username_idx` (`username`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `aemailtempl`
--
ALTER TABLE `aemailtempl`
  MODIFY `emailtempl_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `aptools`
--
ALTER TABLE `aptools`
  MODIFY `aptool_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `autoresponders`
--
ALTER TABLE `autoresponders`
  MODIFY `email_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `cash`
--
ALTER TABLE `cash`
  MODIFY `cash_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `cash_out`
--
ALTER TABLE `cash_out`
  MODIFY `cash_out_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `currency`
--
ALTER TABLE `currency`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `emailtempl`
--
ALTER TABLE `emailtempl`
  MODIFY `emailtempl_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `faq`
--
ALTER TABLE `faq`
  MODIFY `faq_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `fees`
--
ALTER TABLE `fees`
  MODIFY `fee_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `lands`
--
ALTER TABLE `lands`
  MODIFY `land_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `logs`
--
ALTER TABLE `logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT для таблицы `matrices_completed`
--
ALTER TABLE `matrices_completed`
  MODIFY `matrix_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `matrix`
--
ALTER TABLE `matrix`
  MODIFY `matrix_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `matrixes`
--
ALTER TABLE `matrixes`
  MODIFY `matrix_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `members`
--
ALTER TABLE `members`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT для таблицы `news`
--
ALTER TABLE `news`
  MODIFY `news_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `online_stats`
--
ALTER TABLE `online_stats`
  MODIFY `online_stat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1268;

--
-- AUTO_INCREMENT для таблицы `pages`
--
ALTER TABLE `pages`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `payins`
--
ALTER TABLE `payins`
  MODIFY `payins_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `payins_log`
--
ALTER TABLE `payins_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `places`
--
ALTER TABLE `places`
  MODIFY `place_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `processors`
--
ALTER TABLE `processors`
  MODIFY `processor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `ptools`
--
ALTER TABLE `ptools`
  MODIFY `ptool_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `pub_tickets`
--
ALTER TABLE `pub_tickets`
  MODIFY `pub_ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `pub_ticket_messages`
--
ALTER TABLE `pub_ticket_messages`
  MODIFY `pub_ticket_message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `replicas`
--
ALTER TABLE `replicas`
  MODIFY `replica_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `selected`
--
ALTER TABLE `selected`
  MODIFY `selected_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `settings`
--
ALTER TABLE `settings`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT для таблицы `shop_fees`
--
ALTER TABLE `shop_fees`
  MODIFY `fee_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `sn_messages`
--
ALTER TABLE `sn_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT для таблицы `sn_messages_mem`
--
ALTER TABLE `sn_messages_mem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=275;

--
-- AUTO_INCREMENT для таблицы `sponsor_bonus`
--
ALTER TABLE `sponsor_bonus`
  MODIFY `sponsor_bonus_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `stats_countries`
--
ALTER TABLE `stats_countries`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `stats_referrals`
--
ALTER TABLE `stats_referrals`
  MODIFY `referral_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `stats_views`
--
ALTER TABLE `stats_views`
  MODIFY `view_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT для таблицы `stats_visitors`
--
ALTER TABLE `stats_visitors`
  MODIFY `visitor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT для таблицы `stat_counter`
--
ALTER TABLE `stat_counter`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `stat_log`
--
ALTER TABLE `stat_log`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `testimonial_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `text_ads`
--
ALTER TABLE `text_ads`
  MODIFY `text_ad_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `ticket_messages`
--
ALTER TABLE `ticket_messages`
  MODIFY `ticket_message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `types`
--
ALTER TABLE `types`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `user_admins`
--
ALTER TABLE `user_admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
