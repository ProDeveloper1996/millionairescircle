<?php
require_once("bitcoin.php");

define("BTC_FEE_LEVEL", 'low' ); // low | medium | high
define("BTC_CONFIRM", 3 );
define("BTC_COMMIS", 0.0002 );


?>