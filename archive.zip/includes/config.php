<?php
define ("DbHost", "irushost.mysql.ukraine.com.ua");
define ("DbName", "irushost_millionairescircle");
define ("DbUserName", "irushost_millionairescircle");
define ("DbUserPwd", "j-G7uK+p59");

define ("LANG", "en");
////�?>