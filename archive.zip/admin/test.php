<?php
    print phpinfo();
?>
