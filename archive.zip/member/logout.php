<?php

require_once ("../includes/config.php");
require_once ("../includes/xtemplate.php");
require_once ("../includes/utilities.php");
require_once ("../includes/xpage_member.php");

$xPage = new XPage ();

$xPage->Logout ();

?>