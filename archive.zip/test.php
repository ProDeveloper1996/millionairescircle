<?php
    print phpinfo();
?>