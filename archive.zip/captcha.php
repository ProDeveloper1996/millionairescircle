<?php
 session_start();

require_once ("includes/config.php");
require_once ("includes/xpage_public.php");
 include('captcha/captcha_ver1.php');

?>
